<input type="hidden" name="services_serial" value="<?= isset($services) ? base64_encode(json_encode($services)) : "" ?>">
<input type="hidden" name="serviceargs_serial" value="<?= isset($serviceargs) ? base64_encode(json_encode($serviceargs)) : "" ?>">
<h5 class="ul"><?= _('Server Information') ?></h5>

<?php
$versionString = shell_exec('python3 -c "import sys; print(sys.version_info[0])" 2>/dev/null');
if ($versionString === null) { ?>
    <ul class="actionMessage">
        <li><b><?php echo _("Python 3 is required to run this wizard."); ?></b></li>
    </ul>
<?php } ?>

<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label><?= _('IP Address') ?>:</label>
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>" class="form-control">
            <div class="subtext"><?= _('The IP address name of the Windows Machine you\'d like to monitor.') ?></div>
        </td>
    </tr>
    <tr>
    <td class="vt">
        <label><?= _('SSH Username') ?>:</label>
    </td>
    <td>
        <input type="text" size="40" name="ssh_username" id="ssh_username" value="<?= encode_form_val($ssh_username) ?>" class="form-control">
        <div class="subtext"><?= _('The SSH username to use when connecting to the server.') ?></div>
    </td>
    </tr>
</table>
<p><b><?= sprintf(_('If you haven\'t used this wizard before, please read the documentation %shere%s'), '<a target="_blank" href="https://answerhub.nagios.com/support/s/article/Windows-SSH-Configuration-Wizard-for-Nagios-XI-9a5920ef">', '</a>'); ?></b></p>