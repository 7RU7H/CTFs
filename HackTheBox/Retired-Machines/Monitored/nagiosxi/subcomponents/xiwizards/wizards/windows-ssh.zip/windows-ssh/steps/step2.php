<input type="hidden" name="ip_address" value="<?= encode_form_val($address) ?>">
<h5 class="ul">
    <?= _('Server Details') ?>
</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>
                <?= _('IP Address') ?>:
            </label>
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="<?= encode_form_val($address) ?>"
                class="form-control" disabled>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>
                <?= _('Host Name') ?>:
            </label>
        </td>
        <td>
            <input type="text" size="20" name="hostname" id="hostname" value="<?= encode_form_val($hostname) ?>"
                class="form-control">
            <div class="subtext">
                <?= _('The name you\'d like to have associated with this server.') ?>
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>
                <?= _('SSH username') ?>:
            </label>
        </td>
        <td>
            <input type="text" size="20" name="ssh_username" id="ssh_username"
                value="<?= encode_form_val($ssh_username) ?>" class="form-control">
            <div class="subtext">
                <?= _('The username you\'d like to use to connect to the server via SSH.') ?>
            </div>
        </td>
    </tr>
    <tr>
                    <td class="vt"></td>
                    <td class="checkbox">
                        <label>
                        <input type="hidden" name="services[tcp][monitor]" value="<?= encode_form_val($services["tcp"]["monitor"]) ?>">
                        <input type="checkbox" id="p" class="checkbox" name="services[ping][monitor]"
                <?= is_checked(checkbox_binary($services["ping"]["monitor"]), "1") ?>>Enable ICMP Ping Monitoring instead of TCP
                        </label>
                    </td>
                </tr>
</table>
<h5 class="ul">
    <?= _('Server Metrics') ?>
</h5>
<p>
    <?= _('Specify which services you\'d like to monitor for the server.') ?>
</p>
<table class="table table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <input type="checkbox" id="volume" class="checkbox" name="services[volume][monitor]"
                <?= is_checked(checkbox_binary($services["volume"]["monitor"]), "1") ?>>
        </td>
        <td>
            <label class="normal" for="volume">
                <b>
                    <?= _('Volume') ?>
                </b><br>
                <?= _('Monitors disk volume.') ?>
            </label>
            <div class="pad-t5">
            </div>
            <div style="display: inline-block; vertical-align: top; height: auto;">
                <div class="pad-t5">
                    <table class="adddeleterow table table-condensed table-no-border table-auto-width"
                        style="margin-bottom: 10px;">
                        <thead>
                            <tr>
                            </tr>
                        </thead>
<?php
    $count = count($services["volume"]);

    if ($count > 2) {
        $count--;
    }

    for ($increment_table = 0; $increment_table < $count; $increment_table++):
?>
                            <tr>
                                <td>
                                    <label>
                                        <?= _('Drive:') ?>
                                    </label>
                                    <select name="services[volume][<?= $increment_table ?>][drive]" id="drive"
                                        class="form-control condensed">
                                        <option value="" <?= isset($services["volume"][$increment_table]["drive"]) ? is_selected($services["volume"][$increment_table]["drive"], "") : "" ?>></option>
                                        <?php for ($increment_table_options = 65; $increment_table_options < 91; $increment_table_options++): ?>
                                            <option value="<?= chr($increment_table_options) ?>:" <?= isset($services["volume"][$increment_table]["drive"]) ? is_selected($services["volume"][$increment_table]["drive"], chr($increment_table_options) . ":") : "" ?>><?= chr($increment_table_options) ?>:</option>
                                        <?php endfor; ?>
                                    </select>
                                </td>
                                <td>
                                    <select name="services[volume][<?= $increment_table ?>][outputType]" id="outputType"
                                        class="form-control condensed">
                                        <option value="GB" <?= is_selected($services["volume"][$increment_table]["outputType"], "GB") ?>>
                                            <?= _('GB') ?>
                                        </option>
                                        <option value="TB" <?= is_selected($services["volume"][$increment_table]["outputType"], "TB") ?>>
                                            <?= _('TB') ?>
                                        </option>
                                        <option value="MB" <?= is_selected($services["volume"][$increment_table]["outputType"], "MB") ?>>
                                            <?= _('MB') ?>
                                        </option>
                                        <option value="%" <?= is_selected($services["volume"][$increment_table]["outputType"], "%") ?>>
                                            <?= _('%') ?>
                                        </option>
                                    </select>
                                    <select name="services[volume][<?= $increment_table ?>][metric]" id="metric" style="margin-right: 20px;"
                                        class="form-control condensed">
                                        <option value="Used" <?= is_selected($services["volume"][$increment_table]["metric"], "Used") ?>>
                                            <?= _('Used') ?>
                                        </option>
                                        <option value="Available" <?= is_selected($services["volume"][$increment_table]["metric"], "Available") ?>><?= _('Available') ?></option>
                                    </select>

                                    <label><img src="<?= theme_image('error.png') ?>" class="tt-bind"
                                            title="<?= _('Warning Threshold') ?>"></label>
                                    <input type="text" size="1" name="services[volume][<?= $increment_table ?>][warning]" 
                                        value="<?= encode_form_val($services['volume'][$increment_table]['warning']) ?>"
                                        class="form-control condensed"> %&nbsp;&nbsp;
                                    <label><img src="<?= theme_image('critical_small.png') ?>" class="tt-bind"
                                            title="<?= _('Critical Threshold') ?>"></label>
                                    <input type="text" size="1" name="services[volume][<?= $increment_table ?>][critical]"
                                        value="<?= encode_form_val($services['volume'][$increment_table]['critical']) ?>"
                                        class="form-control condensed"> %
                                </td>
                            </tr>
                        <?php endfor; ?>
                    </table>
    </tr>
    <tr>
        <td>
            <input type="checkbox" id="memory_usage" class="checkbox" name="services[memory_usage][monitor]"
                <?= is_checked(checkbox_binary($services["memory_usage"]["monitor"]), "1") ?>>
        </td>
        <td>
            <label class="normal" for="memory_usage">
                <b>
                    <?= _('Memory Usage') ?>
                </b><br>
                <?= _('Monitors the amount of memory used on the server.') ?>
            </label>
             <div class="pad-t5">
                <label>
                    <?= _('Metric') ?>:
                </label>
                <select name="services[memory_usage][outputType]" id="outputType" class="form-control condensed">
                    <option value="MB" <?= is_selected($services["memory_usage"]["outputType"], "MB") ?>><?= _('MB') ?>
                    </option>
                    <option value="GB" <?= is_selected($services["memory_usage"]["outputType"], "GB") ?>><?= _('GB') ?>
                    </option>
                    <option value="TB" <?= is_selected($services["memory_usage"]["outputType"], "TB") ?>><?= _('TB') ?>
                    </option>
                    <option value="%" <?= is_selected($services["memory_usage"]["outputType"], "%") ?>><?= _('%') ?>
                    </option>
                </select>
                <select name="services[memory_usage][metric]" id="metric" class="form-control condensed" style="margin-right: 20px;">
                    <option value="Used" <?= is_selected($services["memory_usage"]["metric"], "Used") ?>><?= _('Used') ?>
                    </option>
                    <option value="Available" <?= is_selected($services["memory_usage"]["metric"], "Available") ?>>
                        <?= _('Available') ?>
                    </option>
                </select>
                <label><img src="<?= theme_image('error.png') ?>" class="tt-bind"
                        title="<?= _('Warning Threshold') ?>"></label>
                <input type="text" size="5" name="services[memory_usage][warning]"
                    value="<?= encode_form_val($services['memory_usage']['warning']) ?>" class="form-control condensed">
                <label><img src="<?= theme_image('critical_small.png') ?>" class="tt-bind"
                        title="<?= _('Critical Threshold') ?>"></label>
                <input type="text" size="5" name="services[memory_usage][critical]"
                    value="<?= encode_form_val($services['memory_usage']['critical']) ?>"
                    class="form-control condensed">
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="cpu_usage" class="checkbox" name="services[cpu_usage][monitor]"
                <?= is_checked(checkbox_binary($services["cpu_usage"]["monitor"]), "1") ?>>
        </td>
        <td>
            <label class="normal" for="cpu_usage">
                <b>
                    <?= _('CPU Usage') ?>
                </b><br>
                <?= _('Monitors CPU usage.') ?>
            </label>
            <div class="pad-t5">
                <label><img src="<?= theme_image('error.png') ?>" class="tt-bind"
                        title="<?= _('Warning Threshold') ?>"></label>
                <input type="text" size="1" name="services[cpu_usage][warning]"
                    value="<?= encode_form_val($services['cpu_usage']['warning']) ?>" class="form-control condensed">
                <?= _('%') ?>&nbsp;&nbsp;
                <label><img src="<?= theme_image('critical_small.png') ?>" class="tt-bind"
                        title="<?= _('Critical Threshold') ?>"></label>
                <input type="text" size="1" name="services[cpu_usage][critical]"
                    value="<?= encode_form_val($services['cpu_usage']['critical']) ?>" class="form-control condensed">
                <?= _('%') ?>
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="disk_usage" class="checkbox" name="services[disk_usage][monitor]"
                <?= is_checked(checkbox_binary($services["disk_usage"]["monitor"]), "1") ?>>
        </td>
        <td>
            <label class="normal" for="disk_usage">
                <b>
                    <?= _('Disk Usage') ?>
                </b><br>
                <?= _('Monitors disk usage.') ?>
            </label>
            <div class="pad-t5">
            </div>
            <div style="display: inline-block; vertical-align: top; height: auto;">
                <div class="pad-t5">
                    <table class="adddeleterow table table-condensed table-no-border table-auto-width"
                        style="margin-bottom: 10px;">
                        <thead>
                            <tr>
                                <th>
                                    <?= _('Disk #') ?>
                                </th>
                                <th>
                                </th>
                                <th>
                                    <div style="text-align: right;">
                                        <?= _('Operations/Sec') ?>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
<?php
    $count = count($services["disk_usage"]);

    if ($count > 2) {
        $count--;
    }

    for ($increment_table = 0; $increment_table < $count; $increment_table++):
?>
                                <tr>
                                    <td>
                                        <input type="text" size="1" name="services[disk_usage][<?= $increment_table ?>][disk_number]"
                                            value="<?= isset($services['disk_usage'][$increment_table]['disk_number']) ? encode_form_val($services['disk_usage'][$increment_table]['disk_number']) : "" ?>"
                                            class="form-control condensed">
                                    </td>
                                    <td>
                                        <select name="services[disk_usage][<?= $increment_table ?>][metric]" id="metric"
                                            class="form-control condensed">
                                            <option value="Total" <?= is_selected($services["disk_usage"][$increment_table]["metric"], "Total") ?>><?= _('Total') ?></option>
                                            <option value="Read" <?= is_selected($services["disk_usage"][$increment_table]["metric"], "Read") ?>><?= _('Read') ?></option>
                                        </select>
                                    </td>
                                    <td>
                                        <label><img src="<?= theme_image('error.png') ?>" class="tt-bind"
                                                title="<?= _('Warning Threshold') ?>"></label>
                                        <input type="text" size="1" name="services[disk_usage][<?= $increment_table ?>][warning]"
                                            value="<?= encode_form_val($services['disk_usage'][$increment_table]['warning']) ?>"
                                            class="form-control condensed">
                                        <label><img src="<?= theme_image('critical_small.png') ?>" class="tt-bind"
                                                title="<?= _('Critical Threshold') ?>"></label>
                                        <input type="text" size="1" name="services[disk_usage][<?= $increment_table ?>][critical]"
                                            value="<?= encode_form_val($services['disk_usage'][$increment_table]['critical']) ?>"
                                            class="form-control condensed">
                                    </td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
    </tr>

    <tr>
        <td class="vt">
            <input type="checkbox" id="windows_services" class="checkbox" name="services[windows_services][monitor]"
                <?= is_checked(checkbox_binary($services["windows_services"]["monitor"]), "1") ?>>
        </td>
        <td>
            <label class="normal" for="windows_services"> 
                <b>
                    <?= _('Windows Services') ?>
                </b><br>
                <?= _('Monitors Windows Services.') ?>
            </label>
            <div class="pad-t5"></div>
            <div style="display: inline-block; vertical-align: top; height: auto;">
                <div class="pad-t5"></div>
                <table class="adddeleterow table table-condensed table-no-border table-auto-width"
                    style="margin-bottom: 10px;">
                    <thead>
                         <tr>
                        </tr>
                    </thead>
<?php
    $count = count($services["windows_services"]);

    if ($count > 2) {
        $count--;
    }

    for ($increment_table = 0; $increment_table < $count; $increment_table++):
?>
                        <tr>
                            <td>
                                <label>
                                    <?= _('Service') ?>:
                                </label>
                                <input type="text" size="20" name="services[windows_services][<?= $increment_table ?>][service_name]"
                                    value="<?= isset($services['windows_services'][$increment_table]['service_name']) ? encode_form_val($services['windows_services'][$increment_table]['service_name']) : "" ?>"
                                    class="form-control condensed">
                            </td>
                            <td>
                                <label>
                                    <?= _('Display Name') ?>:
                                </label>
                                <input type="text" size="20" name="services[windows_services][<?= $increment_table ?>][display_name]"
                                    value="<?= isset($services['windows_services'][$increment_table]['display_name']) ? encode_form_val($services['windows_services'][$increment_table]['display_name']) : "" ?>"
                                    class="form-control condensed">
                            </td>
                            <td>
                                <label>
                                    <?= _('Expected State') ?>:
                                </label>
                                <select name="services[windows_services][<?= $increment_table ?>][expected_state]" id="expected_state"
                                    class="form-control condensed">
                                    <option value="Running"
                                        <?= is_selected($services["windows_services"][$increment_table]["expected_state"], "Running") ?>>
                                        <?= _('Running') ?></option>
                                    <option value="Stopped"
                                        <?= is_selected($services["windows_services"][$increment_table]["expected_state"], "Stopped") ?>>
                                        <?= _('Stopped') ?></option>
                                </select>
                            </td>
                        </tr>

                    <?php endfor; ?>
                </table>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="windows_processes" class="checkbox" name="services[windows_processes][monitor]"
                <?= is_checked(checkbox_binary($services["windows_processes"]["monitor"]), "1") ?>>
        </td>
        <td>
            <label class="normal" for="windows_processes">
                <b>
                    <?= _('Windows Processes') ?>
                </b><br>
                <?= _('Monitors Windows Processes.') ?>
            </label>
            <div class="pad-t5"></div>
            <div style="display: inline-block; vertical-align: top; height: auto;">
                <div class="pad-t5"></div>
                <table class="adddeleterow table table-condensed table-no-border table-auto-width"
                    style="margin-bottom: 10px;">
                    <thead>
                         <tr>
                        </tr>
                    </thead>
                    <script type="text/javascript">
                        // Overriding this function
                        var _old_wizard_add_row = wizard_add_row;

                        wizard_add_row = function (clickedelement) {
                            _old_wizard_add_row(clickedelement);

                            var table = $(clickedelement).prev()[0];


                            var $tr = $(table).find("tbody tr:last");

                            $tr.find("[id]").attr("id", function () {
                                var parts = this.id.match(/(\d+)/g);
                                return this.id.replace(/[\d]+/g, ++parts);
                            });

                            $tr.find("[onchange]").attr("onchange", function () {
                                var parts = this.getAttribute("onchange").match(/(\d+)/g);
                                return this.getAttribute("onchange").replace(/[\d]+/g, ++parts);
                            });


                        };

                        let rowCount = <?= count($services["windows_processes"]) ?>;

                        function toggleOutputTypeSelect(rowId) {
                            var metricSelect = document.getElementById("windows_processes_metric_" + rowId);
                            var outputTypeSelect = document.getElementById("windows_processes_outputType_" + rowId);
                            // if either null, return
                            if (!metricSelect || !outputTypeSelect) return;

                            if (metricSelect.value === "Memory") {
                                outputTypeSelect.style.display = "inline-block";
                                outputTypeSelect.style.opacity = 1;
                                outputTypeSelect.style.pointerEvents = "auto";
                            } else {
                                outputTypeSelect.style.opacity = 0;
                                outputTypeSelect.style.pointerEvents = "none";
                       
                                
                            }
                        }

                        function initializeOutputTypeSelect() {
                            for (var i = 0; i < rowCount; i++) {
                                toggleOutputTypeSelect(i);
                            }
                        }

                        window.addEventListener("load", initializeOutputTypeSelect);
                        $(document).on("click focus", ".wizard-add-row", function () {
                            initializeOutputTypeSelect();
                            rowCount++;
                        });

                        $(document).on("click focus", ".wizard-del-row", function () {
                            initializeOutputTypeSelect();
                            rowCount--;
                        });
                    </script>
<?php
    $count = count($services["windows_processes"]);

    if ($count > 2) {
        $count--;
    }

    for ($increment_table = 0; $increment_table < $count; $increment_table++):
?>
                        <tr>
                            <td><label>
                                    <?= _('Process') ?>:
                                </label> <input type="text" size="20"
                                    name="services[windows_processes][<?= $increment_table ?>][process_name]"
                                    value="<?= isset($services['windows_processes'][$increment_table]['process_name']) ? encode_form_val($services['windows_processes'][$increment_table]['process_name']) : "" ?>"
                                    class="form-control condensed"></td>
                            <td><label>
                                    <?= _('Display Name') ?>:
                                </label> <input type="text" size="20"
                                    name="services[windows_processes][<?= $increment_table ?>][display_name]"
                                    value="<?= isset($services['windows_processes'][$increment_table]['display_name']) ? encode_form_val($services['windows_processes'][$increment_table]['display_name']) : "" ?>"
                                    class="form-control condensed"></td>
                            <td>
                                <label>
                                    <?= _('Metric') ?>:
                                </label>
                                <select name="services[windows_processes][<?= $increment_table ?>][metric]"
                                    id="windows_processes_metric_<?= $increment_table ?>" class="form-control condensed"
                                    onchange="toggleOutputTypeSelect(<?= $increment_table ?>);">
                                    <option value="Memory" <?= is_selected($services["windows_processes"][$increment_table]["metric"], "Memory") ?>><?= _('Memory') ?></option>
                                    <option value="CPU" <?= is_selected($services["windows_processes"][$increment_table]["metric"], "CPU (%)") ?>><?= _('CPU (%)') ?></option>
                                    <option value="Count" <?= is_selected($services["windows_processes"][$increment_table]["metric"], "Count") ?>><?= _('Count') ?></option>
                                </select>
                                <select name="services[windows_processes][<?= $increment_table ?>][outputType]"
                                    id="windows_processes_outputType_<?= $increment_table ?>" class="form-control condensed" style="margin-right: 20px;"
                                    style="<?= ($services["windows_processes"][$increment_table]["metric"] == "Memory" ? "inline-block" : "none") ?>">
                                    <option value="MB" <?= is_selected($services["windows_processes"][$increment_table]["outputType"], "MB") ?>><?= _('MB') ?></option>
                                    <option value="GB" <?= is_selected($services["windows_processes"][$increment_table]["outputType"], "GB") ?>><?= _('GB') ?></option>
                                    <option value="KB" <?= is_selected($services["windows_processes"][$increment_table]["outputType"], "KB") ?>><?= _('KB') ?></option>
                                </select>
                                <label><img src="<?= theme_image('warning_small.png') ?>" class="tt-bind"
                                        title="<?= _('Warning Threshold') ?>"></label>
                                <input type="text" size="1" name="services[windows_processes][<?= $increment_table ?>][warning]"
                                    value="<?= encode_form_val($services['windows_processes'][$increment_table]['warning']) ?>"
                                    class="form-control condensed" id="windows_processes_warning_<?= $increment_table ?>">
                                <label><img src="<?= theme_image('critical_small.png') ?>" class="tt-bind"
                                        title="<?= _('Critical Threshold') ?>"></label>
                                <input type="text" size="1" name="services[windows_processes][<?= $increment_table ?>][critical]"
                                    value="<?= encode_form_val($services['windows_processes'][$increment_table]['critical']) ?>"
                                    class="form-control condensed" id="windows_processes_critical_<?= $increment_table ?>">
                            </td>
                        </tr>
                    <?php endfor; ?>
                </table>
            </div>
        </td>

    </tr>

</table>