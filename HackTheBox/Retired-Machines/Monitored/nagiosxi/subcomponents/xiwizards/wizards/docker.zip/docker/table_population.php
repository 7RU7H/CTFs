<?php
//
// Docker Config Wizard
// Copyright (c) 2018-2021 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

// Initialization stuff
pre_init();
init_session();

// Grab GET or POST variables and check pre-reqs
grab_request_vars();
check_prereqs();
check_authentication(false);

$mode = grab_request_var('mode', 'containers');
if (!in_array($mode, array('containers', 'networks'))) {
	$mode = 'containers';
}

$objects = array();

$cert = escapeshellarg(grab_request_var('cert', ''));
if (!empty($cert) && $cert !== "''") {
	$cert = " --cert=" . escapeshellarg($cert); 
}
else {
	$cert = "";
}

$key = escapeshellarg(grab_request_var('key', ''));
if (!empty($key) && $key !== "''") {
	$key = " --key=" . escapeshellarg($key); 
}
else {
	$key = "";
}

$cacert = escapeshellarg(grab_request_var('cacert', ''));
if (!empty($cacert) && $cacert !== "''") {
	$cacert = " --cacert=" . escapeshellarg($cacert); 
}
else {
	$cacert = "";
}

$host_addr = grab_request_var('host', '');

if (!$host_addr) {
	echo json_encode("error_host");
	exit();
}
if (substr($host_addr, -1) !== '/') {
	$host_addr .= '/';
}


// validate URL.
// The base URL can be either a normal URL (like 'http://192.168.0.160:4243/')
// or a socket URI (like 'http:/v1.30/')
$url = parse_url($host_addr);

// parse_url() treats socket URIs as though they only have a scheme and path, so we can make sure the others don't exist.
$non_socket_keys = array(
	'host' => 1,
	'port' => 1,
	'user' => 1,
	'pass' => 1,
	'query' => 1,
	'fragment' => 1
);
$socket_baseurl_intersection = array_intersect_key($url, $non_socket_keys);
$is_socket_baseurl = empty($socket_baseurl_intersection);

$reconstructed_url = '';
if ($is_socket_baseurl)
{
	// socket URIs are very unlikely to be malicious, so we don't need to do any stricter validation
	$reconstructed_url = $host_addr;
}
else {
	// Normal URLs should not have paths, queries, and fragments included.
	// (we supply the paths later in this script)

	if (isset($url['scheme'])) {
		$reconstructed_url .= $url['scheme'] . '://';
	}
	if (isset($url['user'])) {
		$reconstructed_url .= $url['user'];
	}
	if (isset($url['pass'])) {
		$reconstructed_url .= ':' . $url['pass'];
	}
	if (isset($url['user']) || isset($url['pass']))
	{
		$reconstructed_url .= "@";
	}
	if (isset($url['host'])) {
		$reconstructed_url .= $url['host'];
	}
	if (isset($url['port'])) {
		$reconstructed_url .= ':' . $url['port'];
	}
	$reconstructed_url .= '/';
}


if ($mode === 'containers')
	$mode .= '/json';
else 
	$mode .= '/';

$reconstructed_url .= $mode . '?all=true';
$reconstructed_url = escapeshellarg($reconstructed_url);

$cmd = 'curl --connect-timeout 10 ' . $reconstructed_url . ' -g ' . $cert . $key . $cacert;
$output = array();
$ret = 0;
exec($cmd, $output, $ret);

if ($ret > 0) {
	echo json_encode("error_curl");
	exit();
}

$output = implode("\n", $output);

$output = json_decode($output, true);

if (isset($output['message'])) {
	$output['cmd'] = $cmd;
	echo json_encode($output);
	exit();
}

foreach($output as $item) {

	preg_replace("/[^a-f0-9]/", '', $item['Id']);
	$name_or_id = $item['Id'];

	if (array_key_exists('Names', $item) && is_array($item['Names'])) {
		preg_replace("/[^a-z_]/", '', $item['Names'][0]);
		$name_or_id = $item['Names'][0];
	}
	else if (array_key_exists('Name', $item)) {
		preg_replace("/[^a-z_]/", '', $item['Name']);
		$name_or_id = $item['Name'];	
	}

	$objects[] = $name_or_id;
}

echo json_encode($objects);

exit();