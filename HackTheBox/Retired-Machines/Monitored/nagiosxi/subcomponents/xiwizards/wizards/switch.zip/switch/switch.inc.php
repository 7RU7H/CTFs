<?php
//
// Switch/Router Config Wizard
// Copyright (c) 2008-2022 - Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

switch_configwizard_init();
function switch_configwizard_init()
{
    $name = "switch";
    $args = array(
        CONFIGWIZARD_NAME =>               $name,
        CONFIGWIZARD_VERSION =>            "2.6.1",
        CONFIGWIZARD_TYPE =>               CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION =>        _("Monitor a network switch or router."),
        CONFIGWIZARD_DISPLAYTITLE =>       _("Network Switch / Router"),
        CONFIGWIZARD_FUNCTION =>           "switch_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE =>       "switch.png",
        CONFIGWIZARD_FILTER_GROUPS =>      array('network'),
        CONFIGWIZARD_REQUIRES_VERSION =>   530
    );
    register_configwizard($name, $args);
}

/**
 *
 * Generates the instructions to be passed to the command line to generate an MRTG configuration.
 *
 * @param $snmpopts     Array - Given by the getstage1html
 * @param $address      String - Address of the network device
 * @param $port         Integer - Port of the network device
 * @param $snmpversion  String - Must be either 1, 2, 3
 * @param $defaultspeed String - If nothing is returned by ifSpeed, use this value (in Mbps)
 *
 * @return String - String to be executed
 */
function switch_configwizard_get_cfgmaker_cmd($snmpopts, $address, $port, $snmpversion = "1", $defaultspeed = 100, $admindown)
{
    $snmpversion = (in_array($snmpversion, array("1", "2c", "3")) ? $snmpversion : "1");

    $cmd = "/usr/bin/cfgmaker ";
    // If user wants to scan administratively down interfaces
    if ($admindown == "on") {
        $args[] = "--no-down";
    } else {
        $args[] = "--show-op-down";
    }
    $args[] = "--noreversedns";
    $args[] = "--if-template=/usr/local/nagiosxi/html/includes/configwizards/switch/template";
    $args[] = "--zero-speed";
    $args[] = escapeshellarg($defaultspeed * 1000000);
    $opts = !empty($port) ? ":".intval($port)."::::" : ":::::";

    if (empty($snmpopts['v3_username'])) {

        // Run SNMPv1, SNMPv2, SNMPv2c code here
        $username = $snmpopts['snmpcommunity'];

        $args[] = escapeshellarg("{$username}@{$address}{$opts}" . (int) $snmpversion);

        file_put_contents("/tmp/bs", escapeshellarg("{$username}@{$address}{$opts}" . (int) $snmpversion));

    } else {

        // Run SNMPv3 code here
        $opts .= 3;
        $args[] = "--enablesnmpv3";
        $args[] = "--snmp-options=$opts";

        if (!empty($snmpopts['v3_username']))
            $args[] = "--username=" . escapeshellarg($snmpopts['v3_username']);
        
        if (!empty($snmpopts['v3_auth_password'])) {
            $args[] = "--authprotocol=" . escapeshellarg(strtolower($snmpopts['v3_auth_proto']));
            $args[] = "--authpassword=" . escapeshellarg($snmpopts['v3_auth_password']);
        }

        if (!empty($snmpopts['v3_priv_password'])) {
            $args[] = "--privprotocol=" . escapeshellarg(strtolower($snmpopts['v3_priv_proto']));
            $args[] = "--privpassword=" . escapeshellarg($snmpopts['v3_priv_password']);
        }

        $args[] = "--contextengineid=0";
        $args[] = escapeshellarg($address);
    }

    $cmd .= implode(' ', $args);

    // Run the cfgmaker through the user macros
    $cmd = nagiosccm_replace_user_macros($cmd);
    debug('the command is ' . $cmd);
    return $cmd;
}


/**
 *
 * Main configwizard driver function
 *
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function switch_configwizard_func($mode = "", $inargs = null, &$outargs, &$result)
{
    global $cfg;
    $wizard_name = "switch";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {

        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            $address = grab_array_var($inargs, "ip_address", "");
            $address_port = grab_array_var($inargs, "port", 161);

            $snmpversion = grab_array_var($inargs, "snmpversion", "2c");
            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if (!empty($snmpopts_serial)) {
                $snmpopts = json_decode(base64_decode($snmpopts_serial), true);
            } else {
                // Set the defaults if nothing is set yet
                $snmpopts_default = array(
                    "snmpcommunity" => "public",
                    "v3_security_level" => "",
                    "v3_username" => "",
                    "v3_auth_password" => "",
                    "v3_priv_password" => "",
                    "v3_auth_proto" => "",
                    "v3_priv_proto" => ""
                );
                $snmpopts = grab_array_var($inargs, "snmpopts", $snmpopts_default);
            }
            $portnames = grab_array_var($inargs, "portnames", "number", "alias");
            $scaninterfaces = grab_array_var($inargs, "scaninterfaces", "on");
            $default_port_speed = grab_array_var($inargs, "default_port_speed", 100);
            $bulk_options = grab_array_var($inargs, 'bulk_options', '');
            $bulk_fields_serial = grab_array_var($inargs, 'bulk_fields_serial', base64_encode(json_encode(array())));
            $bulk_fields_serial = json_decode(base64_decode($bulk_fields_serial), true);
            $bulk_fields = grab_array_var($inargs, 'bulk_fields', $bulk_fields_serial);
            $warn_speed_in_percent = grab_array_var($inargs, "warn_speed_in_percent", 50);
            $warn_speed_out_percent = grab_array_var($inargs, "warn_speed_out_percent", 50);
            $crit_speed_in_percent = grab_array_var($inargs, "crit_speed_in_percent", 80);
            $crit_speed_out_percent = grab_array_var($inargs, "crit_speed_out_percent", 80);
        	$admindown = grab_array_var($inargs, "admindown", "on");

            $bulk_options = grab_array_var($inargs, 'bulk_options', '');

            $xisys = $cfg['root_dir'] . '/var/xi-sys.cfg';
            $ini = parse_ini_file($xisys);

            $des_option = '';
            if ($ini['dist'] != "el9" && $ini['dist'] != "ubuntu22") {
                $des_option = '<option value="DES" ' . is_selected($snmpopts["v3_priv_proto"], "DES") . '>DES</option>';
            }

            $output = '
<script type="text/javascript">
    $(document).ready(function() {
        $("#tabs").tabs();
        // Upon clicking the tabs, set the invisible radio selector
        // to be true, based on the tab clicked
        $("#selectv1").click(function() {
            $("#snmpversion").val("1");
        });
        $("#selectv2c").click(function() {
            $("#snmpversion").val("2c");
        });
        $("#selectv3").click(function() {
            $("#snmpversion").val("3");
        });
        $("#selectv' . $snmpversion . '").click();
        // End of above commented section

        // On page load, determine which snmp version is selected, 
        // and populate the Bulk Configuration fields accordingly
        set_bulk_config_fields();

        $("#selectv1, #selectv2c, #selectv3").click(function () {
            $("#bulk-append-fields").find(".bulk-remove-me").remove();
            $("#bulk-append-headers").find(".bulk-remove-me").remove();

            set_bulk_config_fields();
        });

        // Then, if the back button was pressed, select the fields that were chosen last time()
        var backpop_array = [\''.implode("','", $bulk_fields).'\'];
        var fields = $("select[name*=\"bulk_fields[]\"");
        console.log(backpop_array);
        console.log(fields);

        // backpop_array will be an array of the empty string if "Next" was pressed
        if (backpop_array.length > 1) {

            for (x in backpop_array) {
                $(fields[x]).val(backpop_array[x]);
            }
        }

        security_level = $(".form-control[name=\"snmpopts[v3_security_level]\"]").val();
        enable_fields_by_security_level(security_level);
        $(".form-control[name=\"snmpopts[v3_security_level]\"]").change(function () {
            enable_fields_by_security_level($(this).val());
        });
    });

function set_bulk_config_fields() {

    var new_fields = $("#sample-fields-v12c");
    var new_headers = $("#sample-headers-v12c");
    if ($("#snmpversion").val() === "3") {
        // version 3
        new_fields = $("#sample-fields-v3");
        new_headers = $("#sample-headers-v3");
    }
    new_fields.children("select").children("option").each(function() {
        // Let the user select each non-empty field once if they choose
        if ($(this).val() === "") {
            return;
        }

        $("#bulk-append-fields").append("<td class=\'bulk-remove-me\'>" + new_fields.html() + "</td>");
    });
    $("#bulk-append-headers").append(new_headers.html());
}

function enable_fields_by_security_level(level) {
    $("." + level + "-enable").attr("disabled", false);
    $("." + level + "-disable").attr("disabled", true);
}
</script>

<input type="hidden" id="backloaded-fields" value="'.$bulk_fields.'">
<h5 class="ul">' . _('Router/Switch Information') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>' . _("IP Address") . ':</label>
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="' . encode_form_val($address) . '" class="form-control">
            <div class="subtext">' . _("The IP address of the network device you'd like to monitor") . '</div>
        </td>
    </tr>
    <tr>
        <td valign="top">
            <label>'._("Port").':</label>
        </td>
        <td>
            <input type="text" size="6" name="port" id="port" value="'.encode_form_val($address_port).'" class="form-control">
            <div class="subtext">'._("The port of the network device").'</div>
        </td>
    </tr>
</table>
<input type="hidden" name="snmpversion" id="snmpversion" value="' . encode_form_val($snmpversion) . '">

<div id="tabs" style="width: 600px;">
    <ul>
        <li><a href="#snmpv2" id="selectv1">SNMPv1</a></li>
        <li><a href="#snmpv2" id="selectv2c">SNMPv2c</a></li>
        <li><a href="#snmpv3" id="selectv3">SNMPv3</a></li>
    </ul>
    <div id="snmpv2">
        <table class="table table-condensed table-no-border table-auto-width" style="margin: 0;">
            <tr>
                <td class="vt">
                    <label>' . _("SNMP Community") . ':</label>
                </td>
                <td>
                    <input type="text" size="20" name="snmpopts[snmpcommunity]" value="' . encode_form_val($snmpopts['snmpcommunity']) . '" class="form-control">
                    <div class="subtext">' . _("The SNMP community string required used to to query the network device") . '</div>
                </td>
            </tr>
        </table>
    </div> <!-- Closes #snmpv2 -->

    <div id="snmpv3">
        <p>' . _("When using SNMP v3 you must specify authentication information") . '.</p>

        <table class="table table-condensed table-no-border table-auto-width" style="margin: 0;">
            <tr>
                <td>
                    <label>' . _("Security Level") . ':</label>
                </td>
                <td>
                    <select name="snmpopts[v3_security_level]" class="form-control">
                        <option value="authPriv" ' . is_selected($snmpopts["v3_security_level"], "authPriv") . '>authPriv</option>
                        <option value="authNoPriv" ' . is_selected($snmpopts["v3_security_level"], "authNoPriv") . '>authNoPriv</option>
                        <option value="noAuthNoPriv" ' . is_selected($snmpopts["v3_security_level"], "noAuthNoPriv") . '>noAuthNoPriv</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    <label>' . _("Username") . ':</label>
                </td>
                <td>
                    <input type="text" size="20" name="snmpopts[v3_username]" value="' . encode_form_val($snmpopts["v3_username"]) . '" class="form-control">
                </td>
            </tr>
            <tr>
                <td>
                    <label>' . _("Authentication Password") . ':</label>
                </td>
                <td>
                    <input type="text" size="20" name="snmpopts[v3_auth_password]" value="' . $snmpopts["v3_auth_password"] . '" class="form-control authPriv-enable authNoPriv-enable noAuthNoPriv-disable">
                </td>
            </tr>
            <tr>
                <td>
                    <label>' . _("Authentication Protocol") . ':</label>
                </td>
                <td>
                    <select name="snmpopts[v3_auth_proto]" class="form-control authPriv-enable authNoPriv-enable noAuthNoPriv-disable">
                        <option value="MD5" ' . is_selected($snmpopts["v3_auth_proto"], "MD5") . '>MD5</option>
                        <option value="SHA" ' . is_selected($snmpopts["v3_auth_proto"], "SHA") . '>SHA</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    <label>' . _("Privacy Password") . ':</label>
                </td>
                <td>
                    <input type="text" size="20" name="snmpopts[v3_priv_password]" value="' . $snmpopts["v3_priv_password"] . '" class="form-control authPriv-enable authNoPriv-disable noAuthNoPriv-disable">
                </td>
            </tr>
            <tr>
                <td>
                    <label>' . _("Privacy Protocol") . ':</label>
                </td>
                <td>
                    <select name="snmpopts[v3_priv_proto]" class="form-control authPriv-enable authNoPriv-disable noAuthNoPriv-disable">
                        <option value="AES" ' . is_selected($snmpopts["v3_priv_proto"], "AES") . '>AES128</option>
                        ' . $des_option . '
                    </select>
                </td>
            </tr>
        </table>
    </div> <!-- Closes #snmpv3 -->
</div> <!-- Closes #tabs -->

<h5 class="ul">' . _("Monitoring Options") . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label for="portnames">' . _("Monitor Using:") . '</label>
        </td>
        <td>
            <select name="portnames" class="form-control">
                <option value="number" ' . is_selected($portnames, "number") . '>' . _("Port's Number") . '</option>
                <option value="name" ' . is_selected($portnames, "name") . '>' . _("Port's Name") . '</option>
                <option value="description" ' . is_selected($portnames, "description") . '>' . _("Port's Description") . '</option>
                <option value="alias" ' . is_selected($portnames, "alias") . '>' . _("Port's Alias") . '</option>
            </select>
            <div class="subtext">' . _("Select the port naming scheme that should be used. ") . '</div>
        </td>
    </tr>
    <tr>
        <td>
            <label for="scaninterfaces">' . _("Scan Interfaces") . '</label>
        </td>
        <td class="checkbox">
            <label><input name="scaninterfaces" type="checkbox" ' . is_checked($scaninterfaces, "on") . '> ' . _("Scan the switch or router to auto-detect interfaces that can be monitored for link up/down status and bandwidth usage.
The scanning process may take several seconds to complete.") . '</label>
        </td>
    </tr>
    <tr>
        <td>
            <label for="admindown">' . _("Administratively Down Interfaces") . '</label>
        </td>
        <td class="checkbox">
            <label><input name="admindown" type="checkbox" ' . is_checked($admindown) . '> ' . _("Scan the switch or router to add Administratively Down Interfaces interfaces that can be monitored for link up/down status and bandwidth usage.") . '</label>
        </td>
    </tr>
</table>

<h5 class="ul">'. _("Bulk Configuration") .'</h5>
<p>'._('If you have many devices with the same port bandwidth and desired alerting thresholds, you may paste their configuration as a CSV in the space below. The "ip_address" is required, but you may also include columns for "hostname", "snmpcommunity", "v3_security_level", "v3_username", "v3_auth_password", "v3_priv_password", "v3_auth_proto", and/or "v3_priv_proto".').'</p>

<table class="table table-condensed table-no-border">
    <tbody>
        <tr>
            <td class="vt" style="width: 60px;">
                <label>'._("Fields:").'</label>
            </td>
            <td>
                <table class="table table-condensed table-no-border table-auto-width table-no-padding">
                    <tbody>
                        <tr id="bulk-append-headers">
                            <th>'._('Field 1').'</th>
                        </tr>
                        <tr id="bulk-append-fields">
                            <td>
                                <select class="form-control" name="bulk_fields[]">
                                    <option value="ip_address">'._("IP Address").'</option>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td class="vt">
                <label>'._("Data:").'</label>
            </td>
            <td>
                <textarea class="form-control" style="min-height: 100px; min-width: 300px; width: 30%; margin-left: 5px; padding: 6px;" name="bulk_options">'.$bulk_options.'</textarea>
            </td>
        </tr>
    </tbody>
</table>

<div id="sample-fields-v12c" class="hide">
    <select class="form-control bulk-remove-me" name="bulk_fields[]">
        <option value="">'._('IGNORE').'</option>
        <option value="hostname">'._("Hostname").'</option>
        <option value="snmpcommunity">'._('SNMP Community').'</option>
    </select>
</div>

<table class="hide">
    <tbody class="hide">
        <tr class="hide" id="sample-headers-v12c">
            <th class="bulk-remove-me">'._('Field 2').'</th>
            <th class="bulk-remove-me">'._('Field 3').'</th>
        </tr>
    </tbody>
</table>

<div id="sample-fields-v3" class="hide">
    <select class="form-control bulk-remove-me" name="bulk_fields[]">
        <option value="">'._('IGNORE').'</option>
        <option value="hostname">'._("Hostname").'</option>
        <option value="v3_username">'._('Username').'</option>
        <option value="v3_auth_password">'._('Auth Password').'</option>
        <option value="v3_priv_password">'._('Priv Password').'</option>
        <option value="v3_auth_proto">'._('Auth Protocol').'</option>
        <option value="v3_priv_proto">'._('Priv Protocol').'</option>
    </select>
</div>

<table class="hide">
    <tbody class="hide">
        <tr class="hide" id="sample-headers-v3">
            <th class="bulk-remove-me">'._('Field 2').'</th>
            <th class="bulk-remove-me">'._('Field 3').'</th>
            <th class="bulk-remove-me">'._('Field 4').'</th>
            <th class="bulk-remove-me">'._('Field 5').'</th>
            <th class="bulk-remove-me">'._('Field 6').'</th>
            <th class="bulk-remove-me">'._('Field 7').'</th>
        </tr>
    </tr>
</table>

<h5 class="ul">' . _("Default Values") . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label for="warn_speed_in_percent"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"> ' . _("Input Rate") . ':</label>
        </td>
        <td>
            <input class="form-control" type="text" value="' . $warn_speed_in_percent . '" name="warn_speed_in_percent" size="2"> %
        </td>
        <td>
            <label for="crit_speed_in_percent"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"> ' . _("Input Rate") . ':</label>
        </td>
        <td>
            <input class="form-control" type="text" value="' . $crit_speed_in_percent . '" name="crit_speed_in_percent" size="2"> %
        </td>
    </tr>
    <tr>
        <td>
            <label for="warn_speed_in_percent"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"> ' . _("Output Rate") . ':</label>
        </td>
        <td>
            <input class="form-control" type="text" value="' . $warn_speed_out_percent . '" name="warn_speed_out_percent" size="2"> %
        </td>
        <td>
            <label for="crit_speed_in_percent"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"> ' . _("Output Rate") . ':</label>
        </td>
        <td>
            <input class="form-control" type="text" value="' . $crit_speed_out_percent . '" name="crit_speed_out_percent" size="2"> %
        </td>
    </tr>
    <tr>
        <td>
            <label for="default_port_speed">' . _("Default Port Speed") . ':</label>
        </td>
        <td>
            <input type="text" value="' . $default_port_speed . '" name="default_port_speed" size="6" class="form-control"> Mbps
        </td>
    </tr>
</table>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $address_port = grab_array_var($inargs, "port", 161);
            $address = nagiosccm_replace_user_macros($address);
            $address_port = nagiosccm_replace_user_macros($address_port);

            $snmpopts = grab_array_var($inargs, "snmpopts", array());
            $scaninterfaces = grab_array_var($inargs, "scaninterfaces");
            $admindown = grab_array_var($inargs, "admindown");
            $bulk_options = grab_array_var($inargs, "bulk_options", '');
            $bulk_fields_serial = grab_array_var($inargs, 'bulk_fields_serial', '');
            if (!empty($bulk_fields_serial)) {
                $bulk_fields = json_decode(base64_decode($bulk_fields_serial), true);
            }
            else {
                $bulk_fields_default = array(
                    'ip_address',
                );
                $bulk_fields = grab_array_var($inargs, 'bulk_fields', $bulk_fields_default);
                $bulk_fields_serial = base64_encode(json_encode($bulk_fields));
            }
            $snmpversion = grab_array_var($inargs, "snmpversion", "2c");
            $default_port_speed = grab_array_var($inargs, "default_port_speed", 100);
            $errors = 0;
            $errmsg = array();

            // Do error checking
            if (have_value($address) == false) {
                $errmsg[$errors++] = _("No address specified.");
            } else if (!valid_ip($address)) {
                $errmsg[$errors++] = _("Invalid IP address.");
            } else if (empty($snmpopts['snmpcommunity']) && empty($snmpopts['v3_username'])) {
                $errmsg[$errors++] = _("Must give either community or username.");
            }
            
            // check passwords for bad characters (! and ;)
            // if (!empty($snmpopts["v3_auth_password"])) {
            //     if (strpos($snmpopts["v3_auth_password"], '!') || strpos($snmpopts["v3_auth_password"], ';')) {
            //         $errmsg[$errors++] = _("You cannot use '!' or ';' characters in authentification password field.");
            //     }
            // }

            // if (!empty($snmpopts["v3_priv_password"])) {
            //     if (strpos($snmpopts["v3_priv_password"], '!') || strpos($snmpopts["v3_priv_password"], ';')) {
            //         $errmsg[$errors++] = _("You cannot use '!' or ';' characters in priveleged password field.");
            //     }
            // }

            // Error results
            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            // If user wants to scan interfaces, immediately launch the command and start working on it....
            if ($scaninterfaces == "on") {

                $outfile = switch_configwizard_get_walk_file($address);
                $donefile = $outfile . ".done";

                // Get rid of old "done" file if it exists
                if (file_exists($donefile)) {
                    unlink($donefile);
                }

                // launch cfgmaker command to scan for ports
                $cfgmaker_cmd = switch_configwizard_get_cfgmaker_cmd($snmpopts, $address, $address_port, $snmpversion, $default_port_speed, $admindown);
                $cmd = $cfgmaker_cmd . " > " . escapeshellarg($outfile) . " ; touch " . escapeshellarg($donefile) . " > /dev/null &";
                exec($cmd);
                debug('outfile ' . $outfile);
            }
            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $address_port = grab_array_var($inargs, "port", 161);
            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if (!empty($snmpopts_serial)) {
                $snmpopts = json_decode(base64_decode($snmpopts_serial), true);
            } else {
                $snmpopts_default = array(
                    "snmpcommunity" => "public",
                    "v3_security_level" => "",
                    "v3_username" => "",
                    "v3_auth_password" => "",
                    "v3_priv_password" => "",
                    "v3_auth_proto" => "md5",
                    "v3_priv_proto" => "des"
                );
                $snmpopts = grab_array_var($inargs, "snmpopts", $snmpopts_default);
                $snmpopts_serial = base64_encode(json_encode($snmpopts));
            }
            $vendor = grab_array_var($inargs, "vendor", "");
            $portnames = grab_array_var($inargs, "portnames");
            $scaninterfaces = grab_array_var($inargs, "scaninterfaces");
            $admindown = grab_array_var($inargs, "admindown");

            $bulk_options = grab_array_var($inargs, 'bulk_options', '');
            $bulk_fields_serial = grab_array_var($inargs, 'bulk_fields_serial', '');
            if (!empty($bulk_fields_serial)) {
                $bulk_fields = json_decode(base64_decode($bulk_fields_serial), true);
            }
            else {
                $bulk_fields_default = array(
                    'ip_address', 'hostname'
                );
                $bulk_fields = grab_array_var($inargs, 'bulk_fields', $bulk_fields_default);
                $bulk_fields_serial = base64_encode(json_encode($bulk_fields));
            }
            $snmpversion = grab_array_var($inargs, "snmpversion", "2c");
            $default_port_speed = grab_array_var($inargs, "default_port_speed", 100);
            $warn_speed_in_percent = grab_array_var($inargs, "warn_speed_in_percent", 50);
            $warn_speed_out_percent = grab_array_var($inargs, "warn_speed_out_percent", 50);
            $crit_speed_in_percent = grab_array_var($inargs, "crit_speed_in_percent", 80);
            $crit_speed_out_percent = grab_array_var($inargs, "crit_speed_out_percent", 80);
            $hostname = @gethostbyaddr($address);

            // Array for removal of illegal chars in port meta data -SW
            $badchars = explode(" ", "; ` ~ ! $ % ^ & * | ' \" < > ? , ( ) = \\ { } [ ]");

            $output .= '
<input type="hidden" name="snmpversion" value="' . encode_form_val($snmpversion) . '">
<input type="hidden" name="ip_address" value="' . encode_form_val($address) . '">
<input type="hidden" name="port" value="' . encode_form_val($address_port) . '">
<input type="hidden" name="vendor" value="' . encode_form_val($vendor) . '">';
            foreach ($snmpopts as $key => $val) {
                $output .='
<input type="hidden" name="snmpopts['.$key.']" value="' . $val . '">';
            }
            $output .='
<input type="hidden" name="snmpopts_serial" value="' . $snmpopts_serial . '">
<input type="hidden" name="portnames" value="' . encode_form_val($portnames) . '">
<input type="hidden" name="scaninterfaces" value="' . encode_form_val($scaninterfaces) . '">
<input type="hidden" name="admindown" value="' . encode_form_val($admindown) . '">
<input type="hidden" name="bulk_options" value="' . encode_form_val($bulk_options) . '">
<input type="hidden" name="bulk_fields_serial" value="'.$bulk_fields_serial.'">
<input type="hidden" name="warn_speed_in_percent" value="' . encode_form_val($warn_speed_in_percent) . '">
<input type="hidden" name="crit_speed_in_percent" value="' . encode_form_val($crit_speed_in_percent) . '">
<input type="hidden" name="warn_speed_out_percent" value="' . encode_form_val($warn_speed_out_percent) . '">
<input type="hidden" name="crit_speed_out_percent" value="' . encode_form_val($crit_speed_out_percent) . '">


<h5 class="ul">' . _('Switch Details') . '</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>' . _('Switch/Router Address') . ':</label>
        </td>
        <td>
            <input type="text" size="20" name="ip_address" id="ip_address" value="' . encode_form_val($address) . '" class="form-control" disabled>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>' . _('Host Name:') . '</label>
        </td>
        <td>
            <input type="text" size="20" name="hostname" id="hostname" value="' . encode_form_val($hostname) . '" class="form-control">
            <div class="subtext">' . _("The name you'd like to have associated with this switch or router.") . '</div>
        </td>
    </tr>
</table>

<h5 class="ul">' . _('Services') . '</h5>
<p>' . _("Specify which services you'd like to monitor for the switch or router.") . '</p>
<table class="table table-no-border table-auto-width">
    <tr>
        <td>
            <input type="checkbox" id="p" class="checkbox" id="ping" name="services[ping]" checked>
        </td>
        <td>
            <label class="normal" for="p">
                <b>' . _('Ping') . '</b><br>
                ' . _('Monitors the switch/router with an ICMP ping.  Useful for watching network latency and general uptime.') . '
            </label>
        </td>
    </tr>
</table>';

                $ports = switch_configwizard_read_walk_file($address);
                $output .= '
<h5 class="ul">' . _('Bandwidth and Port Status') . '</h5>

<script type="text/javascript">
//check all ports 
var allChecked=false;
function switchCheckAll()
{
    $(".portbox:checkbox").each(function() { 
      this.checked = "checked";
    });
}
function switchUncheckAll()
{
    $(".portbox:checkbox").each(function() { 
      this.checked = "";
    });
}
function bandwidthCheckAll()
{
    $(".bandwidthbox:checkbox").each(function() {
      this.checked = "checked";
    });
}
function bandwidthUncheckAll()
{
    $(".bandwidthbox:checkbox").each(function() { 
      this.checked = "";
    });
}
function statusCheckAll()
{
    $(".statusbox:checkbox").each(function() { 
      this.checked = "checked";
    });
}   
function statusUncheckAll()
{
    $(".statusbox:checkbox").each(function() { 
      this.checked = "";
    });
}
</script>
<style>
table.bandwidth td {
    padding: 0 1px;
}
</style>
';

                if (count($ports) > 0) {

                    // we need to double check for duplcate names before we go any further
                    foreach ($ports as $outer_number => $outer_arr) {
                        $outer_name = grab_array_var($outer_arr, "name");
                        $outer_description = grab_array_var($outer_arr, "description");
                        $outer_alias = grab_array_var($outer_arr, "alias");

                        $name_match = 1;
                        $description_match = 1;
                        $alias_match = 1;

                        foreach ($ports as $inner_number => $inner_arr) {
                            if ($outer_number === $inner_number)
                                continue;

                            $inner_name = grab_array_var($inner_arr, "name");
                            $inner_description = grab_array_var($inner_arr, "description");
                            $inner_alias = grab_array_var($inner_arr, "alias");

                            if ($outer_name == $inner_name) {
                                $ports[$outer_number]['name'] = $outer_name . ' ' . $name_match++;
                                $ports[$inner_number]['name'] = $inner_name . ' ' . $name_match++;
                            }

                            if ($outer_description == $inner_description) {
                                $ports[$outer_number]['description'] = $outer_description . ' ' . $description_match++;
                                $ports[$inner_number]['description'] = $inner_description . ' ' . $description_match++;
                            }
                            
                            if ($outer_alias == $inner_alias) {
                                $ports[$outer_number]['alias'] = $outer_alias . ' ' . $alias_match++;
                                $ports[$inner_number]['alias'] = $inner_alias . ' ' . $alias_match++;
                            }
                        }
                    }

                    debug($ports);

                    $output .= '
                    <p>' . _("Select the ports for which you'd like to monitor bandwidth and port status.  You may specify an optional port name to be associated with specific ports.") . '</p>

                    <table class="table table-condensed table-hover table-striped table-bordered table-auto-width">
                        <thead>
                            <tr>
                                <th>' . _('Port') . '<br>
                                    <a href="javascript:void(0);" onclick="switchCheckAll()" title="' . _('Check All Ports') . '">' . _('Check') . '</a> /
                                    <a href="javascript:void(0);" onclick="switchUncheckAll()" title="' . _('Uncheck All Ports') . '">' . _('Uncheck') . '</a>
                                </th>
                                <th style="vertical-align: top;">
                                    ' . _('Port Name') . '<br>
                                </th>
                                <th style="vertical-align: top;">
                                    ' . _('Port Description') . '<br>
                                </th>
                <th style="vertical-align: top;">
                                    ' . _('Port Alias') . '<br>
                                </th>
                                <th style="vertical-align: top;">
                                    ' . _('Max Speed') . '
                                </th>
                                <th style="vertical-align: top;">
                                    ' . _('Service Description') . '
                                </th>
                                <th>
                                    ' . _('Bandwidth') . '<br><a href="javascript:void(0);" onclick="bandwidthCheckAll()" title="' . _('Check All Ports') . '">' . _('Check') . '</a> /
                                    <a href="javascript:void(0);" onclick="bandwidthUncheckAll()" title="' . _('Uncheck All Ports') . '">' . _('Uncheck') . '</a>
                                </th>
                                <th>
                                    ' . _('Port Status') . '<br><a href="javascript:void(0);" onclick="statusCheckAll()" title="' . _('Check All Ports') . '">' . _('Check') . '</a> /
                                    <a href="javascript:void(0);" onclick="statusUncheckAll()" title="' . _('Uncheck All Ports') . '">' . _('Uncheck') . '</a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>';

                    $x = 0;
                    foreach ($ports as $port_number => $parr) {

                        $max_bytes = grab_array_var($parr, "max_bytes", 0);
                        $port_name = grab_array_var($parr, "name", $port_number);
                        $port_description = grab_array_var($parr, "description", $port_number);
                        $port_alias = grab_array_var($parr, "alias", $port_number);

                        $port_number = str_replace($badchars, " ", $port_number);
                        $port_name = str_replace($badchars, " ", $port_name);
                        $port_description = str_replace($badchars, " ", $port_description);
                        $port_alias = str_replace($badchars, " ", $port_alias);

                        $service_description = _('Port ') . $port_number;

                        if ($portnames == 'name')
                            $service_description = $port_name;

                        if ($portnames == 'description')
                            $service_description = $port_description;
                        
                        if ($portnames == 'alias')
                            $service_description = $port_alias;

                        $x++;

                        $max_speed = switch_configwizard_get_readable_port_line_speed($max_bytes, $speed, $label);
                        $warn_in_speed =  ($speed * ($warn_speed_in_percent  / 100));
                        $warn_out_speed = ($speed * ($warn_speed_out_percent / 100));
                        $crit_in_speed =  ($speed * ($crit_speed_in_percent  / 100));
                        $crit_out_speed = ($speed * ($crit_speed_out_percent / 100));

                        // Possible refomat speed values/labels
                        switch_configwizard_recalculate_speeds($warn_in_speed, $warn_out_speed, $crit_in_speed, $crit_out_speed, $label);

                        // configure the display rates so that they fit in the text boxes (which are size=3)
                        $warn_in =  switch_configwizard_get_sane_display_rate($warn_in_speed);
                        $warn_out = switch_configwizard_get_sane_display_rate($warn_out_speed);
                        $crit_in =  switch_configwizard_get_sane_display_rate($crit_in_speed);
                        $crit_out = switch_configwizard_get_sane_display_rate($crit_out_speed);

                        $output .= '
    <tr>
        <td class="checkbox">
            <label>
                <input type="checkbox" class="portbox" id="port_' . $port_number . '" name="services[port][' . $port_number . ']" checked>
                ' . _('Port ') . $port_number . '
            </label>
        </td>
        <td>
            ' . encode_form_val($port_name) . '
        </td>
        <td>
            ' . encode_form_val($port_description) . '
        </td>
        <td>
            ' . encode_form_val($port_alias) . '
        </td>
        <td>
            ' . $max_speed . '
        </td>
        <td>
            <input type="text" size="16" name="serviceargs[portname][' . $port_number . ']" 
                value="' . encode_form_val($service_description) . '" class="form-control">
        </td>
        <td>
            <table class="bandwidth">
                <tr>
                    <td>
                        <input type="checkbox" class="checkbox bandwidthbox" 
                            id="bandwidth_' . $port_number . '" name="serviceargs[bandwidth][' . $port_number . ']" checked>
                    </td>
                    <td>' . _('Rate In') . ':</td>
                    <td>' . _('Rate Out') . ':</td>
                    <td></td>
                    <td>' . _('Rate In') . ':</td>
                    <td>' . _('Rate Out') . ':</td>
                </tr>
                <tr>
                    <td>
                        <label>' . _('Warning') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="3" name="serviceargs[bandwidth_warning_input_value][' . $port_number . ']" 
                            value="' . $warn_in . '" class="form-control condensed">
                    </td>
                    <td>
                        <input type="text" size="3" name="serviceargs[bandwidth_warning_output_value][' . $port_number . ']" 
                            value="' . $warn_out . '" class="form-control condensed">
                    </td>
                    <td>
                        <label>' . _('Critical') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="3" name="serviceargs[bandwidth_critical_input_value][' . $port_number . ']" 
                            value="' . $crit_in . '" class="form-control condensed">
                    </td>
                    <td>
                        <input type="text" size="3" name="serviceargs[bandwidth_critical_output_value][' . $port_number . ']" 
                            value="' . $crit_out . '" class="form-control condensed">
                    </td>
                    <td>
                        <select name="serviceargs[bandwidth_speed_label][' . $port_number . ']" class="form-control condensed">
                            <option value="Gbps" ' . is_selected("Gbps", $label) . '>' . _('Gbps') . '</option>
                            <option value="Mbps" ' . is_selected("Mbps", $label) . '>' . _('Mbps') . '</option>
                            <option value="Kbps" ' . is_selected("Kbps", $label) . '>' . _('Kbps') . '</option>
                            <option value="bps" ' . is_selected("bps", $label) . '>' . _('bps') . '</option>
                        </select>
                    </td>
                </tr>
            </table>
        </td>
        <td style="text-align: center;">
            <input type="checkbox" class="statusbox" id="portstatus_' . $port_number . '" name="serviceargs[portstatus][' . $port_number . ']" checked>
        </td>
    </tr>';
                    }

                    $output .= '
                        </tbody>
                    </table>
                    ';
                } else {
                    $output .= '
                    <img src="' . theme_image("critical_small.png") . '">
                    <b>' . _('No ports were detected on the switch.') . '</b>  ' . _('Possible reasons for this include') . ':
                    <ul>
                        <li>' . _('The switch is currently down') . '</li>
                        <li>' . _('The switch does not exist at the address you specified') . '</li>
                        <li>' . _('SNMP support on the switch is disabled') . '</li>
                    </ul>
                    ';

                    if (is_admin() == true) {
                        $cfgmaker_cmd = switch_configwizard_get_cfgmaker_cmd($snmpopts, $address, $address_port, $snmpversion, $default_port_speed, $admindown);
                        $output .= '
                        <br>
                        <img src="' . theme_image("ack.png") . '">
                        <b>' . _('Troubleshooting Tip') . ':</b>
                        <p>
                        ' . _('If you keep experiencing problems with the switch wizard scan, login to the Nagios XI server as the root user and execute the following command') . ':
                        </p>
<pre>
' . $cfgmaker_cmd . '
</pre>
<p>
' . _('Send the output of the command and a description of your problem to the Nagios support team by posting to our online ') . '<a href="http://support.nagios.com/forum/" target="_blank">' . _('support forum') . '</a>.
</p>
                        ';
                    }
                }
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // get variables that were passed to us
            $hostname = grab_array_var($inargs, "hostname");
            $hostname = nagiosccm_replace_user_macros($hostname);
            $address = grab_array_var($inargs, "ip_address");
            $address_port = grab_array_var($inargs, "port", 161);
            $portnames = grab_array_var($inargs, "portnames");
            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if (!empty($snmpopts_serial)) {
                $snmpopts = json_decode(base64_decode($snmpopts_serial), true);
            } else {
                $snmpopts_default = array(
                    "snmpcommunity" => "public",
                    "v3_security_level" => "",
                    "v3_username" => "",
                    "v3_auth_password" => "",
                    "v3_priv_password" => "",
                    "v3_auth_proto" => "md5",
                    "v3_priv_proto" => "des"
                );
                $snmpopts = grab_array_var($inargs, "snmpopts", $snmpopts_default);
                $snmpopts_serial = base64_encode(json_encode($snmpopts));
            }
            $snmpversion = grab_array_var($inargs, "snmpversion", "1");
            $vendor = grab_array_var($inargs, "vendor");
            $scaninterfaces = grab_array_var($inargs, "scaninterfaces");
            $admindown = grab_array_var($inargs, "admindown");
            $bulk_options = grab_array_var($inargs, "bulk_options", '');
            $bulk_fields_serial = grab_array_var($inargs, 'bulk_fields_serial', '');
            if (!empty($bulk_fields_serial)) {
                $bulk_fields = json_decode(base64_decode($bulk_fields_serial), true);
            }
            else {
                $bulk_fields_default = array(
                    'ip_address', 'hostname'
                );
                $bulk_fields = grab_array_var($inargs, 'bulk_fields', $bulk_fields_default);
                $bulk_fields_serial = base64_encode(json_encode($bulk_fields));
            }
            $warn_speed_in_percent = grab_array_var($inargs, "warn_speed_in_percent", 50);
            $warn_speed_out_percent = grab_array_var($inargs, "warn_speed_out_percent", 50);
            $crit_speed_in_percent = grab_array_var($inargs, "crit_speed_in_percent", 80);
            $crit_speed_out_percent = grab_array_var($inargs, "crit_speed_out_percent", 80);

            // Check for errors
            $errors = 0;
            $errmsg = array();
            if (is_valid_host_name($hostname) == false) {
                $errmsg[$errors++] = _("Invalid host name.");
            }       

            // TODO - check rate in/out warning and critical thresholds

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $address_port = grab_array_var($inargs, "port", 161);
            $hostname = grab_array_var($inargs, "hostname");
            $vendor = grab_array_var($inargs, "vendor");
            $portnames = grab_array_var($inargs, "portnames");
            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if ($snmpopts_serial != "") {
                $snmpopts = json_decode(base64_decode($snmpopts_serial), true);
            } else {

                $snmpopts_default = array(
                    "snmpcommunity" => "public",
                    "v3_security_level" => "",
                    "v3_username" => "",
                    "v3_auth_password" => "",
                    "v3_priv_password" => "",
                    "v3_auth_proto" => "md5",
                    "v3_priv_proto" => "des",
                );
                $snmpopts = grab_array_var($inargs, "snmpopts", $snmpopts_default);
                $snmpopts_serial = base64_encode(json_encode($snmpopts));
            }
            $snmpversion = grab_array_var($inargs, "snmpversion", "1");
            $scaninterfaces = grab_array_var($inargs, "scaninterfaces");
            $admindown = grab_array_var($inargs, "admindown");
            $bulk_options = grab_array_var($inargs, "bulk_options", '');
            $bulk_fields_serial = grab_array_var($inargs, 'bulk_fields_serial', '');
            if (!empty($bulk_fields_serial)) {
                $bulk_fields = json_decode(base64_decode($bulk_fields_serial), true);
            }
            else {
                $bulk_fields_default = array(
                    'ip_address', 'hostname'
                );
                $bulk_fields = grab_array_var($inargs, 'bulk_fields', $bulk_fields_default);
                $bulk_fields_serial = base64_encode(json_encode($bulk_fields));
            }
            $warn_speed_in_percent = grab_array_var($inargs, "warn_speed_in_percent", 50);
            $warn_speed_out_percent = grab_array_var($inargs, "warn_speed_out_percent", 50);
            $crit_speed_in_percent = grab_array_var($inargs, "crit_speed_in_percent", 80);
            $crit_speed_out_percent = grab_array_var($inargs, "crit_speed_out_percent", 80);

            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");

            $services_serial = grab_array_var($inargs, "services_serial", base64_encode(json_encode($services)));
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", base64_encode(json_encode($serviceargs)));

            global $request;
            debug($request);
            debug($services);
            debug($serviceargs);

            $output .= '
            
        <input type="hidden" name="ip_address" value="' . encode_form_val($address) . '" />
        <input type="hidden" name="port" value="' . encode_form_val($address_port) . '" />
        <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '" />
        <input type="hidden" name="snmpopts_serial" value="' . $snmpopts_serial . '" />
        <input type="hidden" name="snmpversion" value="' . encode_form_val($snmpversion) . '" />
        <input type="hidden" name="vendor" value="' . encode_form_val($vendor) . '" />
        <input type="hidden" name="portnames" value="' . encode_form_val($portnames) . '" />
        <input type="hidden" name="scaninterfaces" value="' . encode_form_val($scaninterfaces) . '" />
        <input type="hidden" name="admindown" value="' . encode_form_val($admindown) . '" />
        <input type="hidden" name="bulk_options" value="' . encode_form_val($bulk_options) . '" />
        <input type="hidden" name="bulk_fields_serial" value="' . $bulk_fields_serial . '" />
        <input type="hidden" name="warn_speed_in_percent" value="' . encode_form_val($warn_speed_in_percent) . '" />
        <input type="hidden" name="crit_speed_in_percent" value="' . encode_form_val($crit_speed_in_percent) . '" />
        <input type="hidden" name="warn_speed_out_percent" value="' . encode_form_val($warn_speed_out_percent) . '" />
        <input type="hidden" name="crit_speed_out_percent" value="' . encode_form_val($crit_speed_out_percent) . '" />
        <input type="hidden" name="services_serial" value="' . $services_serial . '" />
        <input type="hidden" name="serviceargs_serial" value="' . $serviceargs_serial . '" />
';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            $output = '';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            // get variables that were passed to us
            $hostname = grab_array_var($inargs, "hostname", "");
            $ip_address = grab_array_var($inargs, "ip_address", "");
            $address_port = grab_array_var($inargs, "port", 161);

            $snmpopts_serial = grab_array_var($inargs, "snmpopts_serial", "");
            if ($snmpopts_serial != "") {
                $snmpopts = json_decode(base64_decode($snmpopts_serial), true);
            } else {

                $snmpopts_default = array(
                    "snmpcommunity" => "public",
                    "v3_security_level" => "",
                    "v3_username" => "",
                    "v3_auth_password" => "",
                    "v3_priv_password" => "",
                    "v3_auth_proto" => "md5",
                    "v3_priv_proto" => "des",
                );
                $snmpopts = grab_array_var($inargs, "snmpopts", $snmpopts_default);
                $snmpopts_serial = base64_encode(json_encode($snmpopts));
            }

            $snmpversion = grab_array_var($inargs, "snmpversion", "1");
            $portnames = grab_array_var($inargs, "portnames");
            $scaninterfaces = grab_array_var($inargs, "scaninterfaces");
            $admindown = grab_array_var($inargs, "admindown");
            $bulk_options = trim(grab_array_var($inargs, "bulk_options", ''));
            $bulk_fields_serial = grab_array_var($inargs, 'bulk_fields_serial', '');
            if (!empty($bulk_fields_serial)) {
                $bulk_fields = json_decode(base64_decode($bulk_fields_serial), true);
            }
            else {
                $bulk_fields_default = array(
                    'ip_address', 'hostname'
                );
                $bulk_fields = grab_array_var($inargs, 'bulk_fields', $bulk_fields_default);
                $bulk_fields_serial = base64_encode(json_encode($bulk_fields));
            }
            $vendor = grab_array_var($inargs, "vendor");

            $services_serial = grab_array_var($inargs, "services_serial", "");
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");

            $services = json_decode(base64_decode($services_serial), true);
            $serviceargs = json_decode(base64_decode($serviceargs_serial), true);
            if (empty($serviceargs)) { 
                $serviceargs = array();
            }

            debug($services);            
            debug($serviceargs);

            if ($snmpversion === "3") {
                $bulk_fields_count = 8;
            }
            else {
                $bulk_fields_count = 3;
            }
            $bulk_fields = array_slice($bulk_fields, 0, $bulk_fields_count);
            $bulk_fields = array_filter($bulk_fields);
            $bulk_fields = implode(",", $bulk_fields);
            debug('$bulk_fields is ' . $bulk_fields);
            $bulk_options = $bulk_fields . "\n" . $bulk_options;

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["ip_address"] = $ip_address;
            $meta_arr["snmpopts_serial"] = $snmpopts_serial;
            $meta_arr["snmpversion"] = $snmpversion;
            $meta_arr["portnames"] = $portnames;
            $meta_arr["scaninterfaces"] = $scaninterfaces;
            $meta_arr["admindown"] = $admindown;
            $meta_arr["vendor"] = $vendor;
            $meta_arr["services"] = $services;
            $meta_arr["serviceargs"] = $serviceargs;
            save_configwizard_object_meta($wizard_name, $hostname, "", $meta_arr);

            $original_values = array();
            foreach ($snmpopts as $k => $v) {
                $original_values[$k] = $v;
            }

            $objs = array();

            debug("bulk_options is $bulk_options");
            $bulk_array = json_decode(real_str_getcsv($bulk_options), true);
            $count = count($bulk_array);
            $bulk_array[$count] = $meta_arr;
            $count++;

            debug('bulk_array is ' . print_r($bulk_array, true));

            switch_configwizard_add_cfg_to_mrtg($ip_address);
            $original_cfg_text = file_get_contents("/etc/mrtg/conf.d/{$ip_address}.cfg"); 
            $original_values['ip_address'] = $ip_address;
            $original_values['hostname'] = $hostname;

            for ($i = 0; $i < $count; $i++) {

                // Every new switch must have a unique hostname and address. 
                if (empty($bulk_array[$i]['ip_address'])) {
                    debug('bulk_array at '.$i.' is getting skipped');
                    continue;
                }

                if (empty($bulk_array[$i]['hostname'])) {
                    $bulk_array[$i]['hostname'] = gethostbyaddr($bulk_array[$i]['ip_address']);
                }

                // $original_values is limited to snmp options + ip_address, hostname
                foreach ($original_values as $k => $v) {
                    $serviceargs[$k] = (empty($bulk_array[$i][$k]) ? $v : $bulk_array[$i][$k]);
                    debug("k $k ".$$k);
                }

                // Generate the cfg file for this address & write it out.
                $search_array = array(
                    $original_values['ip_address'],
                );
                $replace_array = array(
                    $serviceargs['ip_address']
                );

                if ($snmpversion != 3) {
                    $search_array[] = $original_values['snmpcommunity'];
                    $replace_array[] = $serviceargs['snmpcommunity'];
                }
                else {
                    $search_array[] = "username=>'".$original_values['v3_username']."'";
                    $replace_array[] = "username=>'".$serviceargs['v3_username']."'";

                    if (strpos(strtolower($snmpopts['v3_security_level']), 'noauth') === false) {
                        $search_array[] = strtolower("authprotocol=>'".$original_values['v3_auth_proto']."'");
                        $replace_array[] = strtolower("authprotocol=>'".$serviceargs['v3_auth_proto']."'");
                        $search_array[] = "authpassword=>'".$original_values['v3_auth_password']."'";
                        $replace_array[] = "authpassword=>'".$serviceargs['v3_auth_password']."'";
                    }
                    if (strpos(strtolower($snmpopts['v3_security_level']), 'nopriv') === false) {
                        $search_array[] = strtolower("privprotocol=>'".$original_values['v3_priv_proto']."'");
                        $replace_array[] = strtolower("privprotocol=>'".$serviceargs['v3_priv_proto']."'");
                        $search_array[] = "privpassword=>'".$original_values['v3_priv_password']."'";
                        $replace_array[] = "privpassword=>'".$serviceargs['v3_priv_password']."'";
                    }
                }
                $new_cfg_text = str_replace($search_array, $replace_array, $original_cfg_text);
                file_put_contents("/etc/mrtg/conf.d/{$serviceargs['ip_address']}.cfg", $new_cfg_text);

                if (!host_exists($hostname)) {
                    $objs[] = array(
                        "type" => OBJECTTYPE_HOST,
                        "use" => "xiwizard_switch_host",
                        "host_name" => $serviceargs['hostname'],
                        "address" => $serviceargs['ip_address'],
                        "icon_image" => "switch.png",
                        "statusmap_image" => "switch.png",
                        "_xiwizard" => $wizard_name,
                    );
                }

                $have_bandwidth = false;

                // see which services we should monitor
                foreach ($services as $svc => $svcstate) {

                    debug("PROCESSING: $svc -> $svcstate");

                    switch ($svc) {

                        case "ping":

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $serviceargs['hostname'],
                                "service_description" => "Ping",
                                "use" => "xiwizard_switch_ping_service",
                                "_xiwizard" => $wizard_name,
                            );
                            break;

                        case "port":


                            // set various snmpopts to escape bad characters ; and !
                            $escape_these = array(
                                'v3_auth_proto',
                                'v3_auth_password',
                                'v3_priv_proto',
                                'v3_priv_password',
                                'v3_security_level',
                                'v3_username'
                            );

                            foreach ($escape_these as $key) {
                                if (!empty($serviceargs[$key])) {
                                    $serviceargs[$key] = str_replace('!', '\!', $serviceargs[$key]);
                                    $serviceargs[$key] = escapeshellarg($serviceargs[$key]);
                                }
                            }

                            foreach ($svcstate as $portnum => $portstate) {

                                // Force int
                                $portnum = intval($portnum);

                                $portname = _("Port ") . $portnum;
                                if (array_key_exists("portname", $serviceargs)) {
                                    if (array_key_exists($portnum, $serviceargs["portname"])) {

                                        $portname = $serviceargs["portname"][$portnum];
                                        $badchars = explode(" ", "` ~ ! $ % ^ & * | ' \" < > ? , ( ) = \\ { } [ ]");
                                        $portname = str_replace($badchars, " ", $portname);
                                    }
                                }

                                // monitor bandwidth
                                if (array_key_exists("bandwidth", $serviceargs) && array_key_exists($portnum, $serviceargs["bandwidth"])) {

                                    $have_bandwidth = true;

                                    $warn_pair = $serviceargs["bandwidth_warning_input_value"][$portnum] . "," . $serviceargs["bandwidth_warning_output_value"][$portnum];
                                    $crit_pair = $serviceargs["bandwidth_critical_input_value"][$portnum] . "," . $serviceargs["bandwidth_critical_output_value"][$portnum];

                                    switch ($serviceargs["bandwidth_speed_label"][$portnum]) {

                                        case "Gbps":
                                            $label = "G";
                                            break;

                                        case "Mbps":
                                            $label = "M";
                                            break;

                                        case "Kbps":
                                            $label = "K";
                                            break;

                                        default:
                                            $label = "B";
                                            break;
                                    }

                                    $objs[] = array(
                                        "type" => OBJECTTYPE_SERVICE,
                                        "host_name" => $serviceargs['hostname'],
                                        "service_description" => $portname . " Bandwidth",
                                        "use" => "xiwizard_switch_port_bandwidth_service",
                                        "check_command" => "check_xi_service_mrtgtraf!" . strtolower($serviceargs['ip_address']) . "_" . $portnum . ".rrd!" . $warn_pair . "!" . $crit_pair . "!" . $label,
                                        "_xiwizard" => $wizard_name,
                                    );
                                }

                                // monitor port status
                                if (array_key_exists("portstatus", $serviceargs) && array_key_exists($portnum, $serviceargs["portstatus"])) {

                                    debug("MONITOR PORT STATUS ON $portnum");

                                    if ($snmpversion != 3) {

                                        $objs[] = array(
                                            "type" => OBJECTTYPE_SERVICE,
                                            "host_name" => $serviceargs['hostname'],
                                            "service_description" => $portname . " Status",
                                            "use" => "xiwizard_switch_port_status_service",
                                            "check_command" => "check_xi_service_ifoperstatus!" . $serviceargs['snmpcommunity'] . "!" . $portnum . "!-v " . intval($snmpversion) . " -p " . $address_port,
                                            "_xiwizard" => $wizard_name,
                                        );

                                    } else {

                                        // If privilege password
                                        $priv_password_and_proto = "";
                                        if (!empty($serviceargs['v3_priv_password'])) {
                                            $priv_password_and_proto = "-x {$serviceargs['v3_priv_proto']}";
                                            $priv_password_and_proto .= " -X {$serviceargs['v3_priv_password']}";
                                        }

                                        $snmppass = '';
                                        if (!empty($serviceargs['v3_auth_password'])) {
                                            $snmppass = "-A {$serviceargs['v3_auth_password']}";
                                        }

                                        $snmpauthproto = '';
                                        if (!empty($serviceargs['v3_auth_proto'])) {
                                            $snmpauthproto = "-a {$serviceargs['v3_auth_proto']}";
                                        }

                                        $snmpuser = "-u {$serviceargs['v3_username']}";

                                        $objs[] = array(
                                            "type" => OBJECTTYPE_SERVICE,
                                            "host_name" => $serviceargs['hostname'],
                                            "service_description" => $portname . " Status",
                                            "use" => "xiwizard_switch_port_status_service",
                                            "check_command" => "check_xi_service_ifoperstatusnag!{$portnum}!-v{$snmpversion} {$snmpuser} {$snmppass} {$priv_password_and_proto} {$snmpauthproto} -l {$serviceargs['v3_security_level']}!{$address_port}",
                                            "_xiwizard" => $wizard_name,
                                        );
                                    }
                                }
                            }
                            break;

                        default:
                            break;
                    }
                }

                debug($objs);

            }

            // Set permissions on rrd files so nagios can read them!
            switch_configwizard_update_mrtg();

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;
            break;

        default:
            break;
    }

    return $output;
}


/**
 *
 * Return a standardardized location for walk/cfgmaker files
 *
 * @param $address string the address to use to build the cfgmaker file location
 *
 * @return string - absolute path to file for cfgmaker walk
 *
 */
function switch_configwizard_get_walk_file($address) {
    $address = str_replace(array('/', '..'), '', $address);
    return get_tmp_dir() . "/mrtg-{$address}";
}


 /**
*
* Read a cfgmaker file to determine port information
*
* @param $address string - the address used to locate the cfgmaker file
*
* @return array - port information scanned from file
*/
function switch_configwizard_read_walk_file($address)
{
    $cfgmaker_file = switch_configwizard_get_walk_file($address);

    debug($cfgmaker_file);

    $output = array();

    // open the walk file for reading
    $cfgmaker_file_handle = fopen($cfgmaker_file, 'r');
    if ($cfgmaker_file_handle) {

        $description = false;
        $ifname = false;
        $alias = false;

        while (!feof($cfgmaker_file_handle)) {

            $buf = fgets($cfgmaker_file_handle);

            // skip comments
            $pos = strpos($buf, '#');
            if ($pos === 0)
                continue;

            // we only care about lines that contain a few keywords, so lets check for those first
            // and if we're sure our lines don't contain them, skip so as not to perform a lot of unecessary regex -bh

            if (strpos($buf, 'Target[') !== false) {

                // found the target line (contains port number)
                if (preg_match('/Target\[' . $address . '_([0-9\.]+)\]/', $buf, $matches)) {

                    $port_number = $matches[1];

                    if (!array_key_exists($port_number, $output)) {
                        $output[$port_number] = array(
                            'max_bytes'     => 0,
                            'name'          => _('Port ') . $port_number,
                            'description'   => _('Port ') . $port_number,
                            'alias'         => _('Port ') . $port_number,
                        );
                    }

                    continue;
                }
            }

            if (strpos($buf, 'MaxBytes[') !== false) {

                // we have the port speed
                if (preg_match('/MaxBytes\[' . $address . '_([0-9\.]+)\]: ([0-9\.]+)/', $buf, $matches)) {

                    $port_number = $matches[1];
                    $max_bytes = $matches[2];

                    if (!array_key_exists($port_number, $output)) {

                        $output[$port_number] = array(
                            'max_bytes'     => $max_bytes,
                            'name'          => _('Port ') . $port_number,
                            'description'   => _('Port ') . $port_number,
                            'alias'         => _('Port ') . $port_number,
                        );

                    } else {
                        $output[$port_number]['max_bytes'] = $max_bytes;
                    }

                    continue;
                }
            }

            // We need the lines directly after <td>Description:</td> and <td>ifName:</td> and <td>Alias:</td>
            if (strpos($buf, '<td>Description:</td>') !== false) {
                $description = true;
                continue;
            }

            if ($description) {
                $description = str_replace(array('<td>', '</td>'), '', $buf);
                $description = trim($description);
                $output[$port_number]['description'] = $description;

                $description = false;
                continue;
            }

            if (strpos($buf, '<td>ifName:</td>') !== false) {
                $ifname = true;
                continue;
            }

            if ($ifname) {
                $ifname = str_replace(array('<td>', '</td>'), '', $buf);
                $ifname = trim($ifname);
                $output[$port_number]['name'] = $ifname;

                $ifname = false;
                continue;
            }
            
            if (strpos($buf, '<td>Alias:</td>') !== false) {
                $alias = true;
                continue;
            }

            if ($alias) {
                $alias = str_replace(array('<td>', '</td>'), '', $buf);
                $alias = trim($alias);
                if( $alias !== '' ) {
                    // If the Alias data is not empty, use it.
                    $output[$port_number]['alias'] = $alias;
                }
                else {
                    // If the Alias data is  empty, replace it with the Description.
                    // This is to ensure if an empty ifAlias field is in the device, that we will use valid data in the wizard.
                    $output[$port_number]['alias'] = $output[$port_number]['description'];
                }

                $alias = false;
                continue;
            }
        }
        //end IF FILE is open

        fclose($cfgmaker_file_handle);
    }

    debug($output);
    return $output;
}


/**
*
* Add a specific cfgmaker file to mrtg config
* NOTE: we use copy+exec(sed) because it's a bit faster than all of the calls to fopen/fwrite/etc.
*       this is a pretty big deal on larger systems!
*
* @param $address string - address to search in 
*
* @return bool
*/
function switch_configwizard_add_cfg_to_mrtg($address)
{
    // get the data that we need
    $mrtg_confd_dir = "/etc/mrtg/conf.d";
    $mrtg_cfg_file = "{$address}.cfg";
    $absolute_mrtg_cfg_file = "{$mrtg_confd_dir}/{$mrtg_cfg_file}";
    $cfgmaker_file = switch_configwizard_get_walk_file($address);

    // check if the file already exists for useful debugging
    $mrtg_confd_contents = scandir($mrtg_confd_dir);
    if (in_array($mrtg_cfg_file, $mrtg_confd_contents)) {
        debug("{$mrtg_cfg_file} exists in {$mrtg_confd_dir}, overwriting");
    } else {
        debug("{$mrtg_cfg_file} does not exist in {$mrtg_confd_dir}, creating");
    }

    // copy the cfgmaker file to the mrtg cfg destination
    if (!copy($cfgmaker_file, $absolute_mrtg_cfg_file)) {
        debug("Unable to copy from {$cfgmaker_file} to {$absolute_mrtg_cfg_file}");
        return false;
    }

    // add some meta info to the file
    $infoline = "#### ADDED BY NAGIOSXI (User: ". get_user_attr(0, 'username') .", DATE: ". get_datetime_string(time()) .") ####\n";
    exec("sed -i '1s|.*|{$infoline}&|' ".escapeshellarg($absolute_mrtg_cfg_file));

    return true;
}


/**
*
* Updates the mrtg config to stop nagios from alerting that rrd files don't exist
*
*/
function switch_configwizard_update_mrtg() {

    if (@is_executable("/usr/bin/mrtg")) {
        // For whatever reason this won't return immediately without the redirectors
        $cmd = "((env LANG=C /usr/bin/mrtg /etc/mrtg/mrtg.cfg --group=nagios || true) ";
        $cmd .= "&& chmod 664 /var/lib/mrtg/*.rrd ";
        $cmd .= "&& chgrp nagios /var/lib/mrtg/*.rrd) >/dev/null 2>&1 &";
        exec($cmd, $out);
    }
}


/**
 *
 * Append some human readable information to maxbytes/portspeed
 *
 * @param $max_bytes
 * @param $speed
 * @param $label
 *
 * @return string
 */
function switch_configwizard_get_readable_port_line_speed($max_bytes, &$speed, &$label)
{
    $bps = $max_bytes * 8;

    $kbps = $bps / 1e3;
    $mbps = $bps / 1e6;
    $gbps = $bps / 1e9;

    if ($gbps >= 1) {

        $speed = $gbps;
        $label = "Gbps";

    } else if ($mbps >= 1) {

        $speed = $mbps;
        $label = "Mbps";

    } else if ($kbps >= 1) {

        $speed = $kbps;
        $label = "Kbps";

    } else {

        $speed = $bps . " bps";
        $label = "bps";
    }

    $output = number_format($speed, 2) . " " . $label;
    return $output;
}


/**
 *
 * Recalculate warn/crit in/out speeds based on label/readability
 *
 * @param $warn_in_speed
 * @param $warn_out_speed
 * @param $crit_in_speed
 * @param $crit_out_speed
 * @param $label
 */
function switch_configwizard_recalculate_speeds(&$warn_in_speed, &$warn_out_speed, &$crit_in_speed, &$crit_out_speed, &$label)
{

    while (1) {

        if ($label == "bps")
            break;

        $maxval = max($warn_in_speed, $warn_out_speed, $crit_in_speed, $crit_out_speed);

        if ($maxval < 1) {

            switch ($label) {

                case "Gbps":
                    $label = "Mbps";
                    break;

                case "Mbps":
                    $label = "Kbps";
                    break;

                case "Kbps":
                    $label = "bps";
                    break;

                default:
                    break;
            }

            // bump down a level
            $warn_in_speed  *= 1000;
            $warn_out_speed *= 1000;
            $crit_in_speed  *= 1000;
            $crit_out_speed *= 1000;

        } else {
            break;
        }
    }
}


/**
 *
 * Get a sane size value to display in a textbox
 *
 * @param $rate - the number to format (in a sane way)
 * @param $start_decimals, optional, default 2 - how many decimal places to try for (via number_format)
 * @param $max_chars, optional, default 5 - the maximum amount of characters to allow after formatting
 *
 */
function switch_configwizard_get_sane_display_rate($rate, $start_decimals = 2, $max_chars = 5) 
{
    $display = (string) number_format($rate, $start_decimals);

    while (strlen($display) > $max_chars) {

        $display = substr($display, 0, -1);
    }

    // get rid of a trailing period no matter what
    if (substr($display, -1) === '.')
        $display = substr($display, 0, -1);

    $display = str_replace(',', '', $display);

    return $display;
}

// Retrieved from https://www.php.net/manual/en/function.str-getcsv.php
// and modified to work on strings instead of files.
// Returns an array-of-arrays or the serialized equivalent.
function real_str_getcsv($strCsv, $serialize = true) {
    $csv = explode("\n", $strCsv);
    $acc = array();

    $csv = array_map('str_getcsv', $csv);
    array_walk($csv, function(&$a) use ($csv) {
      $a = array_combine($csv[0], $a);
    });
    array_shift($csv); # remove column header

    return ($serialize ? json_encode($csv) : $csv);
}
/**
 *
 * Debug logging - dummy function override for xiver < 5.3.0
 *
 */
if (!function_exists('debug')) {
    function debug() { }
}

