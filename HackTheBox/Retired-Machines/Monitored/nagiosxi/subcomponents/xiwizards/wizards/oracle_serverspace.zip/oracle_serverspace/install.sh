#!/bin/bash

WIZARD_DIR=$(dirname $(readlink -f $0))
cd $WIZARD_DIR
# We are currently in  get_base_dir().'/includes/configwizards/'.$name

BASE_DIR=$WIZARD_DIR/../../../..
CFG_DIR=$BASE_DIR/etc/configwizards/oracle

if [ ! -d $CFG_DIR ]; then
	mkdir -p $CFG_DIR
fi

if [ ! -f $CFG_DIR/oracle ]; then
	touch $CFG_DIR/oracle
	cat << EOF > $CFG_DIR/oracle
export LD_LIBRARY_PATH=/usr/lib/oracle/11.2/client/lib
export ORACLE_HOME=/usr/lib/oracle/11.2/client
EOF

fi
