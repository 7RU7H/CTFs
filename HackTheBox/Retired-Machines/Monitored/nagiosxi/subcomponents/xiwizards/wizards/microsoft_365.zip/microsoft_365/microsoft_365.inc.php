<?php
//
// Microsoft/Office 365 Config Wizard
// Copyright (c) 2010-2021 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

microsoft_365_configwizard_init();

function microsoft_365_configwizard_init() {
    $name = "microsoft_365";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.0.3",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Monitor Microsoft/Office 365 Subscription Services"),
        CONFIGWIZARD_DISPLAYTITLE => _("Microsoft/Office 365"),
        CONFIGWIZARD_FUNCTION => "microsoft_365_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "microsoft_365.png",
        CONFIGWIZARD_FILTER_GROUPS => array('windows','database'),
        CONFIGWIZARD_REQUIRES_VERSION => 500
    );
    register_configwizard($name, $args);
}

const CONCEALED_INFO = '<div style="display: inline-block; padding-left: 5px;"><i class="credtooltip fa fa-question-circle fa-14" data-placement="right" data-content="This dropdown is disabled because your user data is concealed/obfuscated."></i></div>';

/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function microsoft_365_configwizard_func($mode = "", $inargs = null, &$outargs, &$result) {

    $wizard_name = "microsoft_365";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $tenant = grab_array_var($inargs, "tenant", "");
            $appid = grab_array_var($inargs, "appid", "");
            $secret = grab_array_var($inargs, "secret", "");

#            $tenant = decrypt_data($tenant);
#            $appid = decrypt_data($appid);
#            $secret = decrypt_data($secret);

            $output = '
<h5 class="ul">'._('Microsoft/Office 365 - Setup').'</h5>
<p>
You can now monitor your Microsoft Office 365 subscription services with Nagios XI.<br>
See <a target="blank" href="https://support.nagios.com/kb/article/monitoring-office-365-subscription-services-881.html">Monitoring Office 365 Subscription Services</a>, for step by step instructions.
</p>
<p style="margin-bottom: 0;">
<b>Notes for Administrators:</b><br>
You will need to setup an app registration, with a client secret and these API permissions...
</p>
<ul style="padding: 0 0 0 20px;">
<b>Microsoft Graph</b>
    <li style="margin-left: 15px;">Group.Read.All</li>
    <li style="margin-left: 15px;">Reports.Read.All</li>
    <li style="margin-left: 15px;">User.Read.All</li>
</ul>
<p style="margin-top: 0;">
Plus, <b><i>Global Administrator</i></b> role is required in order to provide admin consent for application permissions to the Microsoft Graph API.
</p>
<p>
For more information, see <a target="blank" href="https://docs.microsoft.com/en-us/azure/active-directory/manage-apps/grant-admin-consent">Grant Tenant-Wide Admin Consent to an Application</a> on the Microsoft site.
</p>';

            $output .= '
<h5 class="ul">'._('Microsoft/Office 365').'</h5>
<p>'._('Specify the details for connecting to the Microsoft/Office 365 statistics you want to monitor').'.</p>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>'._('Application (client) ID').':</label>
        </td>
        <td>
            <input type="text" size="50" name="appid" id="appid" value="'.encode_form_val($appid).'" class="textfield form-control">
            <div class="subtext">'._('Application (client) ID (GUID) created during plugin registration in Azure AD').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Directory (tenant) ID').':</label>
        </td>
        <td>
            <input type="text" size="50" name="tenant" id="tenant" value="'.encode_form_val($tenant).'" class="textfield form-control">
            <div class="subtext">'._('Azure Directory (tenant) ID (GUID), of your organization or domain').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt"><label>' . _('Client Secret') . ':</label></td>
        <td>
            <input type="password" size="50" name="secret" id="secret" value="' . encode_form_val($secret) . '" class="textfield usermacro-detection form-control" autocomplete="off">
            <button type="button" style="vertical-align: top;" class="btn btn-sm btn-default tt-bind btn-show-secret" title="'._("Show secret").'"><i class="fa fa-eye"></i></button>
            <div class="subtext">'._('Client secret - plugin authentication credentials, created in Azure AD').'.</div>
        </td>
    </tr>
</table>

<script type="text/javascript">
    // Show or hide secret section
    $(\'.btn-show-secret\').click(function() {
        var type = $(this).parent().find(\'input\').attr(\'type\');
        var tooltip_id = $(this).attr(\'aria-describedby\');

        if (type == \'password\') {
            $(this).parent().find(\'input\').attr(\'type\', \'input\');
            $(this).attr(\'data-original-title\', _("Hide secret"));
            $(\'#\'+tooltip_id+\' .tooltip-inner\').text(_("Hide secret"));
            $(this).find(\'i\').removeClass(\'fa-eye\').addClass(\'fa-eye-slash\');
        } else {
            $(this).parent().find(\'input\').attr(\'type\', \'password\');
            $(this).attr(\'data-original-title\', _("Show secret"));
            $(\'#\'+tooltip_id+\' .tooltip-inner\').text(_("Show secret"));
            $(this).find(\'i\').removeClass(\'fa-eye-slash\').addClass(\'fa-eye\');
        }
    });
</script>';

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:
            // Get variables that were passed to us
            $appid = grab_array_var($inargs, "appid", "");
            $tenant = grab_array_var($inargs, "tenant", "");
            $secret = grab_array_var($inargs, "secret", "");

            $appid = nagiosccm_replace_user_macros($appid);
            $tenant = nagiosccm_replace_user_macros($tenant);
            $secret = nagiosccm_replace_user_macros($secret);

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (have_value($appid) == false)    $errmsg[$errors++] = "No Application ID specified.";
            if (have_value($tenant) == false)   $errmsg[$errors++] = "No Directory ID specified.";
            if (have_value($secret) == false)   $errmsg[$errors++] = "No Client Secret specified.";

            if ($errors == 0) { 
                $authCheck = msip_auth_check($appid, $tenant, $secret);

                if ($authCheck) {
                    $errmsg[$errors++] = nl2br($authCheck);
                }
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $appid = grab_array_var($inargs, "appid", "");
            $tenant = grab_array_var($inargs, "tenant", "");
            $secret = grab_array_var($inargs, "secret", "");
            $hostname = grab_array_var($inargs, "hostname", "");

            # This should use ms graph batching, at some point.
            # Don't pass these along (like modelist and services).
            $usersList = plugin_data($appid, $tenant, $secret, 'userslist');
            $groupsList = plugin_data($appid, $tenant, $secret, 'groupslist');
            $productsList = plugin_data($appid, $tenant, $secret, 'productslist');
            $organization = plugin_data($appid, $tenant, $secret, 'organization');

            # Review, in case the < Back button was used.
            $services_serial = grab_array_var($inargs, "services_serial", "");
            $services = json_decode(base64_decode($services_serial), true);
            $modelist_serial = grab_array_var($inargs, "modelist_serial", "");
            $modelist = json_decode(base64_decode($modelist_serial), true);

            # This should use ms graph batching, at some point.
            $modelist = (empty($modelist)) ? mode_list($appid, $tenant, $secret) : $modelist;

            # Check for concealed user data (affects user, group and site names in all reports.
            $isDataConcealed = is_data_concealed($appid, $tenant, $secret);

            $ms365_base_url = get_base_url().'includes/configwizards/microsoft_365/';
            $select2_css_url = $ms365_base_url.'css/select2'.(get_theme() === 'xi5dark' ? '-dark' : '').'.css';
            $select2_js_url = $ms365_base_url.'js/select2.full.min.js';

            $output = '';

            # Microsoft now conceals user, group and site name data, by default, so check to see if we need to warn the user.
            if ($isDataConcealed) {
                $output .= '
<h5 class="ul">'._('NOTIFICATION: Concealed user, group and site names detected').'</h5>
<p>
On September 1, 2021, Microsoft made privacy changes to all Microsoft 365 Subscriptions. As a result, your<br>
user, group, and site information, in your organizations data usage reports, is concealed/anonymized.
</p><p>
In order to monitor individual users, groups and sites in your Microsoft Office 365 subscription,<br>
you will need to override the setting in the <a target="blank" href="https://admin.microsoft.com">Microsoft 365 admin center</a>.<br>
See <a target="blank" href="https://docs.microsoft.com/en-us/office365/troubleshoot/miscellaneous/reports-show-anonymous-user-name">Microsoft 365 reports show anonymous user names instead of actual user names</a>,<br>
for step by step instructions.
</p><p>
Generic metrics are available, without any changes.
</p><br>';
            }

            $output .= '
<link href="'.$select2_css_url.'" rel="stylesheet"/>
<script src="'.$select2_js_url.'"></script>
<style>
    .select2-container, .selection, .select2-selection, .select2-selection__rendered {
        z-index: 800;
    }
</style>
<input type="hidden" name="appid" value="'.encode_form_val($appid).'">
<input type="hidden" name="tenant" value="'.encode_form_val($tenant).'">
<input type="hidden" name="secret" value="'.encode_form_val($secret).'">
<input type="hidden" name="hostname" value="'.encode_form_val($hostname).'">
<input type="hidden" name="services_serial" value="'.$services_serial.'" />
<input type="hidden" name="modelist_serial" value="'.base64_encode(json_encode($modelist)).'" />
<input type="hidden" name="usersList" value="'.htmlspecialchars(json_encode($usersList), ENT_QUOTES, "UTF-8").'" />
<input type="hidden" name="groupsList" value="'.htmlspecialchars(json_encode($groupsList), ENT_QUOTES, "UTF-8").'" />
<input type="hidden" name="productsList" value="'.htmlspecialchars(json_encode($productsList), ENT_QUOTES, "UTF-8").'" />

<h5 class="ul">'._('Microsoft/Office 365').'</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>'._('Host name').':</label>
        </td>
        <td>
            <input type="text" size="50" name="hostname" id="hostname" value="'.encode_form_val(!empty($hostname) ? $hostname : $organization[0]['displayName'].'-'.$organization[0]['tenantType']).'" class="textfield form-control">
            <div class="subtext">'._('Short name for the tenant the service connects through (combination of tenant name and type)').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Application (Client) ID').':</label>
        </td>
        <td>
            <input type="text" size="50" name="appid" id="appid" value="'.encode_form_val($appid).'" class="textfield form-control" disabled>
            <div class="subtext">'._('Application (client) ID (GUID) created when this plugin was registered in Azure AD').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Directory (tenant) ID').':</label>
        </td>
        <td>
            <input type="text" size="50" name="tenant" id="tenant" value="'.encode_form_val($tenant).'" class="textfield form-control" disabled>
            <div class="subtext">'._('Azure Directory (tenant) ID (GUID), of your organization or domain').'.</div>
        </td>
    </tr>
</table>

<h5 class="ul"></h5>';

#echo("services ".var_export($services, true)."<br>");
            foreach ((array) $modelist as $modeName => $pluginMode) {
                $serviceCount = 0;

                if (isset($services['process'][$modeName]) == false) {
                    $services['process'][$modeName]['0']['monitor'] = 'off';
                    #$services['process'][$modeName]['0']['unit'] = '';
                    #$services['process'][$modeName]['0']['modifier'] = '';
                    $services['process'][$modeName]['0']['warning'] = $pluginMode['warn'];
                    $services['process'][$modeName]['0']['critical'] = $pluginMode['crit'];
                }

                $output .= '
<table class="table table-condensed table-no-border table-auto-width table-padded" style="margin-bottom: 0">
    <tbody id="process-'.$modeName.'-list">
    <tr>
        <td class="vt"></td>
        <td colspan=3>
            <label class="normal">
                <b>'. _($pluginMode['name']). '</b><br>
                '. _(str_replace('|', '', $pluginMode['help'])).'
            </label>
        </td>
    </tr>';

                $output .= '
    <tr>';
                # Multiple service setups.
                if ($pluginMode['multiple'] == true) {
                    $output .= '
        <td class="vt" style="width: 26px">&nbsp;</td>';

                # Single service setups.
                } else {
                    $checked = (array_key_exists('monitor', $services['process'][$modeName]['0']) &&
                                $services['process'][$modeName]['0']['monitor'] == 'on') ? 'checked' : '';

                    $output .= '
        <td class="vt">
            <input type="checkbox" class="checkbox" id="services[process]['.$modeName.'][0][monitor]" name="services[process]['.$modeName.'][0][monitor]" style="margin-top: 1px;" '.$checked.'>
        </td>';
                }

                $output .= '
        <td>
            <div style="display: table-row">';

                # Multiple service setups.
                if ($pluginMode['multiple'] == true) {
                    $output .= '
                <div style="display:table-cell; padding-right: 5px; vertical-align: middle;">
                    <img src="/nagiosxi/images/'.$pluginMode['icon'].'" class="tt-bind" title="'.$pluginMode['filterLabel'].'">
                </div>
                <div style="position: relative; display: table-cell">
                    <div style="float: left;">
                        <select name="services[process]['.$modeName.']['.$pluginMode['filter'].']"
                            id="services[process]['.$modeName.']['.$pluginMode['filter'].']"
                            class="services-process-'.$modeName.'-'.$pluginMode['filter'].' form-control condensed"
                            style="width: 400px; z-index: 800;"';
                    $output .= ($isDataConcealed && $pluginMode['filter'] == 'user') ? 'disabled=disabled> ' : '>';
                    $output .= '<!--option value=\'0\'>Please select a '.$pluginMode['filter'].'</option-->
                            <option></option>';

                    $list = $pluginMode['filter']."List";
                    $dataList = array();

                    if (array_key_exists($list, $services['process'][$modeName])) {
                        $dataList = explode(',', $services['process'][$modeName][$list]);
                    }

                    # Would be nice to consolidate this, a bit...
                    switch ($pluginMode['filter']) {

                        case "user":
                            foreach ((array) $usersList as $key => $user) {
                                # Skip chosen options
                                if (in_array($user['userPrincipalName'], $dataList))    continue;

                                $output .= '
                            <option value="'.$user['userPrincipalName'].'">'._($user['userPrincipalName']).' - '._($user['displayName']).'</option>';
                            }

                            break;

                        case "group":
                            foreach ((array) $groupsList as $group) {
                                # Skip chosen options
                                if (in_array($group['id'], $dataList))    continue;

                                $output .= '
                            <option value="'.$group['id'].'">'._($group['displayName']).' - '._($group['id']).'</option>';
                            }

                            break;

                        case "product":
                            foreach ((array) $productsList as $product) {
                                # No products (like dev.onmicrosoft.com)
                                if (array_key_exists('rowCount', $productsList) && $productsList['rowCount'] == 0)    continue;

                                # Skip chosen options
                                if (in_array($product['Product Type'], $dataList))    continue;

                                $output .= '
                            <option value="'.$product['Product Type'].'">'._($product['Product Type']).'</option>';
                            }

                            break;
                    }   # End $plugin['filter'] switch

                    $output .= '
                </select>
            </div>
        </td>
        <td>
            <div class="pad-t5">
                
                <div style="display: inline-block;">
                    <button type="button" class="btn btn-sm btn-primary" id="add-new-'.$modeName.'-service" name="add-new-'.$modeName.'-service" disabled>Add</button>
                </div>';
                    if ($isDataConcealed && $pluginMode['filter'] == 'user') {
                        $output .= CONCEALED_INFO.'

                <script type="text/javascript">

                    $(function(){
                        $(".credtooltip").popover({ html: true });
                    });

                </script>';
                    }

                    $output .= '
            </div>';

                # Single service setups.
                } else {
                        $output .= '
            <div class="pad-t5">
                <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
                <input type="text" size="20" name="services[process]['.$modeName.'][0][warning]" value="'.encode_form_val((array_key_exists('warning', $services['process'][$modeName][0])) ? $services['process'][$modeName][0]['warning'] : $pluginMode['warn']).'" class="form-control condensed">&nbsp;&nbsp;
                <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
                <input type="text" size="20" name="services[process]['.$modeName.'][0][critical]" value="'.encode_form_val((array_key_exists('critical', $services['process'][$modeName][0])) ? $services['process'][$modeName][0]['critical'] : $pluginMode['crit']).'" class="form-control condensed">
            </div>';
                }

                $output .= '
        </td>
        <td width="50%"></td>
    </tr>
    </tbody>
</table>';


$output .='
    <div class="xi-modal hide">
        <div class="xi-modal-spinner">
            <div class="sk-spinner sk-spinner-rotating-plane"></div>
        </div>
    </div>
';

                # Multiple service setups.
                if ($pluginMode['multiple'] == true) {
                    $output .= '
<input type="hidden" name="services[process]['.$modeName.'][filter]" value="'.encode_form_val($pluginMode['filter']).'"/>
<input type="hidden" name="services[process]['.$modeName.']['.$pluginMode['filter'].'List]" value="'.((array_key_exists($pluginMode['filter'].'List', $services['process'][$modeName])) ? $services['process'][$modeName][$pluginMode['filter'].'List'] : "").'"/>';
                }

                $output .= '
<table class="table table-condensed table-no-border table-auto-width table-padded" style="margin-bottom: 0">
    <tbody id="process-'.$modeName.'-services">';


                # Multiple service setups.
                if ($pluginMode['multiple'] == true && array_key_exists($pluginMode['filter']."List", $services['process'][$modeName])) {

                    # Handle data from the services array (Back button)
                    foreach ((array) $services['process'][$modeName] as $i => $metrics) {
                        if (!is_numeric($i)) continue;

                        $checked = (array_key_exists('monitor', $services['process'][$modeName][$i]) &&
                                    $services['process'][$modeName][$i]['monitor'] == 'on') ? 'checked' : '';

                        $output .= '
    <tr>
        <td style="padding-bottom: 0;">
         <input type="checkbox" class="checkbox" id="services[process]['.$modeName.']['.$i.'][monitor]" name="services[process]['.$modeName.']['.$i.'][monitor]" style="margin-top: 1px;" '.$checked.'>
        </td>
        <td style="padding-right: 0; padding-bottom: 0">
            <label><img src="/nagiosxi/images/'.$pluginMode['icon'].'" class="tt-bind" title="'.$pluginMode['filterLabel'].'"></label>
        </td>
        <td style="padding-bottom: 0;">
            <input type="text" size="40" name="services[process]['.$modeName.']['.$i.'][displayName]" id="services[process]['.$modeName.']['.$i.'][displayName]" value="'.encode_form_val($metrics['displayName']).'" class="form-control condensed">
            <input type="hidden" name="services[process]['.$modeName.']['.$i.']['.$pluginMode['filter'].']" id="services[process]['.$modeName.']['.$i.']['.$pluginMode['filter'].']" value="'.encode_form_val($metrics[$pluginMode['filter']]).'">
        </td>
        <td style="padding-right: 0; padding-bottom: 0">
            <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>
        </td>
        <td style="padding-bottom: 0;">
            <input type="text" size="20" name="services[process]['.$modeName.']['.$i.'][warning]" value="'.encode_form_val($metrics['warning']).'" class="form-control condensed">
        </td>
        <td style="padding-right: 0; padding-bottom: 0">
            <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>
        </td>
        <td style="padding-bottom: 0;">
            <input type="text" size="20" name="services[process]['.$modeName.']['.$i.'][critical]" value="'.encode_form_val($metrics['critical']).'" class="form-control condensed">
        </td>
    </tr>';
                        $serviceCount = $i;
                    }
                }

                $output .= '
</tbody>
</table>';

                # Multiple service setups.
                if ($pluginMode['multiple'] == true) {

                    $output .= '
<script type="text/javascript">

    var '.$modeName.'_num = ('.$serviceCount.') ? '.$serviceCount.' + 1 : 1;
    var '.$modeName.'List = [];
    '.$modeName.'List.unshift($("input[name=\'services[process]['.$modeName.']['.$pluginMode['filter'].'List]\']").val());

    $(document).ready(function() {

        $(".xi-modal-spinner").show();
        $(".btn-select-template").click(function() {
            whiteout();
            $(".xi-modal").show();
            $(".xi-modal").position({ my: "center", at: "center", of: element });
        });

        // Setup select2 searchable widget.
        $(".services-process-'.$modeName.'-'.$pluginMode['filter'].'").select2({
            placeholder: \'Please select a '.$pluginMode['filterLabel'].'\',
            allowClear: false,
            minimumResultsForSearch: 8, // No search, unless at least 8 entries.
        });

        // Activate button, once select is changed.
        $("select[name=\'services[process]['.$modeName.']['.$pluginMode['filter'].']\']").on("change", function() {
            $("#add-new-'.$modeName.'-service").prop("disabled", false);
        });

        $("#add-new-'.$modeName.'-service").click(function() {

            row = "".concat(
\'<tr>\',
\'    <td style="padding-bottom: 0;">\',
\'        <input type="checkbox" class="checkbox" id="services[process]['.$modeName.'][\'+'.$modeName.'_num+\'][monitor]" name="services[process]['.$modeName.'][\'+'.$modeName.'_num+\'][monitor]" style="margin-top: 1px;" checked>\',
\'    </td>\',
\'    <td style="padding-right: 0; padding-bottom: 0">\',
\'        <label><img src="/nagiosxi/images/'.$pluginMode['icon'].'" class="tt-bind" title="'.$pluginMode['filterLabel'].'"></label>\',
\'    </td>\',
\'    <td style="padding-bottom: 0;">\',
\'        <input type="text" size="40" name="services[process]['.$modeName.'][\'+'.$modeName.'_num+\'][displayName]" id="services[process]['.$modeName.'][\'+'.$modeName.'_num+\'][displayName]" class="form-control condensed">\',
\'        <input type="hidden" name="services[process]['.$modeName.'][\'+'.$modeName.'_num+\']['.$pluginMode['filter'].']" id="services[process]['.$modeName.'][\'+'.$modeName.'_num+\']['.$pluginMode['filter'].']">\',
\'    </td>\',
\'    <td style="padding-right: 0; padding-bottom: 0">\',
\'        <label><img src="/nagiosxi/images/error.png" class="tt-bind" title="Warning Threshold"></label>\',
\'    </td>\',
\'    <td style="padding-bottom: 0;">\',
\'        <input type="text" size="20" name="services[process]['.$modeName.'][\'+'.$modeName.'_num+\'][warning]" value="'.encode_form_val($pluginMode['warn']).'" class="form-control condensed">\',
\'    </td>\',
\'    <td style="padding-right: 0; padding-bottom: 0">\',
\'        <label><img src="/nagiosxi/images/critical_small.png" class="tt-bind" title="Critical Threshold"></label>\',
\'    </td>\',
\'    <td style="padding-bottom: 0;">\',
\'        <input type="text" size="20" name="services[process]['.$modeName.'][\'+'.$modeName.'_num+\'][critical]" value="'.encode_form_val($pluginMode['crit']).'" class="form-control condensed">\',
\'    </td>\',
\'</tr>\');

            var '.$pluginMode['filter'].' = $("select[name=\'services[process]['.$modeName.']['.$pluginMode['filter'].']\']").val();
            var displayName = $("select[name=\'services[process]['.$modeName.']['.$pluginMode['filter'].']\'] option:selected").text();

            $("#process-'.$modeName.'-services").append(row);

            $("input[name=\'services[process]['.$modeName.']["+'.$modeName.'_num+"][displayName]\']").val(displayName);
            $("input[name=\'services[process]['.$modeName.']["+'.$modeName.'_num+"]['.$pluginMode['filter'].']\']").val('.$pluginMode['filter'].');
            $("select[name=\'services[process]['.$modeName.']['.$pluginMode['filter'].']\'] option:selected").remove();

            '.$modeName.'List.push('.$pluginMode['filter'].');
            $("input[name=\'services[process]['.$modeName.']['.$pluginMode['filter'].'List]\']").val('.$modeName.'List.toString());

            '.$modeName.'_num++;

            // Disable the button, again.
            $("#add-new-'.$modeName.'-service").prop("disabled", true);
        });
    });
</script>';
                }

            $output .= '
<h5 class="ul"></h5>';
            }

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // get variables that were passed to us
            $appid = grab_array_var($inargs, "appid");
            $tenant = grab_array_var($inargs, "tenant");
            $secret = grab_array_var($inargs, "secret");
            $hostname = grab_array_var($inargs, "hostname");

            $appid = nagiosccm_replace_user_macros($appid);
            $tenant = nagiosccm_replace_user_macros($tenant);
            $secret = nagiosccm_replace_user_macros($secret);

            #$modelist_serial = grab_array_var($inargs, "modelist", array());
            $modelist_serial = grab_array_var($inargs, "modelist_serial");
            $modelist = json_decode(base64_decode($modelist_serial), true);

            $services = grab_array_var($inargs, "services", array());

            // check for errors
            $errors = 0;
            $errmsg = array();

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

       // get variables that were passed to us
            $tenant = grab_array_var($inargs, "tenant");
            $appid = grab_array_var($inargs, "appid");
            $secret = grab_array_var($inargs, "secret");
            $hostname = grab_array_var($inargs, "hostname");

#            $modelist = grab_array_var($inargs, "modelist");
            $modelist_serial = grab_array_var($inargs, "modelist_serial");
            $modelist = json_decode(base64_decode($modelist_serial), true);

            $services = grab_array_var($inargs, "services");

            $output = '
            
        <input type="hidden" name="tenant" value="'.encode_form_val($tenant).'" />
        <input type="hidden" name="appid" value="'.encode_form_val($appid).'" />
        <input type="hidden" name="secret" value="'.encode_form_val($secret).'" />
        <input type="hidden" name="hostname" value="'.encode_form_val($hostname).'" />

        <input type="hidden" name="modelist_serial" value="'.$modelist_serial.'" />
        <input type="hidden" name="services_serial" value="'.base64_encode(json_encode($services)).'" />
            ';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            $output = '
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            $appid = grab_array_var($inargs, "appid", "");
            $tenant = grab_array_var($inargs, "tenant", "");
            $secret = grab_array_var($inargs, "secret", "");
            $hostname = grab_array_var($inargs, "hostname", "");

            $modelist_serial = grab_array_var($inargs, "modelist_serial");
            $services_serial = grab_array_var($inargs, "services_serial", "");

            $modelist = json_decode(base64_decode($modelist_serial), true);
            $services = json_decode(base64_decode($services_serial), true);

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["appid"] = $appid;
            $meta_arr["tenant"] = $tenant;
            $meta_arr["secret"] = $secret;
            $meta_arr["hostname"] = $hostname;
            $meta_arr["modelist"] = $modelist;
            $meta_arr["services"] = $services;

            save_configwizard_object_meta($wizard_name, $appid, "", $meta_arr);

            $objs = array();

            if (!host_exists($appid)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_microsoft_365_host",
                    "host_name" => $hostname,
                    "icon_image" => "microsoft_365.png",
                    "statusmap_image" => "microsoft_365.png",
                    "_xiwizard" => $wizard_name,
                );
            }

            // common plugin opts
            $commonopts = "--tenant '$tenant' --appid '$appid' --secret '$secret' ";

            foreach ((array) $services as $service => $args) {

                $pluginopts = "".$commonopts;

                switch ($service) {

                    case "connectiontime":

                        $pluginopts .= "--mode time2connect --warning '".$services["warning"]."' --critical '".$service["critical"]."'";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => " Graph Connection Time",
                            "use" => "xiwizard_microsoft_365_service",
                            "check_command" => "check_xi_microsoft_365!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "process":

                        foreach ((array) $args as $counter_name => $services) {
                            if (empty($counter_name)) {
                                continue;
                            }

                            $filter = (array_key_exists('filter', $services) ? $services['filter'] : false);

                            foreach ((array) $services as $i => $service) {
                                # Skips if not checked (monitor)
                                # Skips higher level data, like the filter entry (!numeric).
                                if (!is_numeric($i) || !array_key_exists('monitor', $service)) {
                                    continue;
                                }


                                # Make sure the service_description(s) are unique, legal for performance data and short.
                                # NOTE: @ characters break the performance data, when in the service_description.
                                $svcDscExtension = "";

                                if (array_key_exists('displayName', $service) || array_key_exists('product', $service)) {

                                    # Since @ are break performance data, and only a complete email address is guaranteed to be
                                    # unique (hopefully), add an encoded version of the email address to the service_description,
                                    # after the displayName.
                                    if (array_key_exists('user', $service)) {
                                        $offset = strlen($service['user']." - ");
                                        $displayName = substr($service['displayName'], $offset);

                                        $svcDscExtension .= " - ".$displayName;
                                        $svcDscExtension .= " - ".substr(md5($service['user']), -6); # Last 6 characters
                                    }

                                    if (array_key_exists('group', $service)) {
                                        $length = strlen($service['displayName']) - strlen(" - ".$service['group']);
                                        $displayName = substr($service['displayName'], 0, $length);

                                        $svcDscExtension .= " - ".$displayName;
                                        $svcDscExtension .= " - ".substr($service['group'], -6); # Last 6 characters
                                    }

                                    if (array_key_exists('product', $service)) {
                                        # Make an acronym.
                                        $expr = '/(?<=\s|^)[a-z]|[\d]/i';
                                        preg_match_all($expr, $service['product'], $matches);
                                        $acronym = implode('', $matches[0]);

                                        $svcDscExtension .= " - ".$acronym;
                                    }
                                }

                                $pluginCustomOpts  = "--mode '".$counter_name."' --warning '".$service['warning']."' --critical '".$service['critical']."' ";

                                #if (array_key_exists('filterIdx', $modelist)) {
                                if ($filter) {
                                    $pluginCustomOpts .= " --filter '".$service[$filter]."'";
                                }

                                $serviceDescription = $modelist[$counter_name]['name'].$svcDscExtension;

                                $objs[] = array(
                                    "type" => OBJECTTYPE_SERVICE,
                                    "host_name" => $hostname,
                                    "service_description" => $serviceDescription,
                                    "use" => "xiwizard_microsoft_365_service",
                                    "_xiwizard" => $wizard_name,
                                    "check_command" => "check_xi_microsoft_365!".$pluginopts.$pluginCustomOpts,
                                );
                            }
                        }
                        break;
                }
            }

#            echo "OBJECTS:<BR>";
#            print_r($objs);
#            exit();

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;


        default:
            break;
    }

    return $output;
}

#############################################################################################################################
# Wizard data requests using check_microsoft_365.php plugin.
#
# time2token:   The time it takes to get the security token from MicroSoft Identity Platform (MSIP)
#       --appid=749628a7-XXXX-XXXX-XXXX-480485c2cfc3 --tenant=b45d6a6c-XXXX-XXXX-XXXX-b155bbbd594a
#       --secret=R98Hx1X~FK~XXXXXXX~3.31K5gti-bH5nR
#       -w 5 -c 10 --mode time2token
#
# modelist:     Modes/services available to users.
#       --modelist
#
#
#
const RETURN_JSON = "json";
const RETURN_CODE = "return_code";
const RETURN_DATA = "return_data";
const RETURN_VALUE = "return_value";
const RETURN_OK_OR_DATA = "return_ok_or_data";

# Verify connectivity to Microsoft Graph with the appid, tenant and secret, provided.
# NOTE: time2token is probably sufficient.  If not, hit the MS Graph endpoint (time2connect).  If we are using more
#       endpoints, than just MS Graph, figure something out.  Maybe check each endpoint as it it chosen.
#       Checking each mode/service may be necessary, if there are permission issues.
function msip_auth_check($appid, $tenant, $secret) {
    return plugin_data_request(" --appid ".escapeshellarg($appid)." --tenant ".escapeshellarg($tenant)." --secret ".escapeshellarg($secret)." -w 5 -c 10 --mode time2token", RETURN_OK_OR_DATA);
}

function is_data_concealed($appid, $tenant, $secret) {
    $results = plugin_report_data($appid, $tenant, $secret, 'reportdatauserslist');

    if (preg_match('/\@/', $results) > 0) {
        return false;
    }

    return true;
}

function plugin_data($appid, $tenant, $secret, $mode) {
    return plugin_data_request(" --appid ".escapeshellarg($appid)." --tenant ".escapeshellarg($tenant)." --secret ".escapeshellarg($secret)." -w 0 -c 0 --mode ".escapeshellarg($mode), RETURN_VALUE);
}

function plugin_report_data($appid, $tenant, $secret, $mode) {
    return plugin_data_request(" --appid ".escapeshellarg($appid)." --tenant ".escapeshellarg($tenant)." --secret ".escapeshellarg($secret)." -w 0 -c 0 --mode ".escapeshellarg($mode), RETURN_JSON);
}

function mode_list($appid, $tenant, $secret) {
    return plugin_data_request(" --appid ".escapeshellarg($appid)." --tenant ".escapeshellarg($tenant)." --secret ".escapeshellarg($secret)." -w 0 -c 0 --mode modelist", RETURN_DATA);
}

# Data for drop downs.
function plugin_data_request($cmdString, $type=RETURN_JSON) {
    $returnCode = 0;

    $cmd = "/usr/local/nagios/libexec/check_microsoft_365.php ".$cmdString;

    # If this is the concealed data check, use --refresh to make sure we are getting the latest data (not cached).
    if (strpos($cmd, "reportdatauserslist") !== false) {
        $cmd .= " --refresh";
    }

    exec($cmd, $data, $returnCode);

    if ($type == RETURN_DATA && !$returnCode) {
        $dataArray = json_decode($data[0], true);

        if (json_last_error() == JSON_ERROR_NONE) {
            return $dataArray;
        }

        return json_last_error();
    }

    if ($type == RETURN_VALUE) {
        if (is_array($data)) {
            $dataArray = json_decode($data['0'], true);

            # How do errors like this need to be handled??
            # TODO: Handle errors
            if (!is_array($dataArray)) {
                # TODO: Development accounts, which no longer support reports, will have errors.
#                echo("ERROR! [".$data['0']."]");
            }

            if (is_array($dataArray)) {
                $dataArray = current($dataArray);
            }

            return $dataArray;
        }
    }

    $data = implode(PHP_EOL, $data);

    if ($type == RETURN_OK_OR_DATA) {
        if ($returnCode) {
            return $data;
        }

        return $returnCode;
    }

    if ($type == RETURN_CODE || $returnCode) {
        return $returnCode;
    }

    if ($type == RETURN_JSON) {
        if (!$data) {
            return 2; // Not JSON data
        }
        # If we have data, return $data
    }

    return $data;
}

?>
