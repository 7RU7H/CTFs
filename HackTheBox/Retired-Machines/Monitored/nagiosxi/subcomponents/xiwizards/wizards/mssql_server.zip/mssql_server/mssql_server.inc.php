<?php
//
// MSSQL Server Config Wizard
// Copyright (c) 2010-2022 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__).'/../configwizardhelper.inc.php');

mssqlserver_configwizard_init();

function mssqlserver_configwizard_init()
{
    $name = "mssql_server";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "2.0.6",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Monitor a MSSQL Server"),
        CONFIGWIZARD_DISPLAYTITLE => _("MSSQL Server"),
        CONFIGWIZARD_FUNCTION => "mssqlserver_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "mssqlserver.png",
        CONFIGWIZARD_FILTER_GROUPS => array('windows','database'),
        CONFIGWIZARD_REQUIRES_VERSION => 500
    );
    register_configwizard($name, $args);
}


/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */
function mssqlserver_configwizard_func($mode = "", $inargs = null, &$outargs, &$result)
{
    $wizard_name = "mssql_server";

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    switch ($mode) {
        case CONFIGWIZARD_MODE_GETSTAGE1HTML:

            $address = grab_array_var($inargs, "ip_address", "");
            $port = grab_array_var($inargs, "port", "1433");
            $instance = grab_array_var($inargs, "instance", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");

            $output = '
<h5 class="ul">'._('MSSQL Server').'</h5>
<p>'._('Specify the details for connecting to the MSSQL Server you want to monitor').'.</p>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <label>'._('Address').':</label>
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="'.encode_form_val($address).'" class="textfield form-control">
            <div class="subtext">'._('The IP address or FQDNS name of the MSSQL server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Instance').':</label>
        </td>
        <td>
            <input type="text" size="40" name="instance" id="instance" value="'.encode_form_val($instance).'" class="textfield form-control">
            <div class="subtext">'._('The Instance Name to connect to MSSQL Server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Port').':</label>
        </td>
        <td>
            <input type="text" size="10" name="port" id="port" value="'.encode_form_val($port).'" class="textfield form-control">
            <div class="subtext">'._('The port to use to connect to MSSQL server. Default is 1433.  NOTE: Delete this entry if you provided an Instance Name.').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Version').':</label>
        </td>
        <td>
            <select name="version" id="version" class="form-control">
                <option value="" disabled selected></option>
                <option value="PDW" '.is_selected($version, "PDW").'>'._('Parallel Data Warehouse').'</option>
                <option value="SQLDW" '.is_selected($version, "SQLDW").'>'._('Azure Synapse Analytics (SQL DW)').'</option>
                <option value="AZURESQLDB" '.is_selected($version, "AZURESQLDB").'>'._('Azure SQL DB').'</option>
                <option value="2019" '.is_selected($version, "2019").'>'._('2019 (Seattle)').'</option>
                <option value="2017" '.is_selected($version, "2017").'>'._('2017 (Helsinki)').'</option>
                <option value="2016" '.is_selected($version, "2016").'>'._('2016 (SQL16)').'</option>
                <option value="2014" '.is_selected($version, "2014").'>'._('2014 (SQL14)').'</option>
                <option value="2012" '.is_selected($version, "2012").'>'._('2012 (Denali)').'</option>
                <option value="2008-R2" '.is_selected($version, "2008-R2").'>'._('2008 R2 (Kilimanjaro)').'</option>
                <option value="2008" '.is_selected($version, "2008").'>'._('2008 (Katmai)').'</option>
                <option value="2005" '.is_selected($version, "2005").'>'._('2005 (Yukon)').'</option>
                <option value="2000-64" '.is_selected($version, "2000-64").'>'._('2000 64-bit (Liberty)').'</option>
                <option value="2000" '.is_selected($version, "2000").'>'._('2000 (Shiloh)').'</option>
                <option value="other" '.is_selected($version, "other").'>'._('Other').'</option>
            </select>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Username').':</label>
        </td>
        <td>
            <input type="text" size="40" name="username" id="username" value="'.encode_form_val($username).'" class="textfield form-control">
            <div class="subtext">'._('The username used to connect to the MSSQL server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Password').':</label>
        </td>
        <td>
            <input type="password" size="128" name="password" id="password" value="' . encode_form_val($password) . '" class="textfield usermacro-detection form-control" autocomplete="off">
            <button type="button" style="vertical-align: top;" class="btn btn-sm btn-default tt-bind btn-show-secret" title="'._("Show secret").'"><i class="fa fa-eye"></i></button>
            <div class="subtext">'._('The password used to connect to the MSSQL server').'.</div>
        </td>
    </tr>
</table>

<script type="text/javascript">
    // Show or hide secret section
    $(\'.btn-show-secret\').click(function() {
        var type = $(this).parent().find(\'input\').attr(\'type\');
        var tooltip_id = $(this).attr(\'aria-describedby\');

        if (type == \'password\') {
            $(this).parent().find(\'input\').attr(\'type\', \'input\');
            $(this).attr(\'data-original-title\', _("Hide secret"));
            $(\'#\'+tooltip_id+\' .tooltip-inner\').text(_("Hide secret"));
            $(this).find(\'i\').removeClass(\'fa-eye\').addClass(\'fa-eye-slash\');
        } else {
            $(this).parent().find(\'input\').attr(\'type\', \'password\');
            $(this).attr(\'data-original-title\', _("Show secret"));
            $(\'#\'+tooltip_id+\' .tooltip-inner\').text(_("Show secret"));
            $(this).find(\'i\').removeClass(\'fa-eye-slash\').addClass(\'fa-eye\');
        }
    });
</script>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");

            $address = nagiosccm_replace_user_macros($address);
            $port = nagiosccm_replace_user_macros($port);
            $username = nagiosccm_replace_user_macros($username);
            $password = nagiosccm_replace_user_macros($password);

            $use_2008_deprecated_stats = false;     # Tests that are deprecated (not available) after 2008
            $use_2008_plus_stats = true;            # Tests available in 2008 and newer.
            $use_2014_plus_stats = true;            # Tests available in 2014 and newer.
            
            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (have_value($address) == false)
                $errmsg[$errors++] = _("No address specified.");
            if (have_value($version) == false)
                $errmsg[$errors++] = _("No version specified.");
            if (have_value($port) == false && have_value($instance) == false)
                $errmsg[$errors++] = _("No port number or instance name specified.\nOne must be specified.");
            if (have_value($username) == false)
                $errmsg[$errors++] = _("No username specified.");
            if (have_value($password) == false)
                $errmsg[$errors++] = _("No password specified.");
            if ($port && $instance) {
                // instance overrides port
                $inargs["port"] = "";   // This is also handled in the plugin.
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $instance = grab_array_var($inargs, "instance", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");

            $use_2008_deprecated_stats = false;
            $use_2008_plus_stats = true;
            $use_2014_plus_stats = true;

            switch ($version) {
                
                // Free Pages, Stolen Pages and Total Pages, should work for these versions (2008 R2 has been verified)
                case "2000":
                case "2000-64":
                case "2005":
                    $use_2008_plus_stats = false;       # Works with 2008+
                case "2008":
                case "2008-R2":
                    $use_2008_deprecated_stats = true;  # Works with 2008 or lower
                case "2012":
                    $use_2014_plus_stats = false;       # Works with 2014+
                    break;

            }
            
            $ha = @gethostbyaddr($address);

            if ($ha == "")
                $ha = $address;

            $hostname = grab_array_var($inargs, "hostname", $ha);

            $services = grab_array_var($inargs, "services", array_merge(
                array(
                    "autoparamattempts" => "on",    # new
                    "avglatchwait" => "on",         # new
                    "averagewait" => "on",
                    "batchreq" => "on",             # missing from the wizard
                    "bufferhitratio" => "on",
                    "cachehit" => "on",             # missing from the wizard
                    "cacheobjcounts" => "on",       # new
                    "cacheobjsinuse" => "on",       # new
                    "cachepages" => "on",           # new
                    "checkpoints" => "on",
                    "connectiontime" => "on",
                    "connections" => "on",          # missing from the wizard
                    "cpu" => "on",                  # missing from the wizard
                    "databasepages" => "on",
                    "deadlocks" => "on",
                    "failedautoparams" => "on",     # new
                    "forwardedrecords" => "on",     # new
                    "freeliststalls" => "on",       # new
                    "fullscans" => "on",            # missing from the wizard
                    "grantedwsmem" => "on",         # new
                    "indexsearches" => "on",        # new
                    "latchwaits" => "on",           # new
                    "lazywrites" => "on",
                    "lockrequests" => "on",
                    "locktimeouts" => "on",
                    "lockwait" => "on",
                    "lockwaits" => "on",
                    "logins" => "on",               # new
                    "logouts" => "on",              # new
                    "longesttrans" => "on",         # new
                    "maxwsmem" => "on",             # new
                    "memgrantsoutstand" => "on",    # new
                    "memgrantspend" => "on",        # new
                    "numsuperlatches" => "on",      # new
                    "pagelife" => "on",             # missing from the wizard
                    "pagelooks" => "on",
                    "pagereads" => "on",
                    "pagesplits" => "on",
                    "pagewrites" => "on",
                    "processesblocked" => "on",     # new
                    "readahead" => "on",
                    "safeautoparams" => "on",       # new
                    "sqlattentionrate" => "on",     # new
                    "sqlcompilations" => "on",      # missing from the wizard
                    "sqlrecompilations" => "on",    # new
                    "superlatchdemotes" => "on",    # new
                    "superlatchpromotes" => "on",   # new
                    "tablelockescalate" => "on",    # new
                    "targetpages" => "on",
                    "targetsrvmem" => "on",         # new
                    "totallatchwait" => "on",       # new
                    "totalsrvmem" => "on",          # new
                    "unsafeautoparams" => "on",     # new
                    "usercons" => "on",             # new
                    "workfilescreated" => "on",     # new
                    "worktablescreated" => "on",    # new
                ),
                (($use_2008_plus_stats) ?
                    array(
                        "connectionreset" => "on",  # new
                        "memory" => "on",           # missing from the wizard
                    ) : array()
                ),
                (($use_2008_deprecated_stats) ?
                    array(
                        "freepages" => "on",
                        "stolenpages" => "on",
                        "totalpages" => "on",       # missing from the wizard
                    ) : array()
                ),
                (($use_2014_plus_stats) ?
                    array(
                        "worktablescacheratio" => "on", # new
                    ) : array()
                )
            ));

            $serviceargs = grab_array_var($inargs, "serviceargs", array_merge(
                array(
                    "autoparamattempts_warning" => "100",   # new - delta
                    "autoparamattempts_critical" => "200",  # new - delta
                    "avglatchwait_warning" => "100",        # new - delta ratio
                    "avglatchwait_critical" => "200",       # new - delta ratio
                    "averagewait_warning" => "20",
                    "averagewait_critical" => "30",
                    "batchreq_warning" => "20",         # missing from the wizard
                    "batchreq_critical" => "30",        # missing from the wizard
                    "bufferhitratio_warning" => "90",
                    "bufferhitratio_critical" => "95",
                    "cachehit_warning" => "20",         # missing from the wizard
                    "cachehit_critical" => "30",        # missing from the wizard
                    "cacheobjcounts_warning" => "10",   # new - standard (point in time)
                    "cacheobjcounts_critical" => "20",  # new - standard (point in time)
                    "cacheobjsinuse_warning" => "10",   # new - standard (point in time)
                    "cacheobjsinuse_critical" => "20",  # new - standard (point in time)
                    "cachepages_warning" => "500",      # new - standard (point in time)
                    "cachepages_critical" => "1000",    # new - standard (point in time)
                    "checkpoints_warning" => "20",
                    "checkpoints_critical" => "30",
                    "connectiontime_warning" => "1",
                    "connectiontime_critical" => "5",
                    "connections_warning" => "20",      # missing from the wizard
                    "connections_critical" => "30",     # missing from the wizard
                    "cpu_warning" => "20",              # missing from the wizard
                    "cpu_critical" => "30",             # missing from the wizard
                    "databasepages_warning" => "300",
                    "databasepages_critical" => "600",
                    "deadlocks_warning" => "20",
                    "deadlocks_critical" => "30",
                    "failedautoparams_warning" => "50",     # new - delta
                    "failedautoparams_critical" => "100",   # new - delta
                    "forwardedrecords_warning" => "50",     # new - delta
                    "forwardedrecords_critical" => "100",   # new - delta
                    "freeliststalls_warning" => "2",        # new - delta
                    "freeliststalls_critical" => "4",       # new - delta
                    "fullscans_warning" => "20",        # missing from the wizard
                    "fullscans_critical" => "30",       # missing from the wizard
                    "grantedwsmem_warning" => "10",         # new - standard (point in time)
                    "grantedwsmem_critical" => "20",        # new - standard (point in time)
                    "indexsearches_warning" => "5000",      # new - delta
                    "indexsearches_critical" => "10000",    # new - delta
                    "latchwaits_warning" => "1000",         # new - delta
                    "latchwaits_critical" => "5000",        # new - delta
                    "lazywrites_warning" => "20",
                    "lazywrites_critical" => "30",
                    "lockrequests_warning" => "20",
                    "lockrequests_critical" => "30",
                    "locktimeouts_warning" => "20",
                    "locktimeouts_critical" => "30",
                    "lockwaits_warning" => "20",            # Ideally 0 or close to 0
                    "lockwaits_critical" => "30",
                    "lockwait_warning" => "2000",
                    "lockwait_critical" => "3000",
                    "logins_warning" => "2",                # new - delta
                    "logins_critical" => "4",               # new - delta
                    "logouts_warning" => "2",               # new - delta
                    "logouts_critical" => "4",              # new - delta
                    "longesttrans_warning" => "5",          # new - standard (seconds)
                    "longesttrans_critical" => "10",        # new - standard (seconds)
                    "maxwsmem_warning" => "1600000",        # new - standard
                    "maxwsmem_critical" => "2000000",       # new - standard
                    "memgrantsoutstand_warning" => "0",     # new - standard
                    "memgrantsoutstand_critical" => "1",    # new - standard
                    "memgrantspend_warning" => "0",         # new - standard
                    "memgrantspend_critical" => "1",        # new - standard
                    "numsuperlatches_warning" => "10",      # new - standard
                    "numsuperlatches_critical" => "20",     # new - standard
                    "pagelife_warning" => "20",         # missing from the wizard
                    "pagelife_critical" => "30",        # missing from the wizard
                    "pagelooks_warning" => "10",
                    "pagelooks_critical" => "20",
                    "pagereads_warning" => "20",
                    "pagereads_critical" => "30",
                    "pagesplits_warning" => "20",           # Ideally < 20% of batch requests/sec
                    "pagesplits_critical" => "30",
                    "pagewrites_warning" => "20",
                    "pagewrites_critical" => "30",
                    "processesblocked_warning" => "0",      # new - standard - Ideally 0 (nothing blocked)
                    "processesblocked_critical" => "3",     # new - standard
                    "readahead_warning" => "40",
                    "readahead_critical" => "50",
                    "safeautoparams_warning" => "20",       # new - delta - ???
                    "safeautoparams_critical" => "50",      # new - delta
                    "sqlattentionrate_warning" => "1",      # new - delta - lower the better
                    "sqlattentionrate_critical" => "5",     # new - delta
                    "sqlcompilations_warning" => "20",  # missing from the wizard - ideally 1 compile/10 batch requests.
                    "sqlcompilations_critical" => "30", # missing from the wizard
                    "sqlrecompilations_warning" => "5",     # new - delta - ideally less than 10% of compilations/sec
                    "sqlrecompilations_critical" => "10",   # new - delta
                    "superlatchdemotes_warning" => "5",     # new - delta
                    "superlatchdemotes_critical" => "10",   # new - delta
                    "superlatchpromotes_warning" => "5",    # new - delta
                    "superlatchpromotes_critical" => "10",  # new - delta
                    "tablelockescalate_warning" => "5",     # new - delta
                    "tablelockescalate_critical" => "10",   # new - delta
                    "targetpages_warning" => "70000",
                    "targetpages_critical" => "90000",
                    "targetsrvmem_warning" => "1900000",    # new - standard
                    "targetsrvmem_critical" => "2000000",   # new - standard
                    "totallatchwait_warning" => "5",        # new - delta
                    "totallatchwait_critical" => "10",      # new - delta
                    "totalsrvmem_warning" => "1500000",     # new - standard
                    "totalsrvmem_critical" => "1200000",    # new - standard
                    "unsafeautoparams_warning" => "5",      # new - delta - lower is better
                    "unsafeautoparams_critical" => "10",    # new - delta
                    "usercons_warning" => "20",             # new - standard
                    "usercons_critical" => "50",            # new - standard
                    "workfilescreated_warning" => "20",     # new - delta
                    "workfilescreated_critical" => "30",    # new - delta
                    "worktablescreated_warning" => "20",    # new - delta
                    "worktablescreated_critical" => "30",   # new - delta
                ),
                (($use_2008_plus_stats) ?
                    array(
                        "connectionreset_warning" => "1000",    # new
                        "connectionreset_critical" => "2000",   # new
                        "memory_warning" => "20",   # missing from the wizard
                        "memory_critical" => "30",  # missing from the wizard
                    ) : array()
                ),
                (($use_2008_deprecated_stats) ?
                    array(
                        "freepages_warning" => "10",
                        "freepages_critical" => "20",
                        "stolenpages_warning" => "500",
                        "stolenpages_critical" => "700",
                        "totalpages_warning" => "500",  # missing from the wizard
                        "totalpages_critical" => "700", # missing from the wizard
                    ) : array()
                ),
                (($use_2014_plus_stats) ?
                    array(
                        "worktablescacheratio_warning" => "95:",
                        "worktablescacheratio_critical" => "90:",
                    ) : array()
                )
            ));

            $services_serial = grab_array_var($inargs, "services_serial");

            if ($services_serial != "") {
                $services = json_decode(base64_decode($services_serial), true);
            }

            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial");

            if ($serviceargs_serial != "") {
                $serviceargs = json_decode(base64_decode($serviceargs_serial), true);
            }

            // Create only one default process to monitor... we will add more via JS if someone wants to add more
            $default_services['process'][0]['monitor'] = 'off';
            $default_services['process'][0]['counter_name'] = '';
            $default_services['process'][0]['display_name'] = '';
            $default_services['process'][0]['instance_name'] = '';
            $default_services['process'][0]['unit'] = '';
            $default_services['process'][0]['modifier'] = '';
            $default_services['process'][0]['ring_buffer_type'] = '';
            $default_services['process'][0]['xpath'] = '';
            $default_services['process'][0]['warning'] = 60;
            $default_services['process'][0]['critical'] = 100;

            if (!isset($services['process'])) {
                $services = array_merge($services, $default_services);
            }

            $output = '
<input type="hidden" name="ip_address" value="'.encode_form_val($address).'">
<input type="hidden" name="instance" value="'.encode_form_val($instance).'">
<input type="hidden" name="port" value="'.encode_form_val($port).'">
<input type="hidden" name="version" value="'.encode_form_val($version).'">
<input type="hidden" name="username" value="'.encode_form_val($username).'">
<input type="hidden" name="password" value="'.encode_form_val($password).'">
<input type="hidden" name="instancename" value="'.encode_form_val($instancename).'">

<h5 class="ul">'._('MSSQL Server').'</h5>
<table class="table table-condensed table-no-border table-auto-width">
    <tr>
        <td>
            <label>'._('Address').':</label>
        </td>
        <td>
            <input type="text" size="40" name="ip_address" id="ip_address" value="'.encode_form_val($address).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Host Name').':</label>
        </td>
        <td>
            <input type="text" size="40" name="hostname" id="hostname" value="'.encode_form_val($hostname).'" class="textfield form-control">
            <div class="subtext">'._('The name you\'d like to have associated with this MSSQL Database').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Version').':</label>
        </td>
        <td>
            <select name="version" id="version" class="form-control" disabled>
                <option value="PDW" '.is_selected($version, "PDW").'>'._('Parallel Data Warehouse').'</option>
                <option value="SQLDW" '.is_selected($version, "SQLDW").'>'._('Azure Synapse Analytics (SQL DW)').'</option>
                <option value="AZURESQLDB" '.is_selected($version, "AZURESQLDB").'>'._('Azure SQL DB').'</option>
                <option value="2019" '.is_selected($version, "2019").'>'._('2019 (Seattle)').'</option>
                <option value="2017" '.is_selected($version, "2017").'>'._('2017 (Helsinki)').'</option>
                <option value="2016" '.is_selected($version, "2016").'>'._('2016 (SQL16)').'</option>
                <option value="2014" '.is_selected($version, "2014").'>'._('2014 (SQL14)').'</option>
                <option value="2012" '.is_selected($version, "2012").'>'._('2012 (Denali)').'</option>
                <option value="2008-R2" '.is_selected($version, "2008-R2").'>'._('2008 R2 (Kilimanjaro)').'</option>
                <option value="2008" '.is_selected($version, "2008").'>'._('2008 (Katmai)').'</option>
                <option value="2005" '.is_selected($version, "2005").'>'._('2005 (Yukon)').'</option>
                <option value="2000-64" '.is_selected($version, "2000-64").'>'._('2000 64-bit (Liberty)').'</option>
                <option value="2000" '.is_selected($version, "2000").'>'._('2000 (Shiloh)').'</option>
                <option value="other" '.is_selected($version, "other").'>'._('Other').'</option>
                <option value="" disabled> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </option>
            </select>
            <div class="subtext">'._('Version of MSSQL server').'.</div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <label>'._('Instance').':</label>
        </td>
        <td>
            <input type="text" size="40" name="instance" id="instance" value="'.encode_form_val($instance).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>'._('Port').':</label>
        </td>
        <td>
            <input type="text" size="10" name="port" id="port" value="'.encode_form_val($port).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>'._('Username').':</label>
        </td>
        <td>
            <input type="text" size="40" name="username" id="username" value="'.encode_form_val($username).'" class="textfield form-control" disabled>
        </td>
    </tr>
    <tr>
        <td>
            <label>'._('Password').':</label>
        </td>
        <td>
            <input type="password" size="128" name="password" id="password" value="'.encode_form_val($password).'" class="textfield form-control" disabled>
        </td>
    </tr>
</table>

<h5 class="ul">'._('MSSQL Server Metrics').'</h5>
<p>'._('Specify the metrics you\'d like to monitor on the MSSQL Server').'.</p>
<table class="table table-no-border table-auto-width">
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[autoparamattempts]" '.is_checked(grab_array_var($services, "autoparamattempts"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Auto-Param Attempts/sec').'</b><br>
                '._('Monitor the number of auto-parameterization attempts per second.').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[autoparamattempts_warning]" value="'.encode_form_val($serviceargs["autoparamattempts_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[autoparamattempts_critical]" value="'.encode_form_val($serviceargs["autoparamattempts_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[avglatchwait]" '.is_checked(grab_array_var($services, "avglatchwait"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Average Latch Wait Time (ms)').'</b><br>
                '._('Monitor the average time in milliseconds, for any latch requests that had to wait.').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[avglatchwait_warning]" value="'.encode_form_val($serviceargs["avglatchwait_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[avglatchwait_critical]" value="'.encode_form_val($serviceargs["avglatchwait_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[averagewait]" '.is_checked(grab_array_var($services, "averagewait"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Average Wait Time').'</b><br>
                '._('Monitor the average wait time for execution').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[averagewait_warning]" value="'.encode_form_val($serviceargs["averagewait_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[averagewait_critical]" value="'.encode_form_val($serviceargs["averagewait_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[batchreq]" '.is_checked(grab_array_var($services, "batchreq"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Batch Requests').'</b><br>
                '._('Monitor the number of batch requests/sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[batchreq_warning]" value="'.encode_form_val($serviceargs["batchreq_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[batchreq_critical]" value="'.encode_form_val($serviceargs["batchreq_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="bhr" class="checkbox" name="services[bufferhitratio]" '.is_checked(grab_array_var($services, "bufferhitratio"), "on").'>
        </td>
        <td>
            <label class="normal" for="bhr">
                <b>'._('Buffer Hit Ratio').'</b><br>
                '._('Monitor the Buffer Hit Ratio').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[bufferhitratio_warning]" value="'.encode_form_val($serviceargs["bufferhitratio_warning"]).'" class="form-control condensed">&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[bufferhitratio_critical]" value="'.encode_form_val($serviceargs["bufferhitratio_critical"]).'" class="form-control condensed">
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="bhr" class="checkbox" name="services[cachehit]" '.is_checked(grab_array_var($services, "cachehit"), "on").'>
        </td>
        <td>
            <label class="normal" for="bhr">
                <b>'._('Cache Hit Ratio').'</b><br>
                '._('Monitor the Cache Hit Ratio').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[cachehit_warning]" value="'.encode_form_val($serviceargs["cachehit_warning"]).'" class="form-control condensed">&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[cachehit_critical]" value="'.encode_form_val($serviceargs["cachehit_critical"]).'" class="form-control condensed">
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[cacheobjcounts]" '.is_checked(grab_array_var($services, "cacheobjcounts"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Cache Object Counts').'</b><br>
                '._('Monitor the number of objects in the cache').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[cacheobjcounts_warning]" value="'.encode_form_val($serviceargs["cacheobjcounts_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[cacheobjcounts_critical]" value="'.encode_form_val($serviceargs["cacheobjcounts_critical"]).'" class="form-control condensed">
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[cacheobjsinuse]" '.is_checked(grab_array_var($services, "cacheobjsinuse"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Cache Objects in use').'</b><br>
                '._('Monitor the number of cache objects in use').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[cacheobjsinuse_warning]" value="'.encode_form_val($serviceargs["cacheobjsinuse_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[cacheobjsinuse_critical]" value="'.encode_form_val($serviceargs["cacheobjsinuse_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[cachepages]" '.is_checked(grab_array_var($services, "cachepages"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Cache Pages').'</b><br>
                '._('Monitor the number of 8-kilobyte pages used by cache objects').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[cachepages_warning]" value="'.encode_form_val($serviceargs["cachepages_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[cachepages_critical]" value="'.encode_form_val($serviceargs["cachepages_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="cp" class="checkbox" name="services[checkpoints]" '.is_checked(grab_array_var($services, "checkpoints"), "on").'>
        </td>
        <td>
            <label class="normal" for="cp">
                <b>'._('Checkpoint Pages/sec').'</b><br>
                '._('The number of dirty pages per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[checkpoints_warning]" value="'.encode_form_val($serviceargs["checkpoints_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[checkpoints_critical]" value="'.encode_form_val($serviceargs["checkpoints_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>';

            if ($use_2008_plus_stats) {

                $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="lwt" class="checkbox" name="services[connectionreset]" '.is_checked(grab_array_var($services, "connectionreset"), "on").'>
        </td>
        <td>
            <label class="normal" for="lwt">
                <b>'._('Connection reset/sec').'</b><br>
                '._('Total number of logins started from the connection pool (Delta)').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[connectionreset_warning]" value="'.encode_form_val($serviceargs["connectionreset_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[connectionreset_critical]" value="'.encode_form_val($serviceargs["connectionreset_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>';
            }

            $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="ct" class="checkbox" name="services[connectiontime]" '.is_checked(grab_array_var($services, "connectiontime"), "on").'>
        </td>
        <td>
            <label class="normal" for="ct">
                <b>'._('Connection Time').'</b><br>
                '._('Monitor the time it takes to connect to the server').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="1" name="serviceargs[connectiontime_warning]" value="'.encode_form_val($serviceargs["connectiontime_warning"]).'" class="form-control condensed"> sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="1" name="serviceargs[connectiontime_critical]" value="'.encode_form_val($serviceargs["connectiontime_critical"]).'" class="form-control condensed"> sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ct" class="checkbox" name="services[connections]" '.is_checked(grab_array_var($services, "connections"), "on").'>
        </td>
        <td>
            <label class="normal" for="ct">
                <b>'._('Connections').'</b><br>
                '._('Monitor the number of open connections to the server').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="1" name="serviceargs[connections_warning]" value="'.encode_form_val($serviceargs["connections_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="1" name="serviceargs[connections_critical]" value="'.encode_form_val($serviceargs["connections_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ct" class="checkbox" name="services[cpu]" '.is_checked(grab_array_var($services, "cpu"), "on").'>
        </td>
        <td>
            <label class="normal" for="ct">
                <b>'._('CPU Utilization').'</b><br>
                '._('Monitor the current CPU utilization').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="1" name="serviceargs[cpu_warning]" value="'.encode_form_val($serviceargs["cpu_warning"]).'" class="form-control condensed"> %&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="1" name="serviceargs[cpu_critical]" value="'.encode_form_val($serviceargs["cpu_critical"]).'" class="form-control condensed"> %
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="dp" class="checkbox" name="services[databasepages]" '.is_checked(grab_array_var($services, "databasepages"), "on").'>
        </td>
        <td>
            <label class="normal" for="dp">
                <b>'._('Database Pages').'</b><br>
                '._('The amount of database pages').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[databasepages_warning]" value="'.encode_form_val($serviceargs["databasepages_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[databasepages_critical]" value="'.encode_form_val($serviceargs["databasepages_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="d" class="checkbox" name="services[deadlocks]" '.is_checked(grab_array_var($services, "deadlocks"), "on").'>
        </td>
        <td>
            <label class="normal" for="d">
                <b>'._('Deadlocks').'</b><br>
                '._('The amount of deadlocks per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[deadlocks_warning]" value="'.encode_form_val($serviceargs["deadlocks_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[deadlocks_critical]" value="'.encode_form_val($serviceargs["deadlocks_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[failedautoparams]" '.is_checked(grab_array_var($services, "failedautoparams"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Failed Auto-Params/sec').'</b><br>
                '._('Monitor the number of auto-parameterization attempts per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[failedautoparams_warning]" value="'.encode_form_val($serviceargs["failedautoparams_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[failedautoparams_critical]" value="'.encode_form_val($serviceargs["failedautoparams_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[forwardedrecords]" '.is_checked(grab_array_var($services, "forwardedrecords"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Forwarded Records/sec').'</b><br>
                '._('Monitor the pointers created when rows have been moved to a new page in a heap').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[forwardedrecords_warning]" value="'.encode_form_val($serviceargs["forwardedrecords_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[forwardedrecords_critical]" value="'.encode_form_val($serviceargs["forwardedrecords_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[freeliststalls]" '.is_checked(grab_array_var($services, "freeliststalls"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Free List Stalls').'</b><br>
                '._('Monitor the number of requests waiting for a free page/sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[freeliststalls_warning]" value="'.encode_form_val($serviceargs["freeliststalls_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[freeliststalls_critical]" value="'.encode_form_val($serviceargs["freeliststalls_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>';

            if ($use_2008_deprecated_stats) {

                $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="fp" class="checkbox" name="services[freepages]" '.is_checked(grab_array_var($services, "freepages"), "on").'>
        </td>
        <td>
            <label class="normal" for="fp">
                <b>'._('Free Pages').'</b><br>
                '._('Monitor the free pages').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[freepages_warning]" value="'.encode_form_val($serviceargs["freepages_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[freepages_critical]" value="'.encode_form_val($serviceargs["freepages_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>';
            
            }
            
            $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="d" class="checkbox" name="services[fullscans]" '.is_checked(grab_array_var($services, "fullscans"), "on").'>
        </td>
        <td>
            <label class="normal" for="d">
                <b>'._('Full Scans').'</b><br>
                '._('The amount of full scans per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[fullscans_warning]" value="'.encode_form_val($serviceargs["fullscans_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[fullscans_critical]" value="'.encode_form_val($serviceargs["fullscans_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[grantedwsmem]" '.is_checked(grab_array_var($services, "grantedwsmem"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Granted Workspace Memory').'</b><br>
                '._('Monitor the total memory granted to executing processes').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[grantedwsmem_warning]" value="'.encode_form_val($serviceargs["grantedwsmem_warning"]).'" class="form-control condensed"> KB&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[grantedwsmem_critical]" value="'.encode_form_val($serviceargs["grantedwsmem_critical"]).'" class="form-control condensed"> KB
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[indexsearches]" '.is_checked(grab_array_var($services, "indexsearches"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Index Searches/sec').'</b><br>
                '._('Monitor the number of index searches, within an index').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[indexsearches_warning]" value="'.encode_form_val($serviceargs["indexsearches_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[indexsearches_critical]" value="'.encode_form_val($serviceargs["indexsearches_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[latchwaits]" '.is_checked(grab_array_var($services, "latchwaits"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Latch Waits/sec').'</b><br>
                '._('Monitor the number of latches that had to wait, in the last second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[latchwaits_warning]" value="'.encode_form_val($serviceargs["latchwaits_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[latchwaits_critical]" value="'.encode_form_val($serviceargs["latchwaits_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lw" class="checkbox" name="services[lazywrites]" '.is_checked(grab_array_var($services, "lazywrites"), "on").'>
        </td>
        <td>
            <label class="normal" for="lw">
                <b>'._('Lazy Writes').'</b><br>
                '._('The amount of lazy writes per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[lazywrites_warning]" value="'.encode_form_val($serviceargs["lazywrites_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[lazywrites_critical]" value="'.encode_form_val($serviceargs["lazywrites_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lr" class="checkbox" name="services[lockrequests]" '.is_checked(grab_array_var($services, "lockrequests"), "on").'>
        </td>
        <td>
            <label class="normal" for="lr">
                <b>'._('Lock Requests').'</b><br>
                '._('The amount of lock requests per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[lockrequests_warning]" value="'.encode_form_val($serviceargs["lockrequests_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[lockrequests_critical]" value="'.encode_form_val($serviceargs["lockrequests_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lt2" class="checkbox" name="services[locktimeouts]" '.is_checked(grab_array_var($services, "locktimeouts"), "on").'>
        </td>
        <td>
            <label class="normal" for="lt2">
                <b>'._('Lock Timeouts').'</b><br>
                '._('The amount of lock timeouts per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[locktimeouts_warning]" value="'.encode_form_val($serviceargs["locktimeouts_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[locktimeouts_critical]" value="'.encode_form_val($serviceargs["locktimeouts_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lwt" class="checkbox" name="services[lockwait]" '.is_checked(grab_array_var($services, "lockwait"), "on").'>
        </td>
        <td>
            <label class="normal" for="lwt">
                <b>'._('Lock Wait Time').'</b><br>
                '._('Monitor the lock wait time').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[lockwait_warning]" value="'.encode_form_val($serviceargs["lockwait_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[lockwait_critical]" value="'.encode_form_val($serviceargs["lockwait_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lw23" class="checkbox" name="services[lockwaits]" '.is_checked(grab_array_var($services, "lockwaits"), "on").'>
        </td>
        <td>
            <label class="normal" for="lw23">
                <b>'._('Lock Waits').'</b><br>
                '._('The amount of lockwaits per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[lockwaits_warning]" value="'.encode_form_val($serviceargs["lockwaits_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[lockwaits_critical]" value="'.encode_form_val($serviceargs["lockwaits_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[logins]" '.is_checked(grab_array_var($services, "logins"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Logins/sec').'</b><br>
                '._('Monitor the total number of logins started per second (not pooled connections)').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logins_warning]" value="'.encode_form_val($serviceargs["logins_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logins_critical]" value="'.encode_form_val($serviceargs["logins_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[logouts]" '.is_checked(grab_array_var($services, "logouts"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Logouts/sec').'</b><br>
                '._('Monitor the total number of logout operations started per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[logouts_warning]" value="'.encode_form_val($serviceargs["logouts_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[logouts_critical]" value="'.encode_form_val($serviceargs["logouts_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[longesttrans]" '.is_checked(grab_array_var($services, "longesttrans"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Longest Transaction Running Time').'</b><br>
                '._('Monitor the time in seconds, of the longest running transaction').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[longesttrans_warning]" value="'.encode_form_val($serviceargs["longesttrans_warning"]).'" class="form-control condensed"> s&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[longesttrans_critical]" value="'.encode_form_val($serviceargs["longesttrans_critical"]).'" class="form-control condensed"> s
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[maxwsmem]" '.is_checked(grab_array_var($services, "maxwsmem"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Maximum Workspace Memory (KB)').'</b><br>
                '._('Monitor the maximum amount of memory available for processes').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[maxwsmem_warning]" value="'.encode_form_val($serviceargs["maxwsmem_warning"]).'" class="form-control condensed"> KB&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[maxwsmem_critical]" value="'.encode_form_val($serviceargs["maxwsmem_critical"]).'" class="form-control condensed"> KB
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[memgrantsoutstand]" '.is_checked(grab_array_var($services, "memgrantsoutstand"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Memory Grants Outstanding').'</b><br>
                '._('Monitor the total number of processes per second successfully acquiring a workspace memory grant').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[memgrantsoutstand_warning]" value="'.encode_form_val($serviceargs["memgrantsoutstand_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[memgrantsoutstand_critical]" value="'.encode_form_val($serviceargs["memgrantsoutstand_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[memgrantspend]" '.is_checked(grab_array_var($services, "memgrantspend"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Memory Grants Pending').'</b><br>
                '._('Monitor the total number of processes per second waiting for a workspace memory grant').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[memgrantspend_warning]" value="'.encode_form_val($serviceargs["memgrantspend_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[memgrantspend_critical]" value="'.encode_form_val($serviceargs["memgrantspend_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>';

            if ($use_2008_plus_stats) {

                $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="lwt" class="checkbox" name="services[memory]" '.is_checked(grab_array_var($services, "memory"), "on").'>
        </td>
        <td>
            <label class="normal" for="lwt">
                <b>'._('Memory').'</b><br>
                '._('Percent of memory the server is using').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[memory_warning]" value="'.encode_form_val($serviceargs["memory_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[memory_critical]" value="'.encode_form_val($serviceargs["memory_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>';
            }

            $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[numsuperlatches]" '.is_checked(grab_array_var($services, "numsuperlatches"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Number of SuperLatches').'</b><br>
                '._('Monitor the current number of SuperLatches').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[numsuperlatches_warning]" value="'.encode_form_val($serviceargs["numsuperlatches_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[numsuperlatches_critical]" value="'.encode_form_val($serviceargs["numsuperlatches_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="lwt" class="checkbox" name="services[pagelife]" '.is_checked(grab_array_var($services, "pagelife"), "on").'>
        </td>
        <td>
            <label class="normal" for="lwt">
                <b>'._('Page life expectancy').'</b><br>
                '._('Monitor the page life expectancy').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagelife_warning]" value="'.encode_form_val($serviceargs["pagelife_warning"]).'" class="form-control condensed"> s&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagelife_critical]" value="'.encode_form_val($serviceargs["pagelife_critical"]).'" class="form-control condensed"> s
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="pl" class="checkbox" name="services[pagelooks]" '.is_checked(grab_array_var($services, "pagelooks"), "on").'>
        </td>
        <td>
            <label class="normal" for="pl">
                <b>'._('Page Looks').'</b><br>
                '._('Monitor the number of page looks per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagelooks_warning]" value="'.encode_form_val($serviceargs["pagelooks_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagelooks_critical]" value="'.encode_form_val($serviceargs["pagelooks_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="pr" class="checkbox" name="services[pagereads]" '.is_checked(grab_array_var($services, "pagereads"), "on").'>
        </td>
        <td>
            <label class="normal" for="pr">
                <b>'._('Page Reads').'</b><br>
                '._('The amount of page reads per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagereads_warning]" value="'.encode_form_val($serviceargs["pagereads_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagereads_critical]" value="'.encode_form_val($serviceargs["pagereads_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ps" class="checkbox" name="services[pagesplits]" '.is_checked(grab_array_var($services, "pagesplits"), "on").'>
        </td>
        <td>
            <label class="normal" for="ps">
                <b>'._('Page Splits').'</b><br>
                '._('The amount of page splits per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagesplits_warning]" value="'.encode_form_val($serviceargs["pagesplits_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagesplits_critical]" value="'.encode_form_val($serviceargs["pagesplits_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="pw2" class="checkbox" name="services[pagewrites]" '.is_checked(grab_array_var($services, "pagewrites"), "on").'>
        </td>
        <td>
            <label class="normal" for="pw2">
                <b>'._('Page Writes').'</b><br>
                '._('The amount of page writes per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagewrites_warning]" value="'.encode_form_val($serviceargs["pagewrites_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[pagewrites_critical]" value="'.encode_form_val($serviceargs["pagewrites_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[processesblocked]" '.is_checked(grab_array_var($services, "processesblocked"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Processes Blocked').'</b><br>
                '._('Monitor the number of currently blocked processes').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[processesblocked_warning]" value="'.encode_form_val($serviceargs["processesblocked_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[processesblocked_critical]" value="'.encode_form_val($serviceargs["processesblocked_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ra" class="checkbox" name="services[readahead]" '.is_checked(grab_array_var($services, "readahead"), "on").'>
        </td>
        <td>
            <label class="normal" for="ra">
                <b>'._('Read Aheads').'</b><br>
                '._('The amount of readaheads per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[readahead_warning]" value="'.encode_form_val($serviceargs["readahead_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[readahead_critical]" value="'.encode_form_val($serviceargs["readahead_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[safeautoparams]" '.is_checked(grab_array_var($services, "safeautoparams"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Safe Auto-Params/sec').'</b><br>
                '._('Monitor the number of safe auto-parameterization attempts per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[safeautoparams_warning]" value="'.encode_form_val($serviceargs["safeautoparams_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[safeautoparams_critical]" value="'.encode_form_val($serviceargs["safeautoparams_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[sqlattentionrate]" '.is_checked(grab_array_var($services, "sqlattentionrate"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('SQL Attention Rate/sec').'</b><br>
                '._('Monitor the number of cancels and query timeouts occurring per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[sqlattentionrate_warning]" value="'.encode_form_val($serviceargs["sqlattentionrate_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[sqlattentionrate_critical]" value="'.encode_form_val($serviceargs["sqlattentionrate_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="ra" class="checkbox" name="services[sqlcompilations]" '.is_checked(grab_array_var($services, "sqlcompilations"), "on").'>
        </td>
        <td>
            <label class="normal" for="ra">
                <b>'._('SQL Compilations').'</b><br>
                '._('Monitor the sql compilations per sec').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[sqlcompilations_warning]" value="'.encode_form_val($serviceargs["sqlcompilations_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[sqlcompilations_critical]" value="'.encode_form_val($serviceargs["sqlcompilations_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[sqlrecompilations]" '.is_checked(grab_array_var($services, "sqlrecompilations"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('SQL Re-Compilations/sec').'</b><br>
                '._('Monitor the number of statement recompiles per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[sqlrecompilations_warning]" value="'.encode_form_val($serviceargs["sqlrecompilations_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[sqlrecompilations_critical]" value="'.encode_form_val($serviceargs["sqlrecompilations_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>';

            if ($use_2008_deprecated_stats) {

                $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="sp" class="checkbox" name="services[stolenpages]" '.is_checked(grab_array_var($services, "stolenpages"), "on").'>
        </td>
        <td>
            <label class="normal" for="sp">
                <b>'._('Stolen Pages').'</b><br>
                '._('Monitor the amount of stolen pages').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[stolenpages_warning]" value="'.encode_form_val($serviceargs["stolenpages_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[stolenpages_critical]" value="'.encode_form_val($serviceargs["stolenpages_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>';
            }

            $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[superlatchdemotes]" '.is_checked(grab_array_var($services, "superlatchdemotes"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('SuperLatch Demotions/sec').'</b><br>
                '._('Monitor the number of latches demoted from SuperLatches, in the last second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[superlatchdemotes_warning]" value="'.encode_form_val($serviceargs["superlatchdemotes_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[superlatchdemotes_critical]" value="'.encode_form_val($serviceargs["superlatchdemotes_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[superlatchpromotes]" '.is_checked(grab_array_var($services, "superlatchpromotes"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('SuperLatch Promotions/sec').'</b><br>
                '._('Monitor the number of latches promoted to SuperLatches, in the last second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[superlatchpromotes_warning]" value="'.encode_form_val($serviceargs["superlatchpromotes_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[superlatchpromotes_critical]" value="'.encode_form_val($serviceargs["superlatchpromotes_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[tablelockescalate]" '.is_checked(grab_array_var($services, "tablelockescalate"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Table Lock Escalations/sec').'</b><br>
                '._('Monitor the number of times locks escalated from page or row to table-level').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[tablelockescalate_warning]" value="'.encode_form_val($serviceargs["tablelockescalate_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[tablelockescalate_critical]" value="'.encode_form_val($serviceargs["tablelockescalate_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" class="checkbox" name="services[targetpages]" '.is_checked(grab_array_var($services, "targetpages"), "on").'>
        </td>
        <td>
            <label class="normal" for="tp">
                <b>'._('Target Pages').'</b><br>
                '._('The amount of target pages').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[targetpages_warning]" value="'.encode_form_val($serviceargs["targetpages_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[targetpages_critical]" value="'.encode_form_val($serviceargs["targetpages_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[targetsrvmem]" '.is_checked(grab_array_var($services, "targetsrvmem"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Target Server Memory (KB)').'</b><br>
                '._('Monitor the amount of memory SQL Server is using').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[targetsrvmem_warning]" value="'.encode_form_val($serviceargs["targetsrvmem_warning"]).'" class="form-control condensed"> KB&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[targetsrvmem_critical]" value="'.encode_form_val($serviceargs["targetsrvmem_critical"]).'" class="form-control condensed"> KB
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[totallatchwait]" '.is_checked(grab_array_var($services, "totallatchwait"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Total Latch Wait Time (ms)').'</b><br>
                '._('Monitor the total amount of time spent waiting for a latch, in the last second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[totallatchwait_warning]" value="'.encode_form_val($serviceargs["totallatchwait_warning"]).'" class="form-control condensed"> ms&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[totallatchwait_critical]" value="'.encode_form_val($serviceargs["totallatchwait_critical"]).'" class="form-control condensed"> ms
            </div>
        </td>
    </tr>';

            if ($use_2008_deprecated_stats) {

                $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="sp" class="checkbox" name="services[totalpages]" '.is_checked(grab_array_var($services, "totalpages"), "on").'>
        </td>
        <td>
            <label class="normal" for="sp">
                <b>'._('Total Pages').'</b><br>
                '._('The total cumulative amount of pages').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[totalpages_warning]" value="'.encode_form_val($serviceargs["totalpages_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[totalpages_critical]" value="'.encode_form_val($serviceargs["totalpages_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>';
            }

            $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[totalsrvmem]" '.is_checked(grab_array_var($services, "totalsrvmem"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Total Server Memory (KB)').'</b><br>
                '._('Monitor the amount of memory SQL Server is using').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[totalsrvmem_warning]" value="'.encode_form_val($serviceargs["totalsrvmem_warning"]).'" class="form-control condensed"> KB&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[totalsrvmem_critical]" value="'.encode_form_val($serviceargs["totalsrvmem_critical"]).'" class="form-control condensed"> KB
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[unsafeautoparams]" '.is_checked(grab_array_var($services, "unsafeautoparams"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Unsafe Auto-Params/sec').'</b><br>
                '._('Monitor the number of unsafe auto-parameterizations per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[unsafeautoparams_warning]" value="'.encode_form_val($serviceargs["unsafeautoparams_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[unsafeautoparams_critical]" value="'.encode_form_val($serviceargs["unsafeautoparams_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[usercons]" '.is_checked(grab_array_var($services, "usercons"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('User Connections').'</b><br>
                '._('Monitor the number of users currently connected').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[usercons_warning]" value="'.encode_form_val($serviceargs["usercons_warning"]).'" class="form-control condensed"> &nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[usercons_critical]" value="'.encode_form_val($serviceargs["usercons_critical"]).'" class="form-control condensed"> 
            </div>
        </td>
    </tr>
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[workfilescreated]" '.is_checked(grab_array_var($services, "workfilescreated"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Workfiles Created/sec').'</b><br>
                '._('Monitor the number of work files created per second').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[workfilescreated_warning]" value="'.encode_form_val($serviceargs["workfilescreated_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[workfilescreated_critical]" value="'.encode_form_val($serviceargs["workfilescreated_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>';

            if ($use_2014_plus_stats) {

                $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="lwt" class="checkbox" name="services[worktablescacheratio]" '.is_checked(grab_array_var($services, "worktablescacheratio"), "on").'>
        </td>
        <td>
            <label class="normal" for="lwt">
                <b>'._('Worktables From Cache Ratio').'</b><br>
                '._('Percentage of work tables created whose initial two pages were immediately available from the worktable cache').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[worktablescacheratio_warning]" value="'.encode_form_val($serviceargs["worktablescacheratio_warning"]).'" class="form-control condensed"> %&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[worktablescacheratio_critical]" value="'.encode_form_val($serviceargs["worktablescacheratio_critical"]).'" class="form-control condensed"> %
            </div>
        </td>
    </tr>';
            }

            $output .= '
    <tr>
        <td class="vt">
            <input type="checkbox" id="awt" class="checkbox" name="services[worktablescreated]" '.is_checked(grab_array_var($services, "worktablescreated"), "on").'>
        </td>
        <td>
            <label class="normal" for="awt">
                <b>'._('Worktables Created/sec').'</b><br>
                '._('Monitor the number of work tables created from the worktable cache').'.
            </label>
            <div class="pad-t5">
                <label><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label> <input type="text" size="2" name="serviceargs[worktablescreated_warning]" value="'.encode_form_val($serviceargs["worktablescreated_warning"]).'" class="form-control condensed"> /sec&nbsp;&nbsp;<label><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label> <input type="text" size="2" name="serviceargs[worktablescreated_critical]" value="'.encode_form_val($serviceargs["worktablescreated_critical"]).'" class="form-control condensed"> /sec
            </div>
        </td>
    </tr>
</table>
<h5 class="ul">'. _('Custom Metrics'). '</h5>
<p>'. _("Other metrics provided by the performance and Ring Buffer tables."). '</p>
<table class="table table-condensed table-no-border table-auto-width table-padded">
    <thead>
        <tr>
            <td></td>
            <td><label class="normal">'._('Counter Name').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('The counter_name from the sys.sysperfinfo, sys.dm_os_performance_counters, etc. table or the field from the Ring table. ').'"></i></td>
            <td><label class="normal">'._('Display Name').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('A meaningful name for monitoring.  If left blank, it will be generated from the Counter and Instance Names.').'"></i></td>
            <td><label class="normal">'._('Instance Name').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Optional instance_name from sys.sysperfinfo, sys.dm_os_performance_counters, etc.').'"></i></td>
            <td><label class="normal">'._('Unit').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Optional label for unit of measure, e.g., s, ms, MB.').'"></i></td>
            <td><label class="normal">'._('Mod').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Optional multiplication modifier, e.g., 100.').'"></i></td>
            <td><label class="normal">'._('Ring Buffer Type').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Required for Ring Buffer queries.  The ring_buffer_type from the sys.dm_os_ring_buffers table.').'"></i></td>
            <td><label class="normal">'._('XPath').'</label>&nbsp;<i class="fa fa-question-circle pop" data-content="'._('Required for Ring Buffer queries.  The xpath to the value you want to monitor.').'"></i></td>
            <td><label class="normal">'._('Warning').'&nbsp;#</label></td>
            <td><label class="normal">'._('Critical').'&nbsp;#</label></td>
        </tr>
    </thead>
    <tbody id="process-list">';

            foreach ($services['process'] as $i => $metrics) {
                $output .= '
                    <tr>
                        <td><input type="checkbox" style="margin-bottom: 5px" class="checkbox deselect" name="services[process]['.$i.'][monitor]" '.is_checked($metrics['monitor'], 'on'). '></td>
                        <td><input type="text" name="services[process]['.$i.'][counter_name]" value="'.encode_form_val($metrics['counter_name']).'" class="form-control condensed"></td>
                        <td><input type="text" name="services[process]['.$i.'][display_name]" value="'.encode_form_val($metrics['display_name']).'" class="form-control condensed"></td>
                        <td><input type="text" name="services[process]['.$i.'][instance_name]" value="'.encode_form_val($metrics['instance_name']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][unit]" value="'.encode_form_val($metrics['unit']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][modifier]" value="'.encode_form_val($metrics['modifier']).'" class="form-control condensed"></td>
                        <td><input type="text" name="services[process]['.$i.'][ring_buffer_type]" value="'.encode_form_val($metrics['ring_buffer_type']).'" class="form-control condensed"></td>
                        <td><input type="text" name="services[process]['.$i.'][xpath]" value="'.encode_form_val($metrics['xpath']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][warning]" value="'.encode_form_val($metrics['warning']).'" class="form-control condensed"></td>
                        <td><input type="text" size="2" name="services[process]['.$i.'][critical]" value="'.encode_form_val($metrics['critical']).'" class="form-control condensed"></td>
                    </tr>';
            }

            $output .= '
    </tbody>
</table>
<div style="margin: 10px 0 20px 0;">
    <a style="cursor: pointer;" id="add-new-service">'._('Add Another Custom Metric').'</a>
</div>';

            $output .= '
<script type="text/javascript">
    var processnum = ' . (count($services['process']) - 1) . ';

    $(document).ready(function() {

        $("#add-new-service").click(function() {
            processnum++;

            row = "".concat(
\'<tr>\',
\'<td><input type="checkbox" style="margin-bottom: 5px" class="checkbox deselect" name="services[process][\'+processnum+\'][monitor]" checked></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][counter_name]" value=""></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][display_name]" value=""></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][instance_name]" value=""></td>\',
\'<td><input type="text" size=2 class="form-control condensed" name="services[process][\'+processnum+\'][unit]" value=""></td>\',
\'<td><input type="text" size=2 class="form-control condensed" name="services[process][\'+processnum+\'][modifier]" value=""></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][ring_buffer_type]" value=""></td>\',
\'<td><input type="text" class="form-control condensed" name="services[process][\'+processnum+\'][xpath]" value=""></td>\',
\'<td><input type="text" size=2 class="form-control condensed" size="2" name="services[process][\'+processnum+\'][warning]" value="60"></td>\',
\'<td><input type="text" size=2 class="form-control condensed" size="2" name="services[process][\'+processnum+\'][critical]" value="100"></td>\',
\'</tr>\');

            $("#process-list").append(row);
        });
    });

</script>';

            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $hostname = nagiosccm_replace_user_macros($hostname);
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $services = grab_array_var($inargs, "services", array());
            $serviceargs = grab_array_var($inargs, "serviceargs", array());


            // check for errors
            $errors = 0;
            $errmsg = array();
            if (is_valid_host_name($hostname) == false)
                $errmsg[$errors++] = "Invalid host name.";

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }

            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");

            $services = grab_array_var($inargs, "services");
            $serviceargs = grab_array_var($inargs, "serviceargs");

            $output = '
            
        <input type="hidden" name="ip_address" value="'.encode_form_val($address).'" />
        <input type="hidden" name="hostname" value="'.encode_form_val($hostname).'" />
        <input type="hidden" name="port" value="'.encode_form_val($port).'" />
        <input type="hidden" name="version" value="'.encode_form_val($version).'" />
        <input type="hidden" name="instance" value="'.encode_form_val($instance).'" />
        <input type="hidden" name="username" value="'.encode_form_val($username).'" />
        <input type="hidden" name="password" value="'.encode_form_val($password).'" />
        <input type="hidden" name="services_serial" value="'.base64_encode(json_encode($services)).'" />
        <input type="hidden" name="serviceargs_serial" value="'.base64_encode(json_encode($serviceargs)).'" />
';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:


            $output = '
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            $hostname = grab_array_var($inargs, "hostname", "");
            $address = grab_array_var($inargs, "ip_address", "");
            $hostaddress = $address;
            $instance = grab_array_var($inargs, "instance", "");
            $port = grab_array_var($inargs, "port", "");
            $version = grab_array_var($inargs, "version", "");
            $username = grab_array_var($inargs, "username", "");
            $password = grab_array_var($inargs, "password", "");
            $instancename = grab_array_var($inargs, "instancename", "");

            // Escape special characters that might break the config, etc.
            $username = nagiosccm_replace_command_line($username);
            $password = nagiosccm_replace_command_line($password);

            $services_serial = grab_array_var($inargs, "services_serial", "");
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");

            $services = json_decode(base64_decode($services_serial), true);
            $serviceargs = json_decode(base64_decode($serviceargs_serial), true);

            // save data for later use in re-entrance
            $meta_arr = array();
            $meta_arr["hostname"] = $hostname;
            $meta_arr["ip_address"] = $address;
            $meta_arr["port"] = $port;
            $meta_arr["instance"] = $instance;
            $meta_arr["version"] = $version;
            $meta_arr["username"] = $username;
            $meta_arr["password"] = $password;
            $meta_arr["instancename"] = $instancename;
            $meta_arr["services"] = $services;
            $meta_arr["serviceargs"] = $serviceargs;
            save_configwizard_object_meta($wizard_name, $hostname, "", $meta_arr);

            $objs = array();

            if (!host_exists($hostname)) {
                $objs[] = array(
                    "type" => OBJECTTYPE_HOST,
                    "use" => "xiwizard_mssqlserver_host",
                    "host_name" => $hostname,
                    "address" => $hostaddress,
                    "icon_image" => "mssqlserver.png",
                    "statusmap_image" => "mssqlserver.png",
                    "_xiwizard" => $wizard_name,
                );
            }

            $perftype = 'default';

            switch ($version) {
                case "AZURESQLDB":
                    $perftype = 'azuresqldb';
                    break;

                case "PDW":
                    $perftype = 'pdw';
                    break;

                case "SQLDW":
                    $perftype = 'sqldw';
                    break;

                case "2005":
                case " 2000":
                    $perftype = 'deprecated';
                    break;
            }

            // common plugin opts
            // checktype = "server", because this is the "server" wizard.
            $commonopts = " --checktype 'server' -U '$username' -P '$password' --perftype $perftype ";

            $instancetext = '';

            if ($instance) {
                $commonopts .= "-I '$instance' ";
                $instancetext = " - $instance";
            }

            if ($port) {
                $commonopts .= "-p $port ";
            }

            foreach ($services as $service => $args) {

                $pluginopts = "";
                $pluginopts .= $commonopts;

                switch ($service) {

                    case "autoparamattempts":

                        $pluginopts .= "--mode autoparamattempts --warning ".$serviceargs["autoparamattempts_warning"]." --critical ".$serviceargs["autoparamattempts_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Auto-Param Attempts / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "avglatchwait":

                        $pluginopts .= "--mode avglatchwait --warning ".$serviceargs["avglatchwait_warning"]." --critical ".$serviceargs["avglatchwait_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Average Latch Wait Time".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "averagewait":

                        $pluginopts .= "--mode averagewait --warning ".$serviceargs["averagewait_warning"]." --critical ".$serviceargs["averagewait_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Average Wait Time".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "batchreq":

                        $pluginopts .= "--mode batchreq --warning ".$serviceargs["batchreq_warning"]." --critical ".$serviceargs["batchreq_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Batch Requests / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "bufferhitratio":

                        $pluginopts .= "--mode bufferhitratio --warning ".$serviceargs["bufferhitratio_warning"].": --critical ".$serviceargs["bufferhitratio_critical"].":";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Buffer Hit Ratio".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "cachehit":

                        $pluginopts .= "--mode cachehit --warning ".$serviceargs["cachehit_warning"].": --critical ".$serviceargs["cachehit_critical"].":";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Cache Hit Ratio".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "cacheobjcounts":

                        $pluginopts .= "--mode cacheobjcounts --warning ".$serviceargs["cacheobjcounts_warning"]." --critical ".$serviceargs["cacheobjcounts_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Cache Object Counts".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "cacheobjsinuse":

                        $pluginopts .= "--mode cacheobjsinuse --warning ".$serviceargs["cacheobjsinuse_warning"]." --critical ".$serviceargs["cacheobjsinuse_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Cache Objects in use".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "cachepages":

                        $pluginopts .= "--mode cachepages --warning ".$serviceargs["cachepages_warning"]." --critical ".$serviceargs["cachepages_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Cache Pages".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "checkpoints":

                        $pluginopts .= "--mode checkpoints --warning ".$serviceargs["checkpoints_warning"]." --critical ".$serviceargs["checkpoints_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Checkpoint Pages / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "connectiontime":

                        $pluginopts .= "--mode time2connect --warning ".$serviceargs["connectiontime_warning"]." --critical ".$serviceargs["connectiontime_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Connection Time".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "connectionreset":

                        $pluginopts .= "--mode connectionreset --warning ".$serviceargs["connectionreset_warning"]." --critical ".$serviceargs["connectionreset_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Connection reset / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "connections":

                        $pluginopts .= "--mode connections --warning ".$serviceargs["connections_warning"]." --critical ".$serviceargs["connections_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Connections Open".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "cpu":

                        $pluginopts .= "--mode cpu --warning ".$serviceargs["cpu_warning"]." --critical ".$serviceargs["cpu_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL CPU Utilization".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "databasepages":

                        $pluginopts .= "--mode databasepages --warning ".$serviceargs["databasepages_warning"]." --critical ".$serviceargs["databasepages_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Database Pages".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "deadlocks":

                        $pluginopts .= "--mode deadlocks --warning ".$serviceargs["deadlocks_warning"]." --critical ".$serviceargs["deadlocks_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Deadlocks / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "failedautoparams":

                        $pluginopts .= "--mode failedautoparams --warning ".$serviceargs["failedautoparams_warning"]." --critical ".$serviceargs["failedautoparams_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Failed Auto-Params / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "forwardedrecords":

                        $pluginopts .= "--mode forwardedrecords --warning ".$serviceargs["forwardedrecords_warning"]." --critical ".$serviceargs["forwardedrecords_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Forwarded Records / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "freelistalls":

                        $pluginopts .= "--mode freelistalls --warning ".$serviceargs["freelistalls_warning"]." --critical ".$serviceargs["freelistalls_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Free List Stalls / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "freepages":

                        $pluginopts .= "--mode freepages --warning ".$serviceargs["freepages_warning"]." --critical ".$serviceargs["freepages_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Free Pages".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "fullscans":

                        $pluginopts .= "--mode fullscans --warning ".$serviceargs["fullscans_warning"]." --critical ".$serviceargs["fullscans_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Full Scans / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "grantedwsmem":

                        $pluginopts .= "--mode grantedwsmem --warning ".$serviceargs["grantedwsmem_warning"]." --critical ".$serviceargs["grantedwsmem_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Granted Workspace Memory".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "indexsearches":

                        $pluginopts .= "--mode indexsearches --warning ".$serviceargs["indexsearches_warning"]." --critical ".$serviceargs["indexsearches_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Index Searches / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "latchwaits":

                        $pluginopts .= "--mode latchwaits --warning ".$serviceargs["latchwaits_warning"]." --critical ".$serviceargs["latchwaits_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Latch Waits / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "lazywrites":

                        $pluginopts .= "--mode lazywrites --warning ".$serviceargs["lazywrites_warning"]." --critical ".$serviceargs["lazywrites_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Lazy Writes / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "lockrequests":

                        $pluginopts .= "--mode lockrequests --warning ".$serviceargs["lockrequests_warning"]." --critical ".$serviceargs["lockrequests_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Lock Requests / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "locktimeouts":

                        $pluginopts .= "--mode locktimeouts --warning ".$serviceargs["locktimeouts_warning"]." --critical ".$serviceargs["locktimeouts_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Lock Timeouts / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "lockwait":

                        $pluginopts .= "--mode lockwait --warning ".$serviceargs["lockwait_warning"]." --critical ".$serviceargs["lockwait_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Lock Wait Times".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "lockwaits":

                        $pluginopts .= "--mode lockwaits --warning ".$serviceargs["lockwaits_warning"]." --critical ".$serviceargs["lockwaits_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Lock Waits / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "memory":

                        $pluginopts .= "--mode memory --warning ".$serviceargs["memory_warning"]." --critical ".$serviceargs["memory_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Memory Usage".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logins":

                        $pluginopts .= "--mode logins --warning ".$serviceargs["logins_warning"]." --critical ".$serviceargs["logins_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Logins / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "logouts":

                        $pluginopts .= "--mode logouts --warning ".$serviceargs["logouts_warning"]." --critical ".$serviceargs["logouts_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Logouts / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "longesttrans":

                        $pluginopts .= "--mode longesttrans --warning ".$serviceargs["longesttrans_warning"]." --critical ".$serviceargs["longesttrans_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Longest Transaction Running Time".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "maxwsmem":

                        $pluginopts .= "--mode maxwsmem --warning ".$serviceargs["maxwsmem_warning"]." --critical ".$serviceargs["maxwsmem_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Maximum Workspace Memory".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "memgrantsoutstand":

                        $pluginopts .= "--mode memgrantsoutstand --warning ".$serviceargs["memgrantsoutstand_warning"]." --critical ".$serviceargs["memgrantsoutstand_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Memory Grants Outstanding".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "memgrantspend":

                        $pluginopts .= "--mode memgrantspend --warning ".$serviceargs["memgrantspend_warning"]." --critical ".$serviceargs["memgrantspend_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Memory Grants Pending".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "numsuperlatches":

                        $pluginopts .= "--mode numsuperlatches --warning ".$serviceargs["numsuperlatches_warning"]." --critical ".$serviceargs["numsuperlatches_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Number of SuperLatches".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "pagelife":

                        $pluginopts .= "--mode pagelife --warning ".$serviceargs["pagelife_warning"]." --critical ".$serviceargs["pagelife_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Page Life Expectancy".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "pagelooks":

                        $pluginopts .= "--mode pagelooks --warning ".$serviceargs["pagelooks_warning"]." --critical ".$serviceargs["pagelooks_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Page Looks / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "pagereads":

                        $pluginopts .= "--mode pagereads --warning ".$serviceargs["pagereads_warning"]." --critical ".$serviceargs["pagereads_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Page Reads / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "pagesplits":

                        $pluginopts .= "--mode pagesplits --warning ".$serviceargs["pagesplits_warning"]." --critical ".$serviceargs["pagesplits_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Page Splits / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "pagewrites":

                        $pluginopts .= "--mode pagewrites --warning ".$serviceargs["pagewrites_warning"]." --critical ".$serviceargs["pagewrites_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Page Writes / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "processesblocked":

                        $pluginopts .= "--mode processesblocked --warning ".$serviceargs["processesblocked_warning"]." --critical ".$serviceargs["processesblocked_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Processes blocked".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "readahead":

                        $pluginopts .= "--mode readahead --warning ".$serviceargs["readahead_warning"]." --critical ".$serviceargs["readahead_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Readaheads / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "safeautoparams":

                        $pluginopts .= "--mode safeautoparams --warning ".$serviceargs["safeautoparams_warning"]." --critical ".$serviceargs["safeautoparams_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Safe Auto-Params / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sqlattentionrate":

                        $pluginopts .= "--mode sqlattentionrate --warning ".$serviceargs["sqlattentionrate_warning"]." --critical ".$serviceargs["sqlattentionrate_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Sql Attention rate".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sqlcompilations":

                        $pluginopts .= "--mode sqlcompilations --warning ".$serviceargs["sqlcompilations_warning"]." --critical ".$serviceargs["sqlcompilations_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL SQL Compilations / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "sqlrecompilations":

                        $pluginopts .= "--mode sqlrecompilations --warning ".$serviceargs["sqlrecompilations_warning"]." --critical ".$serviceargs["sqlrecompilations_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Sql Re-Compilations / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "stolenpages":

                        $pluginopts .= "--mode stolenpages --warning ".$serviceargs["stolenpages_warning"]." --critical ".$serviceargs["stolenpages_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Stolen Pages".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "superlatchdemotes":

                        $pluginopts .= "--mode superlatchdemotes --warning ".$serviceargs["superlatchdemotes_warning"]." --critical ".$serviceargs["superlatchdemotes_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL SuperLatch Demotions / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "superlatchpromotes":

                        $pluginopts .= "--mode superlatchpromotes --warning ".$serviceargs["superlatchpromotes_warning"]." --critical ".$serviceargs["superlatchpromotes_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL SuperLatch Promotions / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "tablelockescalate":

                        $pluginopts .= "--mode tablelockescalate --warning ".$serviceargs["tablelockescalate_warning"]." --critical ".$serviceargs["tablelockescalate_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Table Lock Escalations / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "targetpages":

                        $pluginopts .= "--mode targetpages --warning ".$serviceargs["targetpages_warning"]." --critical ".$serviceargs["targetpages_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Target Pages".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "targetsrvmem":

                        $pluginopts .= "--mode targetsrvmem --warning ".$serviceargs["targetsrvmem_warning"]." --critical ".$serviceargs["targetsrvmem_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Target Server Memory".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "totallatchwait":

                        $pluginopts .= "--mode totallatchwait --warning ".$serviceargs["totallatchwait_warning"]." --critical ".$serviceargs["totallatchwait_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Total Latch Wait Time".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "totalpages":

                        $pluginopts .= "--mode totalpages --warning ".$serviceargs["totalpages_warning"]." --critical ".$serviceargs["totalpages_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Total Pages".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "totalsrvmem":

                        $pluginopts .= "--mode totalsrvmem --warning ".$serviceargs["totalsrvmem_warning"]." --critical ".$serviceargs["totalsrvmem_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Total Server Memory".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "unsafeautoparams":

                        $pluginopts .= "--mode unsafeautoparams --warning ".$serviceargs["unsafeautoparams_warning"]." --critical ".$serviceargs["unsafeautoparams_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Unsafe Auto-Params / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "usercons":

                        $pluginopts .= "--mode usercons --warning ".$serviceargs["usercons_warning"]." --critical ".$serviceargs["usercons_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL User Connections".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "workfilescreated":

                        $pluginopts .= "--mode workfilescreated --warning ".$serviceargs["workfilescreated_warning"]." --critical ".$serviceargs["workfilescreated_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Workfiles Created / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "worktablescacheratio":

                        $pluginopts .= "--mode worktablescacheratio --warning ".$serviceargs["worktablescacheratio_warning"]." --critical ".$serviceargs["worktablescacheratio_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Worktables From Cache Ratio".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "worktablescreated":

                        $pluginopts .= "--mode worktablescreated --warning ".$serviceargs["worktablescreated_warning"]." --critical ".$serviceargs["worktablescreated_critical"]."";

                        $objs[] = array(
                            "type" => OBJECTTYPE_SERVICE,
                            "host_name" => $hostname,
                            "service_description" => "MSSQL Worktables Created / Sec".$instancetext,
                            "use" => "xiwizard_mssqlserver_service",
                            "check_command" => "check_xi_mssql_server2!".$pluginopts,
                            "_xiwizard" => $wizard_name,
                        );
                        break;

                    case "process":
                        foreach ($args as $i => $service) {
                            if (!array_key_exists('monitor', $service) || empty($service['counter_name'])) {
                                continue;
                            }

                            $pluginCustomOpts  = '--mode \'custom\' --warning '.$service["warning"].' --critical '.$service["critical"].' ';
                            $pluginCustomOpts .= '--custom \'("counter_name" : "'.$service["counter_name"].'", "instance_name" : "'.$service["instance_name"].'", "unit" : "'.$service["unit"].'", "modifier" : "'.$service["modifier"].'", "ring_buffer_type" : "'.$service["ring_buffer_type"].'", "xpath" : "'.$service["xpath"].'")\'';

                            $serviceDescription = $service['display_name'];

                            if (empty($service['display_name'])) {
                                # e.g. Cache Hit Ratio to 'cachehitratio'
                                $serviceDescription = ucwords(str_replace("%", "Pct", $service["counter_name"]));
                                $serviceDescription = (!empty($service["instance_name"]) ? $service["instance_name"]." " : "")."MSSQL ".$serviceDescription;
                            }

                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $hostname,
                                "service_description" => $serviceDescription,
                                "use" => "xiwizard_mssqlserver_service",
                                "_xiwizard" => $wizard_name,
                                "check_command" => "check_xi_mssql_server2!".$pluginopts.$pluginCustomOpts,
                            );
                        }
                        break;

                    default:
                        break;
                }
            }

            //~ echo "OBJECTS:<BR>";
            //~ print_r($objs);
            //~ exit();

            // return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;
    }

    return $output;
}

?>

