<?php
//
// Linux Server Config Wizard
// Copyright (c) 2018-2022 Nagios Enterprises, LLC. All rights reserved.
//

include_once(dirname(__FILE__) . '/../configwizardhelper.inc.php');

ec2_configwizard_init();

function ec2_configwizard_init()
{
    $name = "ec2";
    $args = array(
        CONFIGWIZARD_NAME => $name,
        CONFIGWIZARD_VERSION => "1.1.6",
        CONFIGWIZARD_TYPE => CONFIGWIZARD_TYPE_MONITORING,
        CONFIGWIZARD_DESCRIPTION => _("Monitor an Amazon EC2 Instance."),
        CONFIGWIZARD_DISPLAYTITLE => "Amazon EC2",
        CONFIGWIZARD_FUNCTION => "ec2_configwizard_func",
        CONFIGWIZARD_PREVIEWIMAGE => "ec2.png",
        CONFIGWIZARD_FILTER_GROUPS => array('amazon'),
        CONFIGWIZARD_REQUIRES_VERSION => 500
    );
    register_configwizard($name, $args);
}

/**
 * @return int
 *          0 = good to go
 *          1 = prereqs non-existent
 *          2 = may need to upgrade boto3
 */

function ec2_configwizard_check_prereqs()
{
    // Plugin doesn't exist
    if (!file_exists("/usr/local/nagios/libexec/check_ec2.py")) {
        return 4; // plugin non-existent
    }

    $preferred_version = '1.4.7';

    $found_pip = false;
    $pip_output = array();

    // See if boto3 is installed via pip and get the version number
    // $pip_command = "pip show boto3"; <-- THIS HAS LOW PERFORMANCE SOMETIMES, DO NOT USE
    $pip_command = 'python -c "import boto3"';
    exec($pip_command, $pip_output, $pip_return);

    // If neither yum nor pip returned anything, there is no need to continue
    if ($pip_return !== 0) {
        return 1; // prereqs non-existent
    }
}

/**
 * @param string $mode
 * @param null   $inargs
 * @param        $outargs
 * @param        $result
 *
 * @return string
 */

function ec2_configwizard_func($mode = "", $inargs = null, &$outargs, &$result)
{

    $wizard_name = "ec2";
    $local_url = get_base_url();

    // Initialize return code and output
    $result = 0;
    $output = "";

    // Initialize output args - pass back the same data we got
    $outargs[CONFIGWIZARD_PASSBACK_DATA] = $inargs;

    // If this is a fresh run of the wizard, clear old data
    if (isset($_SESSION['instancelist'])) {
        unset($_SESSION['instancelist']);
    }

    switch ($mode) {

        case CONFIGWIZARD_MODE_GETSTAGE1HTML:
            
            $check_prereqs = ec2_configwizard_check_prereqs();

            if ($check_prereqs == 1) {
                $output .= '<div class="message errorMessage" style="padding: 10px; margin-bottom: 20px;"><p><b>' . _('Error') . ':</b> ' . _('It looks like you are missing the python boto3 module on your Nagios XI server.') . '</p><p>' . _('To use this wizard you must install boto3 on your server. You can install it by running:') . '</p><pre>python -m pip install boto3</pre> OR <pre>pip install boto3</pre></div>';

            } elseif ($check_prereqs == 4) {
                $output .= '<div class="message errorMessage" style="padding: 10px; margin-bottom: 20px;"><p><b>' . _('Error') . ':</b> ' . _('It looks like you are missing the check_ec2.py plugin on your Nagios XI server.</p></div>');
            } else {

            $instanceid = grab_array_var($inargs, "instanceid", "");
            $accesskeyid = grab_array_var($inargs, "accesskeyid", "");
            $accesskey = grab_array_var($inargs, "accesskey", "");
            $staticcreds = grab_array_var($inargs, "staticcreds", "");
            $staticconfig = grab_array_var($inargs, "staticconfig", "");
            $credsfilepath = grab_array_var($inargs, "credsfilepath", "");
            $configfilepath = grab_array_var($inargs, "configfilepath", "");
            $region = grab_array_var($inargs, "aws_region", "");
            $instance_list = grab_array_var($inargs, 'instancelist', '');

            if (gettype($instance_list) == 'string') {
                $instance_list = json_decode(base64_decode($instance_list), true);
            }

            if ($credsfilepath == "") {
                $credsfilepath = "/usr/local/nagiosxi/etc/.aws/credentials";
            }

            if ($configfilepath == "") {
                $configfilepath = "/usr/local/nagiosxi/etc/.aws/config";
            }

            $linuxdistro = grab_array_var($inargs, "linuxdistro", "");

            $output = '
            <h5 class="ul">'._('AWS Credentials').'</h5>
            <p>' . _('Specify the credentials for the EC2 instance you would like to monitor.') . '</p>
            <table class="table table-condensed table-no-border table-auto-width">
                <tr>
                    <td class="vt" style="width: 135px;">
                        <label>' . _('Access Key ID') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="accesskeyid" id="accesskeyid" value="' . encode_form_val($accesskeyid) . '" class="textfield form-control credinput" ' . (checkbox_binary($staticcreds) ? "disabled" : "") . ' autocomplete="on">
                        <div class="subtext" id="accesskeyiderror" style="color: #c69; display: none;">' . _('Please enter an Access Key ID or specify a static credentials file') . '.</div>
                        <div class="subtext">' . _('The Access Key ID of the instance to be monitored') . '.</div>
                    </td>
                </tr>
                <tr>
                    <td class="vt" style="width: 135px;">
                        <label>' . _('Secret Access Key') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="accesskey" id="accesskey" value="' . encode_form_val($accesskey) . '" class="textfield form-control credinput" ' . (checkbox_binary($staticcreds) ? "disabled" : "") . ' autocomplete="on">
                        <div class="subtext" id="accesskeyerror" style="color: #c69; display: none;">' . _('Please enter a Secret Access Key or specify a static credentials file') . '.</div>
                        <div class="subtext">' . _('The Secret Access Key of the instance to be monitored') . '.</div>
                    </td>
                </tr>
            </table>

            <table class="table table-condensed table-no-border table-auto-width">
                <tr>
                    <td style="width: 135px;"></td>
                    <td>
                        <input type="checkbox" class="checkbox" id="staticcreds" name="staticcreds" ' . is_checked(checkbox_binary($staticcreds), "1") . '>
                    </td>
                    <td>
                        <label class="normal" for="staticcreds">
                            <b>' . _('Static credentials file') . '</b><br>
                            ' . _('Use a statically defined AWS credentials file') . '.
                        </label>

                        <i class="credtooltip fa fa-question-circle fa-14" data-placement="right" data-content="If this box is checked, Nagios will read a local file containing your AWS credentials that follows Amazon\'s syntax.  Read more about credentials files <a target=\'' . '_blank' . '\' href=\'' . 'http://docs.aws.amazon.com/cli/latest/userguide/cli-config-files.html' . '\'>here</a>.">
                    </td>
                </tr>
            </table>

            <script type="text/javascript">

                $(function(){
                    $(".credtooltip").popover({ html: true });
                });

            </script>

            <table class="table table-condensed table-no-border table-auto-width ' . (checkbox_binary($staticcreds) ? "" : "hidden") . '" id="credsfiletable">
                <tr>
                    <td class="vt" id="filepath" style="width: 135px;">
                        <label>' . _('File path') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="credsfilepath" id="credsfilepath" value="' . encode_form_val($credsfilepath) . '" class="textfield form-control">
                        <div class="subtext">' . _('The absolute file path to the Amazon Credentials file (<b>Default:</b> /usr/local/nagiosxi/etc/.aws/credentials)') . '.</div>
                        <div class="subtext">' . _('<b>Note: Ensure the nagios group has read permissions for the entirety of the file path leading to the credentials file, including the file itself</b>') . '.</div>
                    </td>
                </tr>
            </table>

            <table class="table table-condensed table-no-border table-auto-width">
                <tr>
                    <td style="width: 135px;"></td>
                    <td>
                        <input type="checkbox" class="checkbox" id="staticconfig" name="staticconfig" ' . is_checked(checkbox_binary($staticconfig), "1") . '>
                    </td>
                    <td>
                        <label class="normal" for="staticconfig">
                            <b>' . _('Static configuration file') . '</b><br>
                            ' . _('Use a statically defined AWS configurations file') . '.
                        </label>
                        <i class="credtooltip fa fa-question-circle fa-14" data-placement="right" data-content="If this box is checked, Nagios will read a local file containing your AWS configuration that follows Amazon\'s syntax.  Read more about configuration files <a target=\'' . '_blank' . '\' href=\'' . 'http://docs.aws.amazon.com/cli/latest/userguide/cli-config-files.html' . '\'>here</a>.">
                    </td>
                </tr>
            </table>

            <table class="table table-condensed table-no-border table-auto-width ' . (checkbox_binary($staticconfig) ? "" : "hidden") . '" id="configfiletable">
                <tr>
                    <td class="vt" style="width: 135px;">
                        <label>' . _('File path') . ':</label>
                    </td>
                    <td>
                        <input type="text" size="40" name="configfilepath" id="configfilepath" value="' . encode_form_val($configfilepath) . '" class="textfield form-control">
                        <div class="subtext">' . _('The absolute file path to the Amazon Configuration file (<b>Default:</b> /usr/local/nagiosxi/etc/.aws/config)') . '.</div>
                        <div class="subtext">' . _('<b>Note: Ensure the nagios group has read permissions for the entirety of the file path leading to the config file, including the file itself</b>') . '.</div>
                    </td>
                </tr>
            </table>

            <script>

                document.addEventListener("DOMContentLoaded", function() {
                    var credtable = document.getElementById("credsfiletable");
                    var credinputs = document.getElementsByClassName("credinput");

                    document.querySelector("#staticcreds").addEventListener("change", function() {
                        if (credtable.classList.contains("hidden")) {
                            credtable.classList.remove("hidden");
                        } else {
                            credtable.classList.add("hidden");
                        }

                        for (var i = 0; i < credinputs.length; i++) {
                            if (credinputs[i].disabled === true) {
                                credinputs[i].disabled = false;
                            } else {
                                credinputs[i].disabled = true;
                            }
                        }
                    });
                });

            </script>

            <h5 class="ul">'._('EC2 Instances').'</h5>
            <p>' . _('Select the EC2 instances you would like to monitor.') . '</p>';

            if ($instance_list == '') {
                $output .= '
                <div class="alert alert-info loader" id="instance-notice" style="max-width: 500px; text-align: center; height: 117px;">
                    <div id="ajax-loader" class="sk-spinner sk-spinner-rotating-plane" style="background-color: #4D89F9; display: none; margin-top: 27px;">
                    </div>
                    <div id="info-placeholder">
                        <p class="center available-instances" id="no-instances" style="padding-top: 5px; padding-bottom: 15px;">We don\'t know which instances are available yet! Fill out the EC2 Account Information section, then click "Get Available Instances".
                        </p> 
                    </div>
                    <button type="button" id="get-instances" class="btn btn-sm btn-default center available-buckets">Get Available Instances</button>
               
                </div>
                <div id="instance-container"></div>';
            } else {
                // Rebuild the region based data structure
                $regional_instance_list = array();
                foreach ($instance_list as $instance_id => $instance_info) {
                    $regional_instance_list[$instance_info['region']][$instance_id] = $instance_info;
                }

                $counter = 0;
                foreach ($regional_instance_list as $region => $instances) {
                    $output .= "<h6>$region</h6>";
                    $output .= '<table class="table table-auto-width table-no-border"><thead><tr><th><input type="checkbox" id="select-all-buckets" checked></th><th>Instance ID</th><th>IP Address</th></tr></thead>';
                    foreach ($instances as $instance_id => $instance_info) {
                        $output .= '<tr style="padding: 0;"><td><input type="checkbox" class="instance-list-checkbox" name="instancelist[' . $instance_id . '][checkbox]" style="margin-top: 2px;" checked></td><td style="padding: 0;"><input type="text" class="form-control" name="instancelist[' . $instance_id . '][instanceid]" style="margin: 3px 10px 3px 6px;" size="25" value="' . $instance_id . '" disabled></td><td style="padding: 0;"><input type="text" class="form-control" style="margin-left: 6px;" name="instancelist[' . $instance_id . '][ip_address]" value="' . $instance_info["ip_address"] . '"></td></tr><input type="hidden" name="instancelist[' . $instance_id . '][region]" value="' . $instance_info['region'] . '">';
                    }    
                }

                $output .= '</table>';
            }

            $output.='<script type="text/javascript">

            $(function(){
                $(".configtooltip").popover({ html: true });
            });

            $(document).ready(function() {
                $("#get-instances").on("click", function() {

                    errors = 0;

                    $("#instance-notice").css("background-color","#d9edf7");
                    $("#instance-notice").css("border-color","#bce8f1");

                    accesskeyid = $("#accesskeyid").val();
                    accesskey = $("#accesskey").val();
                    staticcreds = $("#staticcreds").prop("checked");

                    if ( ! accesskeyid && !staticcreds) {
                        $("#accesskeyid").css("border", "1px solid #c69");
                        $("#accesskeyiderror").show();
                        errors += 1;
                    } else {
                        $("#accesskeyiderror").hide();
                        $("#accesskeyid").css("border", "1px solid #ccc");
                    }

                    if ( ! accesskey && !staticcreds) {
                        $("#accesskey").css("border", "1px solid #c69");
                        $("#accesskeyerror").show();
                        errors += 1;
                    } else {
                        $("#accesskeyerror").hide();
                        $("#accesskey").css("border", "1px solid #ccc");
                    }

                    if ( errors > 0 ) {
                        return false;
                    }

                    // Display the loading animation whenever the button is clicked
                    $("#get-instances").hide();
                    $("#no-instances").hide();
                    $("#info-placeholder").empty();
                    $("#ajax-loader").show();

                    var accesskeyid = $("#accesskeyid").val();
                    var accesskey = $("#accesskey").val();

                    // Base64 encode the strings so we can pass them as a query string
                    accesskeyid = btoa(accesskeyid);
                    accesskey = btoa(accesskey);

                    var formvalues = "mode=getinstances";

                    if ($("#staticcreds").is(":checked")) {
                        var staticcreds = $("#staticcreds").val();
                        var credsfilepath = $("#credsfilepath").val();
                        formvalues += "&staticcreds=" + staticcreds;
                        formvalues += "&credsfilepath=" + credsfilepath;
                    }

                    if (accesskeyid != "") {
                        formvalues += "&accesskeyid=" + accesskeyid;
                    }
                    if (accesskey != "") {
                        formvalues += "&accesskey=" + accesskey;
                    }

                    full_url = base_url + "includes/configwizards/amazon_ec2/ec2.ajax.php?" + formvalues;
                    $.ajax({
                        url: full_url,
                        dataType: "json",
                        success: function(data) {

                            if (! data) {
                                $("#ajax-loader").hide();
                                $("#instance-notice").css("background-color", "#FF9999");
                                $("#instance-notice").css("border", "1px solid #c69");
                                $("#info-placeholder").html(\'<p style="margin-bottom: 15px; padding-top: 5px; color: #333;">There were no instances found. Verify your AWS credentials and try again.</p>\');
                                $("#get-instances").show();
                                return false;
                            }

                            $("#instance-notice").hide();

                            // $("#instance-container").append("<thead><tr><th><input type=\'checkbox\' id=\'select-all-instances\' checked></th><th>Bucket Name</th><th>Bucket Region</th></tr></thead>");

                            var counter = 0;

                            $.each(data, function( region, value ) {
                                $("#instance-container").append(\'<h6 style="font-weight: bold;">\' + region + \'</h6>\');
                                $("#instance-container").append("<table class=\'table table-auto-width table-no-border\' id=\'instance-table-" + counter + "\'><thead><tr><th style=\'padding-left: 0px;\'><input type=\'checkbox\' id=\'select-all-buckets\' checked></th><th>Instance ID</th><th>IP Address</th></tr></thead></table>");
                                $.each(value, function( index, instance ) {
                                    $("#instance-table-" + counter).append(\'<tr><td class="vt"><input type="checkbox" class="instance-list-checkbox" name="instancelist[\' + instance.instance_id + \'][checkbox]" style="margin-top: 2px;" checked></td><td><input type="text" class="form-control" name="instancelist[\' + instance.instanceid + \'][instanceid]" style="margin: 3px 10px 3px 6px;" size="25" value="\' + instance.instance_id + \'" disabled></td><td><input type="text" class="form-control" style="margin-left: 6px;" name="instancelist[\' + instance.instance_id + \'][ip_address]" value="\' + instance.ip_address + \'"></td></tr><input type="hidden" name="instancelist[\' + instance.instance_id + \'][region]" value="\' + region + \'">\');
                                });
                                counter++;
                            });
                        },
                        error: function(xmlhttprequest, textstatus, message) {
                            if (textstatus === "parsererror") {
                                $("#ajax-loader").hide();
                                $("#instance-notice").css("background-color", "#FF9999");
                                $("#instance-notice").css("border", "1px solid #c69");
                                $("#info-placeholder").html(\'<p style="margin-bottom: 15px; padding-top: 5px; color: #333;">There were no instances found. Verify your AWS credentials and try again.</p>\');
                                $("#get-instances").show();
                            }
                        }
                    });
                });

                $("#instance-container").on("click", "thead > tr > th > input:checkbox", function() {
                    if ($(this).prop("checked") ==  true) {
                        $(".instance-list-checkbox").prop("checked", true);
                    } else {
                        $(".instance-list-checkbox").prop("checked", false);
                    }
                });
            });

                document.addEventListener("DOMContentLoaded", function() {
                    var configtable = document.getElementById("configfiletable");
                    var configinputs = document.getElementsByClassName("configinputs");

                    document.querySelector("#staticconfig").addEventListener("change", function() {
                        if (configtable.classList.contains("hidden")) {
                            configtable.classList.remove("hidden");
                        } else {
                            configtable.classList.add("hidden");
                        }

                        for (var i = 0; i < configinputs.length; i++) {
                            if (configinputs[i].disabled === true) {
                                configinputs[i].disabled = false;
                            } else {
                                configinputs[i].disabled = true;
                            }
                        }
                    });
                });

            </script>';
            }
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE1DATA:

            // Get variables that were passed to us
            $accesskeyid = grab_array_var($inargs, "accesskeyid", "");
            $accesskey = grab_array_var($inargs, "accesskey", "");
            $credsfilepath = grab_array_var($inargs, "credsfilepath", "");
            $configfilepath = grab_array_var($inargs, "configfilepath", "");

            $staticcreds = grab_array_var($inargs, "staticcreds", "off");
            $staticconfig = grab_array_var($inargs, "staticconfig", "off");

            $checkbox_list = grab_array_var($inargs, "checkboxlist", "");
            $instance_list = grab_array_var($inargs, "instancelist", "");

            if (isset($checkbox_list)) {
                $_SESSION['checkbox_list'] = $checkbox_list;
            }

            if (isset($instance_list)) {
                $_SESSION['instance_list'] = $instance_list;
            }

            // Check for errors
            $errors = 0;
            $errmsg = array();

            if (empty($accesskeyid) and $staticcreds == "off") {
                $errmsg[$errors++] = _("Specify either an Access Key ID or a static credentials file.");
            }

            if (empty($accesskey) and $staticcreds == "off") {
                $errmsg[$errors++] = _("Specify either a Secret Access Key or a static credentials file.");
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            break;

        case CONFIGWIZARD_MODE_GETSTAGE2HTML:

            // Get variables that were passed to us
            $accesskeyid = grab_array_var($inargs, "accesskeyid", "");
            $accesskey = grab_array_var($inargs, "accesskey", "");
            $staticcreds = grab_array_var($inargs, "staticcreds", "");
            $staticconfig = grab_array_var($inargs, "staticconfig", "");
            $credsfilepath = grab_array_var($inargs, "credsfilepath", "");
            $configfilepath = grab_array_var($inargs, "configfilepath", "");

            $instance_list = grab_array_var($inargs, "instancelist", "");

            if (gettype($instance_list) == 'string') {
                $instance_list = json_decode(base64_decode($instance_list), true);
            }

            $hostname = grab_array_var($inargs, "hostname", $ha);

            $password = "";

            $services = "";
            $services_serial = grab_array_var($inargs, "services_serial", "");
            if ($services_serial != "") {
                $services = json_decode(base64_decode($services_serial), true);
            }
            if (!is_array($services)) {
                $services_default = array(
                    "ping" => 1,
                    "CPUCreditUsage" => 1,
                    "CPUCreditBalance" => 1,
                    "CPUUtilization" => 1,
                    "DiskReadOps" => 1,
                    "DiskWriteOps" => 1,
                    "DiskReadBytes" => 1,
                    "DiskWriteBytes" => 1,
                    "NetworkIn" => 1,
                    "NetworkOut" => 1,
                    "NetworkPacketsIn" => 1,
                    "NetworkPacketsOut" => 1,
                    "StatusCheckFailed" => 1,
                    "StatusCheckFailed_Instance" => 1,
                    "StatusCheckFailed_System" => 1

                );
                $services_default["servicestate"][0] = "on";
                $services_default["servicestate"][1] = "on";
                $services = grab_array_var($inargs, "services", $services_default);
            }

            $serviceargs = "";
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial", "");
            if ($serviceargs_serial != "") {
                $serviceargs = json_decode(base64_decode($serviceargs_serial), true);
            }
            if (!is_array($serviceargs)) {
                $serviceargs_default = array(

                    "CPUCreditUsage_warning" => 60,
                    "CPUCreditUsage_critical" => 120,

                    "CPUCreditBalance_warning" => 100,
                    "CPUCreditBalance_critical" => 25,

                    "CPUUtilization_warning" => 50,
                    "CPUUtilization_critical" => 75,
                    
                    "DiskReadOps_warning" => 15000,
                    "DiskReadOps_critical" => 30000,
                    
                    "DiskWriteOps_warning" => 15000,
                    "DiskWriteOps_critical" => 30000,
                    
                    "DiskReadBytes_warning" => 1000000000,
                    "DiskReadBytes_critical" => 2000000000,
                    
                    "DiskWriteBytes_warning" => 1000000000,
                    "DiskWriteBytes_critical" => 2000000000,
                    
                    "NetworkIn_warning" => 1000000000,
                    "NetworkIn_critical" => 2000000000,
                    
                    "NetworkOut_warning" => 1000000000,
                    "NetworkOut_critical" => 2000000000,
                    
                    "NetworkPacketsIn_warning" => 1750000,
                    "NetworkPacketsIn_critical" => 3500000,
                    
                    "NetworkPacketsOut_warning" => 1750000,
                    "NetworkPacketsOut_critical" => 3500000,
                    
                    "StatusCheckFailed_warning" => 1,
                    "StatusCheckFailed_critical" => 1,
                    
                    "StatusCheckFailed_Instance_warning" => 1,
                    "StatusCheckFailed_Instance_critical" => 1,
                    
                    "StatusCheckFailed_System_warning" => 1,
                    "StatusCheckFailed_System_critical" => 1,
                );

                $serviceargs = grab_array_var($inargs, "serviceargs", $serviceargs_default);
            }
            $main_css_url = get_base_url() . 'includes/configwizards/amazon_ec2/css/main'.(get_theme() === 'xi5dark' ? '-dark' : '') . '.css';
            $output = '
            <link rel="stylesheet" href="'.$main_css_url.'"/>
            <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '">
            <input type="hidden" name="accesskeyid" value="' . encode_form_val($accesskeyid) . '">
            <input type="hidden" name="accesskey" value="' . encode_form_val($accesskey) . '">
            <input type="hidden" name="staticcreds" value="' . encode_form_val($staticcreds) . '">
            <input type="hidden" name="staticconfig" value="' . encode_form_val($staticconfig) . '">
            <input type="hidden" name="credsfilepath" value="' . encode_form_val($credsfilepath) . '">
            <input type="hidden" name="configfilepath" value="' . encode_form_val($configfilepath) . '">

            <h5 class="ul">' . _('EC2 Instance Metrics') . '</h5>';

            if ($staticcreds == "on") {
                $output .= '<input type="hidden" name="credsfilepath" value="' . encode_form_val($credsfilepath) . '" >';
            } else {
                $output .=
                '<input type="hidden" name="accesskeyid" value="' . encode_form_val($accesskeyid) . '" >
                 <input type="hidden" name="accesskey" value="' . encode_form_val($accesskey) . '" >';
            }

            if ($staticconfig == "on") {
                $output .= '
                    <input type="hidden" name="configfilepath" value="' . encode_form_val($configfilepath) . '" >';
            }

            $output .= '

            <div id="advanced-wrapper">
                <div id="batch-edit-grid">
                    <div class="flex-center">
                        <button type="button" class="btn btn-sm btn-default" id="batch-edit-button">' . _("Edit All Selected") . '</button>
                    </div>
                    <div class="flex-center">
                        <span class="advanced-subtext">' . _("Batch edit thresholds for metrics for instances selected below") . '.</span>
                    </div>
                </div>

                <div id="search-grid">
                    <div class="flex-center">
                        <p id="search-label">Filter Instances:</p>
                        <input type="text" class="textfield form-control" id="instance-search" size="35"/>
                    </div>
                    <div class="flex-center" id="search-subtext-wrapper">
                        <span class="advanced-subtext">' . _("Filter by Instance ID, IP Address or Region") . '</span>
                    </div>
                </div>
            </div>
            
            <!------------------------------------------->
            <!---------- BEGIN MODAL HTML HERE ---------->
            <!------------------------------------------->

            <div id="batch-edit-modal-header">
                <div class="flex-center">
                    <h5>' . _("Batch Edit") . '</h5>
                </div>
            </div>
            <div id="batch-edit-modal-content" style="display: none;">

                    <!---------- CPUCreditUsage ---------->

                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" title="" data-original-title="The number of CPU credits spend by the instance for CPU utilization.">' . _('CPU Credit Usage') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="CPUCreditUsage_warning" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["CPUCreditUsage_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="CPUCreditUsage_critical" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["CPUCreditUsage_critical"] . '" />
                            <label class="input-group-addon">' . _("Credits (vCPU-minutes)") . '</label>
                        </div>
                    </div>


                    <!---------- Network Bytes In ---------->

                    <div class="flex-center">
                        <div class="input-group">
                            <label class="input-group-addon tt-bind" title="" data-original-title="The number of bytes received on all network interfaces by the instance.">' . _('Network Bytes In') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="NetworkBytesIn_warning" class="textarea form-control batch-edit-input" type="text" style="border-left: 0; border-right: 0;" value="' . $serviceargs["NetworkIn_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="NetworkBytesIn_critical" class="textarea form-control batch-edit-input" type="text" style="border-left: 0;" value="' . $serviceargs["NetworkIn_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                        </div>
                    </div>


                    <!---------- CPU Credit Balance ---------->

                    <div class="flex-center">
                        <div class="input-group">
                            <label class="input-group-addon tt-bind" title="" data-original-title="The number of earned CPU credits that an instance has accrued since it was launched or started.">' . _('CPU Credit Balance') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="CPUCreditBalance_warning" class="textarea form-control batch-edit-input" type="text" style="border-left: 0; border-right: 0;" value="' . $serviceargs["CPUCreditBalance_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="CPUCreditBalance_critical" class="textarea form-control batch-edit-input" type="text" style="border-left: 0;" value="' . $serviceargs["CPUCreditBalance_critical"] . '" />
                            <div class="input-group-addon">' . _("Credits (vCPU-minutes)") . '</div>
                        </div>
                    </div>


                    <!---------- Network Bytes Out ---------->

                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" title="" data-original-title="The number of bytes sent out on all network interfaces by the instance.">' . _("Network Bytes Out") . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="NetworkBytesOut_warning" class="textarea form-control batch-edit-input" value="' . $serviceargs["NetworkOut_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="NetworkBytesOut_critical" class="textarea form-control batch-edit-input" value="' . $serviceargs["NetworkOut_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                        </div>
                    </div><!---------- CPU Utilization ----------><div class="flex-center"><div class="input-group double-input">
                            <label class="input-group-addon tt-bind" title="" data-original-title="The percentage of allocated EC2 compute units that are currently in use on the instance.">' . _("CPU Utilization") . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="CPUUtilization_warning" class="textarea form-control batch-edit-input" type="text" style="border-left: 0; border-right: 0;" value="' . $serviceargs["CPUUtilization_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="CPUUtilization_critical" class="textarea form-control batch-edit-input" type="text" style="border-left: 0;" value="' . $serviceargs["CPUUtilization_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">%</div>
                        </div>
                    </div>


                    <!---------- Network Packets In ---------->
                    
                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" data-original-title="' . _("The number of packets received on all network interfaces by the instance") . '.">' . _('Network Packets In') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="NetworkPacketsIn_warning" type="text" class="textfield form-control batch-edit-input" value="' . $serviceargs["NetworkPacketsIn_warning"] . '" >
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="NetworkPacketsIn_critical" type="text" class="textfield form-control batch-edit-input" value="' . $serviceargs["NetworkPacketsIn_critical"] . '" >
                            <div class="input-group-addon" style="width: 70px;">' . _("Packets") . '</div>
                        </div>
                    </div>


                    <!---------- Disk Read Operations ---------->

                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" data-original-title="' . _("Completed read operations from all instance store volumes available to the instance in a specified period of time") . '.">' . _('Disk Read Operations') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="DiskReadOperations_warning" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskReadOps_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="DiskReadOperations_critical" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskReadOps_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">IOPS</div>
                        </div>
                    </div>


                    <!---------- Network Packets Out ---------->

                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" data-original-title="' . _("The number of packets sent out on all network interfaces by the instance") . '.">' . _('Network Packets Out') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind batch-edit-input" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="NetworkPacketsOut_warning" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["NetworkPacketsOut_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind batch-edit-input" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="NetworkPacketsOut_critical" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["NetworkPacketsOut_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">' . _("Packets") . '</div>
                        </div>
                    </div>


                    <!---------- Disk Write Operations ---------->

                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" data-original-title="' . _("Completed write operations to all instance store volumes available to the instance in a specified period of time") . '.">' . _('Disk Write Operations') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="DiskWriteOperations_warning" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskWriteOps_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="DiskWriteOperations_critical" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskWriteOps_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">IOPS</div>
                        </div>
                    </div>


                    <!---------- Disk Read Bytes ---------->

                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" data-original-title="' . _("Bytes read from all instance store volumes available to the instance") . '.">' . _('Disk Read Bytes') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="DiskReadBytes_warning" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskReadBytes_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="DiskReadBytes_critical" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskReadBytes_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                        </div>
                    </div>

                    
                    <!---------- Status Check Failed ---------->

                    <div class="flex-center">
                        <div class="input-group flex-v-align">
                            <input data-batch-edit-target="StatusCheckFailed_checkbox" type="checkbox" class="batch-edit-input" style="margin-right: 5px;" checked="true">
                            <label for="StatusCheckFailed" class="select-cf-option tt-bind" data-original-title="' . _("Reports whether the instance has passed both the instance status check and the system status check in the last minute") . '.">' . _('Status Check Failed') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>
                        </div>
                    </div>

                    <!---------- Disk Write Bytes ---------->

                    <div class="flex-center">
                        <div class="input-group double-input">
                            <label class="input-group-addon tt-bind" data-original-title="' . _("Bytes written to all instance store volumes available to the instance") . '.">' . _('Disk Write Bytes') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                            <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                            <input data-batch-edit-target="DiskWriteBytes_warning" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskWriteBytes_warning"] . '" />
                            <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                            <input data-batch-edit-target="DiskWriteBytes_critical" class="textarea form-control batch-edit-input" type="text" value="' . $serviceargs["DiskWriteBytes_critical"] . '" />
                            <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                        </div>
                    </div>

                    <!---------- Status Check Failed (Instance) ---------->

                    <div class="flex-center">
                        <div class="input-group double-input flex-v-align">
                            <input data-batch-edit-target="StatusCheckFailed_Instance_checkbox" type="checkbox" class="batch-edit-input" style="margin-right: 5px;" checked="true">
                            <label class="select-cf-option tt-bind" data-original-title="' . _("Reports whether the instance has passed the instance status check in the last minute") . '.">' . _('Status Check Failed (Instance)') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>
                        </div>
                    </div>

                    <!---------- Status Check Failed (System) ---------->

                    <div class="flex-center">
                        <div class="input-group double-input flex-v-align">
                            <input data-batch-edit-target="StatusCheckFailed_System_checkbox" type="checkbox" class="batch-edit-input" style="margin-right: 5px;" checked="true">
                            <label class="select-cf-option tt-bind" data-original-title="' . _("Reports whether the instance has passed the system status check in the last minute") . '.">' . _('Status Check Failed (System)') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>
                        </div>
                    </div>

                    <div id="batch-edit-button-wrapper">
                        <button type="button" class="btn btn-sm btn-default" id="apply-batch-edit-button">' . _("Apply Batch Edit") . '</button>
                        <button type="button" class="btn btn-sm btn-default" id="hide-batch-edit">' . _("Close") . '</button>
                    </div>
            </div>

            <!------------------------------------------->
            <!----------- END MODAL HTML HERE ----------->
            <!------------------------------------------->

            <div class="grid">
                <div class="flex-center">
                    <input type="checkbox" id="toggle-all-instances">
                </div>
                <h6>Instance ID</h6>
                <h6>IP Address</h6>
                <h6>Region</h6>
                <div class="flex-center">
                    <i class="fa fa-chevron-down" id="toggle-all-chevron"></i>
                </div>
            </div>';

            foreach($instance_list as $instance_id => $instance) {
                // Don't display instances that haven't been selected for monitoring
                if ( $instance['checkbox'] != 'on' ) {
                    continue;
                }

                $output .= '
                <div class="instance-wrapper" data-instance-id="' . $instance_id . '" data-ip-address="' . $instance["ip_address"] . '" data-region="' . $instance["region"] . '">
                    <input type="hidden" name="instancelist[' . $instance_id . '][region]" value="' . $instance["region"] . '">
                    <input type="hidden" name="instancelist[' . $instance_id . '][ip_address]" value="' . $instance["ip_address"] . '">
                    <input type="hidden" name="instancelist[' . $instance_id . '][instance_id]" value="' . $instance_id . '">
                    <input type="hidden" name="instancelist[' . $instance_id . '][checkbox]" value="on">
                    <div class="grid instance-header" data-instance-id="' . $instance_id . '">
                        <div class="flex-center">
                            <input type="checkbox" class="instance-batch-checkbox" data-instance-id="' . $instance_id . '">
                        </div>
                        <p>' . $instance_id . '</p>
                        <p>' . $instance["ip_address"] . '</p>
                        <p>' . $instance["region"] . '</p>
                        <div class="flex-center">
                            <i class="fa fa-chevron-down metrics-chevron" data-instance-id="' . $instance_id . '"></i>
                        </div>
                    </div>
                    
                    <div class="metrics-grid" data-instance-id="' . $instance_id . '">
                        <div id="metrics-grid-table">

                            <!---------- Hostname ---------->
   
                            <div class="flex-center" id="hostname-div">
                                <div class="input-group">
                                    <label class="input-group-addon tt-bind" title="" data-original-title="The name you want associated with this host" for="instancelist[' . $instance_id . '][hostname]">' . _("Hostname") . ' <i class="fa fa-question-circle" style="font-size: 12px; margin-left: 2px;"></i></label>
                                    <input name="instancelist[' . $instance_id . '][hostname]" value="' . $instance["ip_address"] . '" class="textarea form-control" type="text"/>
                                </div>
                            </div>

                            <!---------- Toggle All Checkbox ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox toggle-checkbox" data-instance-id="' . $instance_id . '" checked="true">
                            </div>
                            <div id="toggle-all-wrapper">
                                <div id="toggle-all-label">
                                    <label class="select-cf-option">' . _("Toggle All") . '</label>
                                </div>
                            </div>


                            <!---------- CPUCreditUsage ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][CPUCreditUsage][checkbox]"  ' . is_checked(checkbox_binary($services["CPUCreditUsage"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label for="CPUCreditUsage" class="input-group-addon tt-bind" title="" data-original-title="The number of CPU credits spend by the instance for CPU utilization.">' . _('CPU Credit Usage') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="CPUCreditUsage_warning" name="instancelist[' . $instance_id . '][metrics][CPUCreditUsage][warning]" value="' . $serviceargs["CPUCreditUsage_warning"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="CPUCreditUsage_critical" name="instancelist[' . $instance_id . '][metrics][CPUCreditUsage][critical]" value="' . $serviceargs["CPUCreditUsage_critical"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <label class="input-group-addon">' . _("Credits (vCPU-minutes)") . '</label>
                                </div>
                            </div>


                            <!---------- Network Bytes In ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][NetworkIn][checkbox]"  ' . is_checked(checkbox_binary($services["NetworkIn"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group">
                                    <label for="NetworkIn" class="input-group-addon tt-bind" title="" data-original-title="The number of bytes received on all network interfaces by the instance.">' . _('Network Bytes In') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkBytesIn_warning" name="instancelist[' . $instance_id . '][metrics][NetworkIn][warning]" value="' . $serviceargs["NetworkIn_warning"] . '" class="textarea form-control batch-edit-target" type="text" style="border-left: 0; border-right: 0;"/>
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkBytesIn_critical" name="instancelist[' . $instance_id . '][metrics][NetworkIn][critical]" value="' . $serviceargs["NetworkIn_critical"] . '" class="textarea form-control batch-edit-target" type="text" style="border-left: 0;"/>
                                    <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                                </div>
                            </div>


                            <!---------- CPU Credit Balance ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][CPUCreditBalance][checkbox]"  ' . is_checked(checkbox_binary($services["CPUCreditBalance"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group">
                                    <label for="CPUCreditBalance" class="input-group-addon tt-bind" title="" data-original-title="The number of earned CPU credits that an instance has accrued since it was launched or started.">' . _('CPU Credit Balance') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="CPUCreditBalance_warning" name="instancelist[' . $instance_id . '][metrics][CPUCreditBalance][warning]" value="' . $serviceargs["CPUCreditBalance_warning"] . '" class="textarea form-control batch-edit-target" type="text" style="border-left: 0; border-right: 0;"/>
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="CPUCreditBalance_critical" name="instancelist[' . $instance_id . '][metrics][CPUCreditBalance][critical]" value="' . $serviceargs["CPUCreditBalance_critical"] . '" class="textarea form-control batch-edit-target" type="text" style="border-left: 0;"/>
                                    <div class="input-group-addon">' . _("Credits (vCPU-minutes)") . '</div>
                                </div>
                            </div>


                            <!---------- Network Bytes Out ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][NetworkOut][checkbox]"  ' . is_checked(checkbox_binary($services["NetworkOut"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label class="input-group-addon tt-bind" title="" data-original-title="The number of bytes sent out on all network interfaces by the instance.">' . _("Network Bytes Out") . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkBytesOut_warning" class="textarea form-control batch-edit-target" name="instancelist[' . $instance_id . '][metrics][NetworkOut][warning]" value="' . $serviceargs["NetworkOut_warning"] . '" />
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkBytesOut_critical" class="textarea form-control batch-edit-target" name="instancelist[' . $instance_id . '][metrics][NetworkOut][critical]" value="' . $serviceargs["NetworkOut_critical"] . '" />
                                    <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                                </div>
                            </div>


                            <!---------- CPU Utilization ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][CPUUtilization][checkbox]"  ' . is_checked(checkbox_binary($services["CPUUtilization"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label for="instancelist[' . $instance_id . '][metrics][CPUUtilization][warning]" class="input-group-addon tt-bind" title="" data-original-title="The percentage of allocated EC2 compute units that are currently in use on the instance.">' . _("CPU Utilization") . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="CPUUtilization_warning" name="instancelist[' . $instance_id . '][metrics][CPUUtilization][warning]" value="' . $serviceargs["CPUUtilization_warning"] . '" class="textarea form-control batch-edit-target" type="text" style="border-left: 0; border-right: 0;"/>
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="CPUUtilization_critical" name="instancelist[' . $instance_id . '][metrics][CPUUtilization][critical]" value="' . $serviceargs["CPUUtilization_critical"] . '" class="textarea form-control batch-edit-target" type="text" style="border-left: 0;"/>
                                    <div class="input-group-addon" style="width: 70px;">%</div>
                                </div>
                            </div>


                            <!---------- Network Packets In ---------->
                            
                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][NetworkPacketsIn][checkbox]"  ' . is_checked(checkbox_binary($services["NetworkPacketsIn"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label for="NetworkPacketsIn" class="input-group-addon tt-bind" data-original-title="' . _("The number of packets received on all network interfaces by the instance") . '.">' . _('Network Packets In') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkPacketsIn_warning" type="text" name="instancelist[' . $instance_id . '][metrics][NetworkPacketsIn][warning]" value="' . $serviceargs["NetworkPacketsIn_warning"] . '" class="textfield form-control batch-edit-target">
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkPacketsIn_critical" type="text" name="instancelist[' . $instance_id . '][metrics][NetworkPacketsIn][critical]" value="' . $serviceargs["NetworkPacketsIn_critical"] . '" class="textfield form-control batch-edit-target">
                                    <div class="input-group-addon" style="width: 70px;">' . _("Packets") . '</div>
                                </div>
                            </div>


                            <!---------- Disk Read Operations ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][DiskReadOps][checkbox]"  ' . is_checked(checkbox_binary($services["DiskReadOps"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label for="DiskReadOps" class="input-group-addon tt-bind" data-original-title="' . _("Completed read operations from all instance store volumes available to the instance in a specified period of time") . '.">' . _('Disk Read Operations') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskReadOperations_warning" name="instancelist[' . $instance_id . '][metrics][DiskReadOps][warning]" value="' . $serviceargs["DiskReadOps_warning"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskReadOperations_critical" name="instancelist[' . $instance_id . '][metrics][DiskReadOps][critical]" value="' . $serviceargs["DiskReadOps_critical"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <div class="input-group-addon" style="width: 70px;">IOPS</div>
                                </div>
                            </div>


                            <!---------- Network Packets Out ---------->

                            <div class="flex-center">
                                <input type="checkbox" id="NetworkPacketsOut" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][NetworkPacketsOut][checkbox]"  ' . is_checked(checkbox_binary($services["NetworkPacketsOut"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label for="NetworkPacketsOut" class="input-group-addon tt-bind" data-original-title="' . _("The number of packets sent out on all network interfaces by the instance") . '.">' . _('Network Packets Out') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkPacketsIn_warning" name="instancelist[' . $instance_id . '][metrics][NetworkPacketsOut][warning]" value="' . $serviceargs["NetworkPacketsOut_warning"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="NetworkPacketsIn_critical" name="instancelist[' . $instance_id . '][metrics][NetworkPacketsOut][critical]" value="' . $serviceargs["NetworkPacketsOut_critical"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <div class="input-group-addon" style="width: 70px;">' . _("Packets") . '</div>
                                </div>
                            </div>


                            <!---------- Disk Write Operations ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" id="DiskWriteOps" name="instancelist[' . $instance_id . '][metrics][DiskWriteOps][checkbox]"  ' . is_checked(checkbox_binary($services["DiskWriteOps"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label for="DiskWriteOps" class="input-group-addon tt-bind" data-original-title="' . _("Completed write operations to all instance store volumes available to the instance in a specified period of time") . '.">' . _('Disk Write Operations') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskWriteOperations_warning" name="instancelist[' . $instance_id . '][metrics][DiskWriteOps][warning]" value="' . $serviceargs["DiskWriteOps_warning"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskWriteOperations_critical" name="instancelist[' . $instance_id . '][metrics][DiskWriteOps][critical]" value="' . $serviceargs["DiskWriteOps_critical"] . '" class="textarea form-control batch-edit-target" type="text"/>
                                    <div class="input-group-addon" style="width: 70px;">IOPS</div>
                                </div>
                            </div>


                            <!---------- Disk Read Bytes ---------->

                            <div class="flex-center">
                                <input type="checkbox" class="checkbox ' . $instance_id . '-checkbox" id="DiskReadBytes" name="instancelist[' . $instance_id . '][metrics][DiskReadBytes][checkbox]"  ' . is_checked(checkbox_binary($services["DiskReadBytes"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label class="input-group-addon tt-bind" data-original-title="' . _("Bytes read from all instance store volumes available to the instance") . '.">' . _('Disk Read Bytes') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskReadBytes_warning" name="instancelist[' . $instance_id . '][metrics][DiskReadBytes][warning]" value="' . $serviceargs["DiskReadBytes_warning"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskReadBytes_critical" name="instancelist[' . $instance_id . '][metrics][DiskReadBytes][critical]" value="' . $serviceargs["DiskReadBytes_critical"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                                </div>
                            </div>

                            
                            <!---------- Status Check Failed ---------->

                            <div class="flex-center">
                                <input data-instance-id="' . $instance_id . '" data-batch-edit-id="StatusCheckFailed_checkbox" type="checkbox" class="checkbox ' . $instance_id . '-checkbox batch-edit-target" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed][checkbox]"  ' . is_checked(checkbox_binary($services["StatusCheckFailed"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group">
                                    <label for="StatusCheckFailed" class="select-cf-option tt-bind" data-original-title="' . _("Reports whether the instance has passed both the instance status check and the system status check in the last minute") . '.">' . _('Status Check Failed') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>
                                    <input type="hidden" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed][warning]" value="' . $serviceargs["StatusCheckFailed_warning"] . '" class="textfield form-control condensed">
                                    <input type="hidden" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed][critical]" value="' . $serviceargs["StatusCheckFailed_critical"] . '" class="textfield form-control condensed">
                                </div>
                            </div>

                            <!---------- Disk Write Bytes ---------->

                            <div class="flex-center">
                                <input type="checkbox" id="DiskWriteBytes" class="checkbox ' . $instance_id . '-checkbox" name="instancelist[' . $instance_id . '][metrics][DiskWriteBytes][checkbox]"  ' . is_checked(checkbox_binary($services["DiskWriteBytes"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group double-input">
                                    <label class="input-group-addon tt-bind" data-original-title="' . _("Bytes written to all instance store volumes available to the instance") . '.">' . _('Disk Write Bytes') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>

                                    <label class="input-group-addon"><img src="'.theme_image('error.png').'" class="tt-bind" title="'._('Warning Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskWriteBytes_warning" name="instancelist[' . $instance_id . '][metrics][DiskWriteBytes][warning]" value="' . $serviceargs["DiskWriteBytes_warning"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <label class="input-group-addon"><img src="'.theme_image('critical_small.png').'" class="tt-bind" title="'._('Critical Threshold').'"></label>
                                    <input data-instance-id="' . $instance_id . '" data-batch-edit-id="DiskWriteBytes_critical" name="instancelist[' . $instance_id . '][metrics][DiskWriteBytes][critical]" value="' . $serviceargs["DiskWriteBytes_critical"] . '" class="textarea form-control batch-edit-target" type="text" />
                                    <div class="input-group-addon" style="width: 70px;">' . _("Bytes") . '</div>
                                </div>
                            </div>

                            <!---------- Status Check Failed (Instance) ---------->

                            <div class="flex-center">
                                <input data-instance-id="' . $instance_id . '" data-batch-edit-id="StatusCheckFailed_Instance_checkbox" type="checkbox" class="checkbox ' . $instance_id . '-checkbox batch-edit-target" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed_Instance][checkbox]"  ' . is_checked(checkbox_binary($services["StatusCheckFailed_Instance"]), "1") . '>
                            </div>
                            <div class="flex-center">
                                <div class="input-group">
                                    <label for="StatusCheckFailed_Instance" class="select-cf-option tt-bind" data-original-title="' . _("Reports whether the instance has passed the instance status check in the last minute") . '.">' . _('Status Check Failed (Instance)') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>
                                    <input type="hidden" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed_Instance][warning]" value="' . $serviceargs["StatusCheckFailed_Instance_warning"] . '" class="textfield form-control condensed">
                                    <input type="hidden" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed_Instance][critical]" value="' . $serviceargs["StatusCheckFailed_Instance_critical"] . '" class="textfield form-control condensed">
                                </div>
                            </div>

                            <!---------- Status Check Failed (System) ---------->

                            <div class="flex-center" id="status-check-system-checkbox">
                                <input data-instance-id="' . $instance_id . '" data-batch-edit-id="StatusCheckFailed_System_checkbox" type="checkbox" class="checkbox ' . $instance_id . '-checkbox batch-edit-target" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed_System][checkbox]"  ' . is_checked(checkbox_binary($services["StatusCheckFailed_System"]), "1") . '>
                            </div>
                            <div class="flex-center" id="status-check-system-label">
                                <div class="input-group">
                                    <label class="select-cf-option tt-bind" data-original-title="' . _("Reports whether the instance has passed the system status check in the last minute") . '.">' . _('Status Check Failed (System)') . ' <i class="fa fa-question-circle" style="font-size: 12px;"></i></label>
                                    <input type="hidden" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed_System][warning]" value="' . $serviceargs["StatusCheckFailed_System_warning"] . '" class="textfield form-control condensed">
                                    <input type="hidden" name="instancelist[' . $instance_id . '][metrics][StatusCheckFailed_System][critical]" value="' . $serviceargs["StatusCheckFailed_System_critical"] . '" class="textfield form-control condensed">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
            }
            
            $output .= '

            <div style="height: 20px;"></div>
            
            <script>
                function searchInstances( searchString ) {
                    $(".instance-wrapper").fadeOut(175);
                    
                    $(".instance-wrapper").each(function() {
                        instance_id = $(this).data("instance-id");
                        ip_address = $(this).data("ip-address");
                        region = $(this).data("region");
                        
                        instance_id_result = instance_id.indexOf(searchString);
                        ip_address_result = ip_address.indexOf(searchString);
                        region_result = region.indexOf(searchString);

                        if (instance_id_result >= 0 || ip_address_result >= 0 || region_result >= 0) {
                            $(this).fadeIn(175);
                        }

                    });
                }


                $(document).ready(function() {
                    
                    $(".toggle-checkbox").on("click", function() {

                        var instance_id = $(this).attr("data-instance-id");
                        var checkbox_class = "." + instance_id + "-checkbox";

                        if (this.checked) {
                            $(checkbox_class).prop("checked", true);
                        } else {
                            $(checkbox_class).prop("checked", false);
                        }
                        
                    });

                    var search;

                    // Instance Search
                    $("#instance-search").on("keyup", function() {
                        clearTimeout(search);
                        searchString = $(this).val().toLowerCase();
                        search = setTimeout(\'searchInstances(searchString)\', 400);
                    });

                    $("#toggle-all-chevron").on("click", function() {
                        if ( $(this).hasClass("expanded") ) {
                            $(this).removeClass("expanded");
                            $(this).css({ "transform" : "rotate(0deg)" });
                            $(".metrics-grid").each(function() {
                                $(this).css("height", "0px");
                                $(this).css("border-bottom", "0px");
                            });

                            $(".metrics-chevron").each(function() {
                                $(this).css({ "transform" : "rotate(0deg)" });
                            });

                            $(".instance-header").each(function() {
                                $(this).removeClass("expanded");
                            });
                        } else {
                            $(this).addClass("expanded");
                            $(this).css({ "transform" : "rotate(180deg)" });
                            $(".metrics-grid").each(function() {
                                $(this).css("height", "392px");
                                $(this).css("border-bottom", "1px solid #ccc");
                            });

                            $(".metrics-chevron").each(function() {
                                $(this).css({ "transform" : "rotate(180deg)" });
                            });

                            $(".instance-header").each(function() {
                                $(this).addClass("expanded");
                            });
                        }
                    });

                    $(".instance-header").on("click", function() {
                        
                        var instanceId = $(this).data("instance-id");

                        if ( $(this).hasClass("expanded") ) {
                            $(this).removeClass("expanded");
                            $(\'.metrics-chevron[data-instance-id="\' + instanceId + \'"]\').css({ "transform" : "rotate(0deg)" });
                            $(\'.metrics-grid[data-instance-id="\' + instanceId + \'"]\').css("height", "0px");
                            $(\'.metrics-grid[data-instance-id="\' + instanceId + \'"]\').css("border-bottom", "0px");
                        } else {
                            $(this).addClass("expanded");
                            $(\'.metrics-chevron[data-instance-id="\' + instanceId + \'"]\').css({ "transform" : "rotate(180deg)" });
                            $(\'.metrics-grid[data-instance-id="\' + instanceId + \'"]\').css("height", "392px");
                            $(\'.metrics-grid[data-instance-id="\' + instanceId + \'"]\').css("border-bottom", "1px solid #ccc");
                        }

                    });

                });

                $("#toggle-all-instances").on("click", function() {
                    checked = $(this).prop("checked");
                    
                    if (checked) {
                        $(".instance-batch-checkbox").prop("checked", true);
                        $(".instance-batch-checkbox").trigger("change");
                    } else {
                        $(".instance-batch-checkbox").prop("checked", false);
                        $(".instance-batch-checkbox").trigger("change");
                    }
                });

                $(".instance-batch-checkbox").on("change", function() {
                    var checkbox = $(this);

                    ';
                    if (get_theme() === 'xi5dark') {

                        $output .= '
                        if ( $(checkbox).prop("checked") ) {
                            $(checkbox).parent().parent().css("background-color", "#404040");
                        } else {
                            $(checkbox).parent().parent().css("background-color", "#111111");
                        }';
                    } else {

                        $output .= '
                        if ( $(checkbox).prop("checked") ) {
                            $(checkbox).parent().parent().css("background-color", "#d9edf7");
                        } else {
                            $(checkbox).parent().parent().css("background-color", "white");
                        }';
                    }
                    $output .= '
                });

                // Show batch edit modal
                $("#batch-edit-button").click(function() {
                    $("#batch-edit-modal-header").show();
                    $("#batch-edit-modal-content").show();
                });

                $("#hide-batch-edit").on("click", function() {
                    $("#batch-edit-modal-content").hide();
                    $("#batch-edit-modal-header").hide();
                });

                $("#apply-batch-edit-button").on("click", function () {

                    var checkedInstances = [];
                    var batchEdit = [];

                    // Get checked instances
                    $(".instance-batch-checkbox").each(function() {
                        if ( $(this).prop("checked") ) {
                            checkedInstances.push( $(this).data("instance-id") );
                        }
                    });

                    // Get all values
                    $(".batch-edit-input").each(function() {
                        // Check for checkboxes
                        if ( $(this).is(":checkbox") ) {
                            val = "checkbox";
                        } else {
                            val = $(this).val();
                        }

                        if (val) {
                            var editEntry = new Object;

                            var target = $(this).data("batch-edit-target");
                            if ( val === "checkbox") {
                                var value = $(this).prop("checked");
                            } else {
                                var value = $(this).val();
                            }

                            editEntry.target = target;
                            editEntry.value = value;

                            batchEdit.push(editEntry);
                        }
                    });

                    // Apply values to checked instances
                    for (index in batchEdit) {
                        targetId = batchEdit[index].target;
                        targetValue = batchEdit[index].value;

                        $(".batch-edit-target[data-batch-edit-id=" + targetId + "]").each(function() {
                            targetInstanceId = $(this).data("instance-id");
                            
                            if ( $.inArray(targetInstanceId, checkedInstances) >= 0 ) {
                                if ( $(this).is(":checkbox") ) {
                                    $(this).prop("checked", targetValue);
                                } else {
                                    $(this).val(targetValue);
                                }
                            }
                        });
                    }
                });
            </script>';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE2DATA:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $instanceid = grab_array_var($inargs, "instanceid", "");
            $accesskeyid = grab_array_var($inargs, "accesskeyid", "");
            $accesskey = grab_array_var($inargs, "accesskey", "");
            $staticcreds = grab_array_var($inargs, "staticcreds", "");
            $staticconfig = grab_array_var($inargs, "staticconfig", "");
            $credsfilepath = grab_array_var($inargs, "credsfilepath", "");
            $configfilepath = grab_array_var($inargs, "configfilepath", "");

            $instance_list = grab_array_var($inargs, "instancelist", "");

            if (gettype($instance_list) == 'string') {
                $instance_list = json_decode(base64_decode($instance_list), true);
            }

            // Check for errors
            $errors = 0;
            $errmsg = array();
            foreach($instance_list as $instance_id => $instance) {
                if (is_valid_host_name($instance["hostname"]) == false) {
                    $errmsg[$errors++] = sprintf(_("Invalid host name for instance %s."), $instance_id);
                }
            }

            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            break;


        case CONFIGWIZARD_MODE_GETSTAGE3HTML:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address");
            $hostname = grab_array_var($inargs, "hostname");
            $instanceid = grab_array_var($inargs, "instanceid", "");
            $accesskeyid = grab_array_var($inargs, "accesskeyid", "");
            $accesskey = grab_array_var($inargs, "accesskey", "");
            $staticcreds = grab_array_var($inargs, "staticcreds", "");
            $staticconfig = grab_array_var($inargs, "staticconfig", "");
            $credsfilepath = grab_array_var($inargs, "credsfilepath", "");
            $configfilepath = grab_array_var($inargs, "configfilepath", "");
            $region = grab_array_var($inargs, "aws_region", "");

            $instance_list = grab_array_var($inargs, "instancelist", "");

            if (gettype($instance_list) == 'string') {
                $instance_list = json_decode(base64_decode($instance_list), true);
            }

            $services = "";
            $services_serial = grab_array_var($inargs, "services_serial");
            if ($services_serial != "") {
                $services = json_decode(base64_decode($services_serial), true);
            } else {
                $services = grab_array_var($inargs, "services");
            }

            $serviceargs = "";
            $serviceargs_serial = grab_array_var($inargs, "serviceargs_serial");
            if ($serviceargs_serial != "") {
                $serviceargs = json_decode(base64_decode($serviceargs_serial), true);
            } else {
                $serviceargs = grab_array_var($inargs, "serviceargs");
            }

            $output = '
            <input type="hidden" name="instancelist" value="' . base64_encode(json_encode($instance_list)) . '">
            <input type="hidden" name="ip_address" value="' . encode_form_val($address) . '">
            <input type="hidden" name="hostname" value="' . encode_form_val($hostname) . '">
            <input type="hidden" name="instanceid" value="' . encode_form_val($instanceid) . '">
            <input type="hidden" name="accesskeyid" value="' . encode_form_val($accesskeyid) . '">
            <input type="hidden" name="accesskey" value="' . encode_form_val($accesskey) . '">
            <input type="hidden" name="aws_region" value="' . encode_form_val($region) . '">
            <input type="hidden" name="staticcreds" value="' . encode_form_val($staticcreds) . '">
            <input type="hidden" name="staticconfig" value="' . encode_form_val($staticconfig) . '">
            <input type="hidden" name="credsfilepath" value="' . encode_form_val($credsfilepath) . '">
            <input type="hidden" name="configfilepath" value="' . encode_form_val($configfilepath) . '">
            <input type="hidden" name="services_serial" value="' . base64_encode(json_encode($services)) . '">
            <input type="hidden" name="serviceargs_serial" value="' . base64_encode(json_encode($serviceargs)) . '">';
            break;

        case CONFIGWIZARD_MODE_VALIDATESTAGE3DATA:

            $check_interval = grab_array_var($inargs, "check_interval", "");

            // Check for errors
            $errors = 0;
            $errmsg = array();
            if ($check_interval < 5) {
                $errmsg[$errors++] = _("Check interval cannot be less than 5 minutes.");
            }
            if ($errors > 0) {
                $outargs[CONFIGWIZARD_ERROR_MESSAGES] = $errmsg;
                $result = 1;
            }
            break;

            break;

        case CONFIGWIZARD_MODE_GETFINALSTAGEHTML:

            $output = '
            ';
            break;

        case CONFIGWIZARD_MODE_GETOBJECTS:

            // Get variables that were passed to us
            $address = grab_array_var($inargs, "ip_address", "");
            $hostname = grab_array_var($inargs, "hostname", "");
            $instanceid = grab_array_var($inargs, "instanceid", "");
            $accesskeyid = grab_array_var($inargs, "accesskeyid", "");
            $accesskey = grab_array_var($inargs, "accesskey", "");
            $staticcreds = grab_array_var($inargs, "staticcreds", "");
            $staticconfig = grab_array_var($inargs, "staticconfig", "");
            $credsfilepath = grab_array_var($inargs, "credsfilepath", "");
            $configfilepath = grab_array_var($inargs, "configfilepath", "");
            $check_interval = grab_array_var($inargs, "check_interval", "");

            $instance_list = json_decode(base64_decode(grab_array_var($inargs, "instancelist", "")), true);

            $objs = array();

            foreach ($instance_list as $instance_id => $instance) {
            
                if (!host_exists($instance["hostname"])) {
                    $objs[] = array(
                        "type" => OBJECTTYPE_HOST,
                        "use" => "xiwizard_linuxserver_host",
                        "host_name" => $instance["hostname"],
                        "address" => $instance["ip_address"],
                        "icon_image" => "ec2.png",
                        "statusmap_image" => "ec2.png",
                        "_xiwizard" => $wizard_name,
                    );
                }

                $commonopts = "--instanceid '" . $instance["instance_id"] . "' ";

                // Append credentials file path if toggled, otherwise pass in instanceid, accesskeyid and accesskey
                if ($staticcreds == "on") {
                    $commonopts .= "--credfile '" . $credsfilepath . "' ";
                } else {
                    $commonopts .= "--accesskeyid '" . $accesskeyid . "' --secretaccesskey '" . $accesskey . "' ";
                }
                // Append config file path if toggled, otherwise pass in region
                if ($staticconfig == "on") {
                    $commonopts .= "--configfile '" . $configfilepath . "' ";
                } else {
                    $commonopts .= "--region '" . $instance["region"] . "' ";
                }

                $metric_name_dict = array(

                        "CPUCreditBalance" => "CPU Credit Balance",
                        "CPUCreditUsage" => "CPU Credit Usage",
                        "CPUUtilization" => "CPU Utilization",
                        "DiskReadBytes" => "Disk Read Bytes",
                        "DiskReadOps" => "Disk Read Ops",
                        "DiskWriteBytes" => "Disk Write Bytes",
                        "DiskWriteOps" => "Disk Write Ops",
                        "NetworkIn" => "Network In",
                        "NetworkOut" => "Network Out",
                        "NetworkPacketsIn" => "Network Packets In",
                        "NetworkPacketsOut" => "Network Packets Out",
                        "StatusCheckFailed" => "Status Check Failed",
                        "StatusCheckFailed_Instance" => "Status Check Failed Instance",
                        "StatusCheckFailed_System" => "Status Check Failed System"

                );

                foreach ($instance["metrics"] as $metric_name => $metric_info) {
                    if ( $metric_info["checkbox"] != "on") {
                        continue;
                    }

                    switch ($metric_name) {

                        case "ping":
                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $instance["hostname"],
                                "service_description" => "Ping",
                                "use" => "xiwizard_linuxserver_ping_service",
                                "_xiwizard" => $wizard_name,
                            );
                            break;

                        default:
                            $objs[] = array(
                                "type" => OBJECTTYPE_SERVICE,
                                "host_name" => $instance["hostname"],
                                "service_description" => $metric_name_dict[$metric_name],
                                "use" => "xiwizard_linuxserver_ping_service",
                                "check_command" => "check_ec2!" . " -P " . $check_interval . " --metricname " . $metric_name . " " . $commonopts . "--warning '" . $metric_info["warning"] . "' --critical '" . $metric_info["critical"] . "'",
                                "_xiwizard" => $wizard_name,
                            );
                            break;
                    }
                }
            }

            // Return the object definitions to the wizard
            $outargs[CONFIGWIZARD_NAGIOS_OBJECTS] = $objs;

            break;

        default:
            break;
    }

    return $output;
}


/**
 *
 * @return string
 */
