#!/bin/bash -e
#
# Script to automatically upgrade and configure NagVis
#
# NagVis Integration Component - Upgrade
# Copyright (c) 2018-2022 - Nagios Enterprises, LLC. All rights reserved.
#

BASEDIR=$(dirname $(readlink -f $0))
. /usr/local/nagiosxi/var/xi-sys.cfg

NAGVIS_VER="1.9.34-nagios"
TS=$(date +%s)

# Check if NagVis is installed
if [ ! -f /usr/local/nagvis/share/index.php ]; then
    echo "NagVis is not installed"
    exit 0
fi

# Check whether we have sufficient privileges
if [ $(whoami) != "root" ]; then
    echo "This script needs to be run as root/superuser." >&2
    exit 0
fi

# Config updates for 1.9.8 (and patches for security)
update_config_and_mods() {

	# Replace links
	sed -i 's|^;host_downtime_url.*|host_downtime_url="[html_cgi]/../nagioscore/ui/cmd.php?cmd_typ=55\&host=[name]"|' /usr/local/nagvis/etc/nagvis.ini.php
	sed -i 's|^;host_ack_url.*|host_ack_url="[html_cgi]/../nagioscore/ui/cmd.php?cmd_typ=96\&host=[name]\&force_check"|' /usr/local/nagvis/etc/nagvis.ini.php
	sed -i 's|^;service_downtime_url.*|service_downtime_url="[html_cgi]/../nagioscore/ui/cmd.php?cmd_typ=56\&host=[name]\&service=[service_description]"|' /usr/local/nagvis/etc/nagvis.ini.php
	sed -i 's|^;service_ack_url.*|service_ack_url="[html_cgi]/../nagioscore/ui/cmd.php?cmd_typ=7\&host=[name]\&service=[service_description]\&force_check"|' /usr/local/nagvis/etc/nagvis.ini.php

	# Add mods
	/bin/cp -rf $BASEDIR/mods/GlobalBackendndomy.php /usr/local/nagvis/share/server/core/classes/GlobalBackendndomy.php
	/bin/cp -rf $BASEDIR/mods/GlobalBackendPDO.php /usr/local/nagvis/share/server/core/classes/GlobalBackendPDO.php
	/bin/cp -rf $BASEDIR/mods/GlobalBackground.php /usr/local/nagvis/share/server/core/classes/GlobalBackground.php
	/bin/cp -rf $BASEDIR/mods/CorePDOHandler.php /usr/local/nagvis/share/server/core/classes/CorePDOHandler.php
	/bin/cp -rf $BASEDIR/mods/NagVisHeaderMenu.php /usr/local/nagvis/share/frontend/nagvis-js/classes/NagVisHeaderMenu.php
	/bin/cp -rf $BASEDIR/mods/oldPhpVersionFixes.php /usr/local/nagvis/share/server/core/functions/oldPhpVersionFixes.php
	/bin/cp -rf $BASEDIR/mods/Compiler.php /usr/local/nagvis/share/frontend/nagvis-js/ext/dwoo-1.1.0/Dwoo/Compiler.php
}

# Check current version of NagVis to see if we can even upgrade properly
# (Version must be 1.5.x)
if ! grep -q "NagVis 1.5" "/usr/local/nagvis/README"; then

    # Verify version and upgrade if we need to
    if grep -q "1.9.8" "/usr/local/nagvis/share/server/core/defines/global.php"; then
            update_config_and_mods
    elif grep -q "1.9.34" "/usr/local/nagvis/share/server/core/defines/global.php"; then
            # Future maintainer - if you have time, figure out how to turn this whole upgrade script into a real upgrade script.
            update_config_and_mods
    else
            echo "You must have NagVis version 1.5.x to automatically upgrade."
            echo "Note: In this situation we recommend installing the latest version of XI"
            echo "on a clean system for best results."
    fi

    # Exit out (we either did the mods or we are on a version that shouldn't be upgraded)
    exit 0

fi


echo "Backing up old NagVis install ..."

# First, let's make a backup
mkdir -p /store/backups/nagvis
cd /store/backups/nagvis
tar -zcf nagvis-upgrade-$TS.tar.gz /usr/local/nagvis

# Install pre-reqs (only needed on old installs - since we only supported CentOS we don't need to check
# for other operating system installs)
if [ "$distro" == "CentOS" ] || [ "$distro" == "RedHatEnterpriseServer" ] || [ "$distro" == "OracleServer" ]; then
	yum install rsync -y
fi

# Run the install (upgrades if NagVis is 1.5 +)
(
	cd $BASEDIR
	tar zxf nagvis-$NAGVIS_VER.tar.gz
	cd nagvis-$NAGVIS_VER
	echo | ./install.sh -b /usr/bin -u $apacheuser -g $apachegroup -w "$httpdconfdir" -i ndo2db -c y -a y -q
	cd ..
	rm -rf nagvis-$NAGVIS_VER
)

# Update the configuration/do mods
update_config_and_mods

# Update NagVis login to us LogonSession instead of LogonMixed
sed -i 's/logonmodule=.*/logonmodule="LogonSession"/' /usr/local/nagvis/etc/nagvis.ini.php
sed -i 's/logonenvvar="/;logonenvvar="/' /usr/local/nagvis/etc/nagvis.ini.php

# Update apache config to remove Basic Auth
sed -i 's/AuthName/#Authname/' $httpdconfdir/nagvis.conf
sed -i 's/AuthType/#AuthType/' $httpdconfdir/nagvis.conf
sed -i 's/AuthUserFile/#AuthUserFile/' $httpdconfdir/nagvis.conf

# Update settings for apache 2.4?
if [ "$dist" == "el7" ]; then
	echo "Updating for apache 2.4 if we need to..."
	sed -i 's/Require valid-user/Require all granted/' $httpdconfdir/nagvis.conf
else
	sed -i 's/Require valid-user/#Require valid-user/' $httpdconfdir/nagvis.conf
fi

# Remove livestatus backend
sed -i 's/\[backend_live_1\]/;\[backend_live_1\]/' /usr/local/nagvis/etc/nagvis.ini.php
sed -i 's/backendtype="mklivestatus"/;backendtype="mklivestatus"/' /usr/local/nagvis/etc/nagvis.ini.php

# Update ndomy_1 to nagiosxi
sed -i 's/\[backend_ndomy_1\]/\[backend_nagiosxi\]/' /usr/local/nagvis/etc/nagvis.ini.php
sed -i 's/backend="ndomy_1"/backend="nagiosxi"/' /usr/local/nagvis/etc/nagvis.ini.php

# Reload Apache configuration
service httpd reload

echo "NagVis upgraded to $NAGVIS_VER"
