<?php
//
// Copyright (c) 2008-2017 Nagios Enterprises, LLC. All rights reserved.
//

require_once(dirname(__FILE__) . '/../coreuiproxy.inc.php');
coreui_do_proxy("config.cgi");
