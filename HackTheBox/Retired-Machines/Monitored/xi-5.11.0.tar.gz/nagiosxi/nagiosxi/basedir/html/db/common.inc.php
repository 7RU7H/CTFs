<?php
//
// Copyright (c) 2008-2020 Nagios Enterprises, LLC.  All rights reserved.
//

require_once(dirname(__FILE__) . '/../includes/db.inc.php');
require_once(dirname(__FILE__) . '/queries.inc.php');

